# SITUNEO DIGITAL PLATFORM - RINGKASAN EKSEKUTIF

**Perusahaan:** PT Permata Cahaya Abadi  
**Direktur:** Devin Prasetyo Hermawan  
**Tanggal:** 9 November 2025  
**Versi:** 2.0

---

## 🎯 OVERVIEW

SITUNEO adalah platform digital all-in-one untuk bisnis Indonesia dengan 232+ layanan digital dalam 10 divisi.

**Key Features:**
- ✅ NO Setup Fee untuk sewa bulanan
- ✅ NO Kontrak Minimum
- ✅ 232+ Layanan dalam 1 platform
- ✅ 1500+ Website Types
- ✅ Multi-tier Commission (30%-55%)
- ✅ 50 Demo Websites production-ready
- ✅ Dual Language (Indonesia & English)

---

## 💰 PRICING SYSTEM

### A. BELI PUTUS (One-Time Payment)
```
Landing Page (1 halaman): Rp 350,000
Multi-page: Rp 350,000 × jumlah halaman

Contoh:
- 1 halaman  = Rp 350,000
- 5 halaman  = Rp 1,750,000
- 10 halaman = Rp 3,500,000

Included:
✅ Website jadi (ownership 100%)
✅ Domain gratis 1 tahun
✅ Hosting gratis 1 bulan
✅ SSL Certificate

NOT Included:
❌ Maintenance & support
❌ Hosting perpanjangan
❌ Minor updates
```

### B. SEWA BULANAN (Subscription)
```
Landing Page (1 halaman): Rp 150,000/bulan
Multi-page: Rp 150,000 × jumlah halaman

Contoh:
- 1 halaman  = Rp 150,000/bulan
- 5 halaman  = Rp 750,000/bulan
- 10 halaman = Rp 1,500,000/bulan

Setup Fee: Rp 0 (GRATIS!)
Kontrak Minimum: TIDAK ADA
Minimal Berlangganan: 3 bulan (untuk komisi partner)

Included:
✅ Domain
✅ Hosting
✅ SSL Certificate
✅ Maintenance & backup
✅ Support 24/7 via WhatsApp
✅ Minor updates (text, foto)
✅ Security updates
```

### C. SPECIAL: Client Premium (>Rp 5jt)
```
✅ Akses dashboard admin khusus
✅ Bisa edit website sendiri
✅ Full control atas konten
✅ Training penggunaan dashboard
```

---

## 💸 COMMISSION SYSTEM

### Tier Structure
```
TIER 1: 0-10 order/bulan   → 30% komisi
TIER 2: 10-25 order/bulan  → 40% komisi
TIER 3: 50+ order/bulan    → 50% komisi
TIER MAX: 75+ order/bulan  → 55% komisi (50% + bonus 5%)

Maintenance Tier: TETAP BERTAHAN
```

### Komisi Rules

**Beli Putus:**
```
Komisi = Harga × Tier %
Dibayar: Setelah client bayar lunas & admin approve

Contoh:
- Client order Landing Page Rp 350K
- Partner Tier 2 (40%)
- Komisi = Rp 140K
```

**Sewa Bulanan:**
```
Komisi = Harga Bulanan × Tier % × 1 bulan ONLY
Syarat: Client minimal 3 bulan

CRITICAL: Jika client STOP sebelum 3 bulan:
→ Komisi partner DIPOTONG
→ SPV dapat 10%, Manager 5%
→ Alternatif: Partner follow-up client
```

---

## 👥 PARTNER HIERARCHY

```
ADMIN (GOD MODE)
    │
    ├── MANAGER AREA (5% komisi + bonus)
    │   └── SPV (10% komisi + bonus)
    │       └── PARTNER (30-55% base komisi)
    │
    └── CLIENT (Order & Pay)
```

### Role Details

**PARTNER:**
- Cari client via referral link
- Terima tugas tambahan (opsional)
- Komisi: 30-55% (sesuai tier)
- Withdraw minimal: Rp 50K

**SPV:**
- Manage partner-partner dibawahnya
- 10% dari order partner downline
- Bonus tier based on ARPU

**MANAGER AREA:**
- Manage SPV-SPV di area tertentu
- 5% dari order SPV & partner dibawahnya
- Bonus tier based on ARPU

---

## 🔗 REFERRAL SYSTEM

```
Format Link: https://situneo.my.id/register/partner-username

Tracking:
- Partner bisa custom username
- Link pertama yang diklik = yang dapat komisi
- Cookie tracking: TIDAK
- Siapa daftar duluan = dapat komisi
```

---

## 💼 JOB BOARD SYSTEM

Flow:
1. Admin post tugas (title, deadline, komisi, requirement)
2. Broadcast ke semua partner dashboard
3. Partner klik "MINAT"
4. Admin approve partner
5. Partner kerja & submit
6. Admin review & approve
7. Komisi masuk saldo partner

**Penalty System:**
- Telat 1-3 hari: Warning
- Telat 4-7 hari: -10% komisi
- Telat >7 hari: -25% komisi + Warning keras
- Banyak telat: Blacklist dari job board

---

## 💳 WITHDRAWAL SYSTEM

```
Minimum: Rp 50,000
Processing: 1-3 hari kerja
Admin Approval: WAJIB

Method:
✅ Transfer Bank (BCA, Mandiri, BNI, BRI, dll)
✅ QRIS (e-wallet)

Fee: GRATIS
```

---

## 📞 CONTACT

```
Company: PT Permata Cahaya Abadi
Director: Devin Prasetyo Hermawan
Website: https://situneo.my.id
WhatsApp: +62 831-7386-8915
Email: vins@situneo.my.id

Address:
Jl. Bekasi Timur IX Dalam No. 27
Jakarta Timur

NIB: 20250-9261-4570-4515-5453
NPWP: 90.296.264.6-002.000
```
