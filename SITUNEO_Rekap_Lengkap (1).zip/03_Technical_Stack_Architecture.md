# TECHNICAL STACK & ARCHITECTURE

---

## 🛠️ TECHNOLOGY STACK

### Frontend
```
- HTML5 (semantic markup)
- CSS3 + Tailwind CSS 3.4
- JavaScript (ES6+)
- jQuery 3.7.1
- Chart.js (untuk dashboard analytics)
- Particles.js (network effect background)
- AOS (Animate On Scroll)
- Swiper.js (slider/carousel)
```

### Backend
```
- PHP 8.1+ (Native, NO Framework)
- MySQL 8.0+
- PHPMailer (email notifications)
- JSON (API responses)
```

### Development Tools
```
- Git (version control)
- VS Code / PHPStorm
- XAMPP / Laragon (local development)
- Postman (API testing)
```

### Hosting Requirements
```
- cPanel hosting
- PHP 8.1+
- MySQL 8.0+
- SSL Certificate (Let's Encrypt)
- Email (SMTP)
```

---

## 📁 FILE STRUCTURE

```
situneo/
│
├── assets/
│   ├── css/
│   │   ├── tailwind.min.css
│   │   ├── custom.css
│   │   └── animations.css
│   │
│   ├── js/
│   │   ├── jquery.min.js
│   │   ├── particles.min.js
│   │   ├── aos.min.js
│   │   ├── chart.min.js
│   │   ├── swiper.min.js
│   │   └── custom.js
│   │
│   ├── images/
│   │   ├── logo/
│   │   ├── services/
│   │   ├── demos/
│   │   └── icons/
│   │
│   └── fonts/
│
├── config/
│   ├── database.php
│   ├── email.php
│   └── app.php
│
├── includes/
│   ├── header.php
│   ├── footer.php
│   ├── navbar.php
│   └── functions.php
│
├── pages/
│   ├── home.php
│   ├── about.php
│   ├── services.php
│   ├── demos.php
│   ├── pricing.php
│   ├── partner.php
│   └── contact.php
│
├── auth/
│   ├── login.php
│   ├── register.php
│   ├── logout.php
│   └── forgot-password.php
│
├── client/
│   ├── dashboard.php
│   ├── orders.php
│   ├── payments.php
│   ├── websites.php
│   └── profile.php
│
├── partner/
│   ├── dashboard.php
│   ├── referral.php
│   ├── commission.php
│   ├── withdraw.php
│   ├── job-board.php
│   └── profile.php
│
├── admin/
│   ├── dashboard.php
│   ├── users.php
│   ├── orders.php
│   ├── payments.php
│   ├── withdrawals.php
│   ├── services.php
│   ├── demos.php
│   ├── job-board.php
│   ├── reports.php
│   └── settings.php
│
├── api/
│   ├── auth.php
│   ├── orders.php
│   ├── payments.php
│   ├── commission.php
│   └── referral.php
│
├── uploads/
│   ├── payments/
│   ├── profiles/
│   └── documents/
│
├── .htaccess
├── index.php
└── README.md
```

---

## 🗄️ DATABASE STRUCTURE

### Core Tables

**1. users**
```sql
- id (PK)
- username (unique)
- email (unique)
- password (hashed)
- full_name
- phone
- role (client/partner/spv/manager/admin)
- referral_code (unique, untuk partner)
- referred_by (FK → users.id)
- tier (partner tier: 1-4)
- balance (komisi saldo)
- status (active/suspended/banned)
- created_at
- updated_at
```

**2. orders**
```sql
- id (PK)
- user_id (FK → users.id)
- service_id (FK → services.id)
- order_type (beli/sewa)
- pages_count
- total_price
- commission_partner
- commission_spv
- commission_manager
- status (pending/processing/completed/cancelled)
- payment_proof (file path)
- payment_verified_at
- payment_verified_by (FK → users.id, admin)
- notes
- created_at
- updated_at
```

**3. services**
```sql
- id (PK)
- division_id (FK → divisions.id)
- name
- description
- price_buy (beli putus)
- price_rent (sewa bulanan)
- features (JSON)
- demo_url
- is_active
- created_at
- updated_at
```

**4. divisions**
```sql
- id (PK)
- name
- slug
- description
- icon
- sort_order
- is_active
- created_at
```

**5. referrals**
```sql
- id (PK)
- partner_id (FK → users.id)
- referred_user_id (FK → users.id)
- order_id (FK → orders.id)
- commission_amount
- commission_status (pending/paid)
- paid_at
- created_at
```

**6. withdrawals**
```sql
- id (PK)
- user_id (FK → users.id)
- amount
- bank_name
- account_number
- account_name
- status (pending/approved/rejected)
- approved_by (FK → users.id, admin)
- approved_at
- notes
- created_at
```

**7. jobs**
```sql
- id (PK)
- title
- description
- requirements
- commission
- deadline
- status (open/in_progress/completed/cancelled)
- created_by (FK → users.id, admin)
- assigned_to (FK → users.id, partner)
- submitted_at
- approved_at
- approved_by (FK → users.id, admin)
- notes
- created_at
- updated_at
```

**8. demos**
```sql
- id (PK)
- name
- category
- url
- screenshot
- description
- tech_stack (JSON)
- is_featured
- view_count
- created_at
```

**9. payments**
```sql
- id (PK)
- order_id (FK → orders.id)
- amount
- payment_method
- payment_proof
- status (pending/verified/rejected)
- verified_by (FK → users.id, admin)
- verified_at
- notes
- created_at
```

**10. notifications**
```sql
- id (PK)
- user_id (FK → users.id)
- title
- message
- type (info/success/warning/danger)
- is_read
- created_at
```

---

## 🔐 SECURITY FEATURES

### Authentication
```
- Password hashing (password_hash with bcrypt)
- Session management (secure cookies)
- CSRF protection
- Rate limiting (login attempts)
```

### Input Validation
```
- SQL injection prevention (prepared statements)
- XSS prevention (htmlspecialchars)
- File upload validation (type, size)
- Email validation
- Phone number validation
```

### Data Protection
```
- SSL Certificate (HTTPS)
- Secure password reset
- Email verification
- Two-factor authentication (optional)
```

---

## 🎨 DESIGN SYSTEM

### Color Palette
```css
Primary: #3B82F6 (Blue)
Secondary: #10B981 (Green)
Accent: #F59E0B (Orange)
Dark: #1E293B
Light: #F8FAFC
Text: #334155
```

### Typography
```css
Primary Font: Inter (Google Fonts)
Heading: font-weight: 700
Body: font-weight: 400
Size Scale: 12px, 14px, 16px, 18px, 24px, 32px, 48px
```

### Spacing
```css
Tailwind spacing scale (rem-based):
0.5, 1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24
```

### Components
```
- Buttons (primary, secondary, outline, ghost)
- Cards (shadow, hover effects)
- Forms (inputs, selects, textareas)
- Modals (overlay, animations)
- Alerts (success, error, warning, info)
- Tables (responsive, sortable)
- Charts (line, bar, pie)
```

---

## 🚀 PERFORMANCE OPTIMIZATION

### Frontend
```
- Minified CSS & JS
- Lazy loading images
- CDN for libraries
- Optimized images (WebP, compression)
- Critical CSS inline
- Deferred JS loading
```

### Backend
```
- Database indexing
- Query optimization
- Caching (file-based)
- Pagination
- Async operations
```

### Hosting
```
- Gzip compression
- Browser caching (.htaccess)
- CDN integration
- Database connection pooling
```

---

## 📧 EMAIL SYSTEM

### PHPMailer Setup
```php
SMTP Host: (user's SMTP server)
SMTP Port: 587 (TLS) or 465 (SSL)
SMTP User: (user's email)
SMTP Password: (user's password)

Fallback: PHP mail() function
```

### Email Types
```
- Welcome email (registration)
- Order confirmation
- Payment verification
- Commission notification
- Withdrawal approval
- Job assignment
- Password reset
```

---

## 🔗 API ENDPOINTS

### Authentication
```
POST /api/auth/login
POST /api/auth/register
POST /api/auth/logout
POST /api/auth/forgot-password
```

### Orders
```
GET  /api/orders (list orders)
POST /api/orders (create order)
GET  /api/orders/{id} (get order detail)
PUT  /api/orders/{id} (update order)
```

### Payments
```
POST /api/payments (upload payment proof)
PUT  /api/payments/{id}/verify (admin verify)
```

### Commission
```
GET /api/commission (partner commission list)
GET /api/commission/stats (commission statistics)
```

### Withdrawals
```
GET  /api/withdrawals (list withdrawals)
POST /api/withdrawals (create withdrawal)
PUT  /api/withdrawals/{id}/approve (admin approve)
```

---

## 🧪 TESTING CHECKLIST

### Functional Testing
```
□ User registration & login
□ Order creation & payment
□ Commission calculation
□ Referral tracking
□ Withdrawal request
□ Admin approval flows
□ Email notifications
□ File uploads
□ Dashboard analytics
```

### Security Testing
```
□ SQL injection attempts
□ XSS attempts
□ CSRF protection
□ Session hijacking
□ File upload exploits
□ Password strength
```

### Performance Testing
```
□ Page load speed (<3s)
□ Database query optimization
□ Image optimization
□ Mobile responsiveness
□ Browser compatibility
```

---

## 📦 DEPLOYMENT

### Requirements
```
- cPanel hosting
- PHP 8.1+
- MySQL 8.0+
- Minimum 1GB RAM
- 10GB disk space
- SSL Certificate
```

### Steps
```
1. Upload files via FTP/File Manager
2. Import database (.sql file)
3. Configure database credentials (config/database.php)
4. Set up email (config/email.php)
5. Configure .htaccess
6. Install SSL certificate
7. Test all functionalities
8. Go live!
```
