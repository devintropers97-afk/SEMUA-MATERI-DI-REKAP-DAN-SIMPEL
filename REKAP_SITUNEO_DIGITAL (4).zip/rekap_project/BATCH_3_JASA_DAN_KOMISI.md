# 💰 JASA YANG DAPAT KOMISI VS TIDAK

## ✅ DAPAT KOMISI (Dikerjakan Situneo)

### KATEGORI A: PEMBUATAN WEBSITE (100% dapat komisi)
```
✅ Company Profile          → Rp 2.000.000 - 5.000.000
✅ Toko Online              → Rp 3.000.000 - 8.000.000
✅ Landing Page             → Rp 1.500.000 - 3.000.000
✅ Website Sekolah          → Rp 2.500.000 - 6.000.000
✅ Portal Berita            → Rp 4.000.000 - 10.000.000
✅ Sistem Informasi         → Rp 5.000.000 - 15.000.000
✅ Website Custom           → Negotiable
```

### KATEGORI B: DESIGN & BRANDING (100% dapat komisi)
```
✅ Logo Design              → Rp 500.000 - 2.000.000
✅ Brand Identity           → Rp 2.000.000 - 5.000.000
✅ UI/UX Design             → Rp 1.500.000 - 4.000.000
✅ Banner/Poster Design     → Rp 200.000 - 800.000
```

### KATEGORI C: MOBILE APP (100% dapat komisi)
```
✅ Android App              → Rp 5.000.000 - 20.000.000
✅ iOS App                  → Rp 6.000.000 - 25.000.000
✅ Hybrid App               → Rp 4.000.000 - 15.000.000
```

### KATEGORI D: DIGITAL MARKETING (100% dapat komisi)
```
✅ SEO Services             → Rp 1.000.000/bulan
✅ Social Media Management  → Rp 2.000.000/bulan
✅ Content Creation         → Rp 500.000 - 2.000.000
✅ Google Ads Management    → Rp 1.500.000/bulan
```

### KATEGORI E: MAINTENANCE (100% dapat komisi)
```
✅ Website Maintenance      → Rp 500.000/bulan
✅ Bug Fixing               → Rp 300.000 - 1.000.000
✅ Content Update           → Rp 200.000 - 500.000
✅ Security Updates         → Rp 400.000 - 800.000
```

---

## ❌ TIDAK DAPAT KOMISI (Beli dari pihak ke-3)

### KATEGORI X: THIRD-PARTY SERVICES (0% komisi)
```
❌ Domain (.com, .id, dll)   → Rp 150.000 - 500.000/tahun
❌ Hosting Shared            → Rp 300.000 - 1.000.000/tahun
❌ Hosting VPS               → Rp 500.000 - 3.000.000/bulan
❌ SSL Certificate           → Rp 200.000 - 1.000.000/tahun
❌ Email Hosting             → Rp 150.000 - 500.000/tahun
❌ Google Workspace          → Rp 100.000/user/bulan
❌ Premium Plugins           → Vary
❌ Premium Themes            → Vary
❌ Stock Photos              → Vary
❌ Third-party Licenses      → Vary
```

**NOTE:** Ini markup kecil saja (5-10%) untuk operasional, tapi **TIDAK masuk perhitungan komisi mitra!**

---

## 📊 CONTOH PERHITUNGAN KOMISI

### Contoh Order: PropertySite Basic + Add-ons

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PropertySite Basic (Sekali Bayar)  → Rp 2.200.000 ✅
Add-on: Filter Lokasi              → Rp   300.000 ✅
Add-on: Galeri Interaktif          → Rp   150.000 ✅
Add-on: SEO Premium                → Rp   300.000 ✅
Domain .com (1 tahun)               → Rp   150.000 ❌ (third-party)
Hosting (1 tahun)                   → Rp   500.000 ❌ (third-party)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL ORDER                         → Rp 3.600.000
```

### KOMISI CALCULATION (Mitra Gold = 35%)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Jasa SITUNEO (Dapat Komisi):
- PropertySite:        Rp 2.200.000 ✅
- Add-ons:             Rp   750.000 ✅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Subtotal:              Rp 2.950.000

Third-party (Tidak Dapat Komisi):
- Domain + Hosting:    Rp   650.000 ❌
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Komisi Base:           Rp 2.950.000 × 35% 
                     = Rp 1.032.500
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL KOMISI MITRA   → Rp 1.032.500 💰
```

---

## 🔧 SISTEM AUTO DETECT

Sistem akan otomatis detect jasa mana yang:
- **COMMISSIONABLE** (dapat komisi)
- **NON-COMMISSIONABLE** (no komisi)

### ✅ Commissionable (dapat komisi):
- Semua DIVISI 1 (Website) - 100%
- Semua DIVISI 2 (Marketing) - 100%
- Semua DIVISI 3 (AI/Otomasi) - 100%
- Semua DIVISI 4 (Branding) - 100%
- Semua DIVISI 5 (Copywriting) - 100%
- Semua DIVISI 6 (Analitik) - 100%
- Sebagian DIVISI 7 (Infrastruktur) - yang jasa saja

### ❌ Non-Commissionable (no komisi):
- Domain registration (third-party)
- Hosting (third-party)
- SSL Certificate (third-party)
- Email hosting (third-party)
- Google Workspace (third-party)
- Premium Plugins/Themes (third-party)

---

## 💡 CATATAN PENTING

1. **Komisi hanya dihitung dari jasa yang dikerjakan Situneo**
2. **Third-party services tidak dapat komisi** (karena Situneo hanya reseller)
3. **Markup third-party hanya 5-10%** untuk operasional perusahaan
4. **Sistem otomatis memisahkan** jasa Situneo vs third-party saat order
5. **Partner dashboard** akan menampilkan breakdown komisi per order

---

## 📄 FILE INI BERISI:
- Kategori jasa yang dapat komisi (A-E)
- Kategori third-party yang tidak dapat komisi (X)
- Contoh perhitungan komisi real
- Sistem auto detect commissionable
- Catatan penting tentang komisi

**LANJUT KE:** `BATCH_4_STRUKTUR_FILE.md`
