# 👥 ADMIN, CLIENT & PARTNER DASHBOARD

## 📁 /admin (40+ files) - ADMIN PANEL

### Main Dashboard
```
└── index.php              ← Admin dashboard
```

### /components
```
├── sidebar.php            ← Admin sidebar
├── header.php             ← Admin header
├── stats-card.php         ← Stats widget
├── chart-widget.php       ← Chart widget
└── table-widget.php       ← Table widget
```

### /pages (Admin Pages - pecah per module!)

#### /orders
```
├── list.php               ← Orders list
├── detail.php             ← Order detail
├── create.php             ← Create order
└── edit.php               ← Edit order
```

#### /users
```
├── list.php               ← Users list
├── detail.php             ← User detail
├── create.php             ← Add user
└── edit.php               ← Edit user
```

#### /partners
```
├── list.php               ← Partners list
├── detail.php             ← Partner detail
├── earnings.php           ← Earnings history
├── withdrawals.php        ← Withdrawal requests
└── tier-management.php    ← Tier updates
```

#### /services
```
├── list.php               ← Services list
├── create.php             ← Add service
├── edit.php               ← Edit service
├── packages.php           ← Package management
└── addons.php             ← Add-ons management
```

#### /portfolio
```
├── list.php               ← Portfolio list
├── upload.php             ← Upload project
└── edit.php               ← Edit project
```

#### /messages
```
├── inbox.php              ← Contact messages
└── detail.php             ← Message detail
```

#### /demo-requests
```
├── list.php               ← Demo requests list
└── detail.php             ← Request detail
```

#### /reports
```
├── sales.php              ← Sales report
├── commissions.php        ← Commission report
└── partners.php           ← Partner performance
```

#### /settings
```
├── general.php            ← General settings
├── email.php              ← Email settings
├── payment.php            ← Payment settings
└── seo.php                ← SEO settings
```

### /ajax (AJAX Handlers)
```
├── update-order-status.php
├── delete-item.php
├── upload-file.php
├── approve-withdrawal.php
└── update-tier.php
```

---

## 📁 /client (30 files) - CLIENT DASHBOARD

### Main Dashboard
```
└── index.php              ← Client dashboard
```

### /components
```
├── sidebar.php            ← Client sidebar
├── header.php             ← Client header
└── order-status-badge.php ← Status badge component
```

### /pages

#### /orders
```
├── list.php               ← My orders
├── detail.php             ← Order detail + timeline
├── create.php             ← New order (form wizard)
└── tracking.php           ← Order tracking
```

#### /profile
```
├── view.php               ← View profile
├── edit.php               ← Edit profile
├── change-password.php    ← Change password
└── avatar-upload.php      ← Avatar upload
```

#### /invoices
```
├── list.php               ← Invoices list
├── detail.php             ← Invoice detail
└── download.php           ← Download PDF
```

#### /downloads
```
├── list.php               ← Download files
└── download-handler.php   ← File download
```

#### /support
```
├── tickets.php            ← Support tickets
├── create.php             ← New ticket
└── detail.php             ← Ticket detail + replies
```

#### /notifications
```
├── list.php               ← Notifications list
└── settings.php           ← Notification preferences
```

### /ajax
```
├── mark-notification-read.php
├── submit-review.php
└── upload-avatar.php
```

---

## 📁 /partner (30 files) - PARTNER DASHBOARD

### Main Dashboard
```
└── index.php              ← Partner dashboard
```

### /components
```
├── sidebar.php            ← Partner sidebar
├── header.php             ← Partner header
├── tier-badge.php         ← Tier badge component
└── earnings-widget.php    ← Earnings widget
```

### /pages

#### /earnings
```
├── overview.php           ← Earnings overview
├── history.php            ← Commission history
├── withdraw.php           ← Withdrawal request
└── withdrawals.php        ← Withdrawal history
```

#### /referrals
```
├── list.php               ← My referrals (clients)
├── link.php               ← Referral link + QR
└── performance.php        ← Performance stats
```

#### /tier
```
├── current.php            ← Current tier info
├── progression.php        ← Tier progression
└── benefits.php           ← Tier benefits
```

#### /marketing
```
├── materials.php          ← Marketing materials
├── download.php           ← Download brochures
└── share.php              ← Share templates
```

#### /profile
```
├── view.php               ← View profile
├── edit.php               ← Edit profile
└── bank-account.php       ← Bank account info
```

### /ajax
```
├── request-withdrawal.php
├── update-bank-account.php
└── generate-qr-code.php
```

---

## 🎯 FITUR PER ROLE

### 👨‍💼 ADMIN FEATURES
✅ Kelola semua orders (create, edit, update status)
✅ Manage users & clients
✅ Approve/reject partner withdrawals
✅ Update partner tiers manually
✅ Upload portfolio projects
✅ Manage services & pricing
✅ View reports & analytics
✅ Handle support tickets
✅ System settings management

### 👤 CLIENT FEATURES
✅ Order new services (wizard form)
✅ Track order progress (real-time)
✅ Download completed files
✅ View & download invoices
✅ Submit support tickets
✅ Leave reviews/testimonials
✅ Update profile & avatar
✅ Receive notifications
✅ View order history

### 🤝 PARTNER FEATURES
✅ Track earnings (real-time)
✅ View commission history
✅ Request withdrawals
✅ View referral list & stats
✅ Check tier progression
✅ Download marketing materials
✅ Generate unique referral link + QR code
✅ Track monthly performance
✅ Update bank account info
✅ View tier benefits

---

## 📊 DASHBOARD WIDGETS

### Admin Dashboard
```
├── Total Revenue (Card)
├── Active Orders (Card)
├── Total Partners (Card)
├── Pending Withdrawals (Card)
├── Revenue Chart (Line graph)
├── Top Partners (Table)
├── Recent Orders (Table)
└── Quick Actions (Buttons)
```

### Client Dashboard
```
├── Active Orders (Card)
├── Completed Projects (Card)
├── Pending Payments (Card)
├── Order Timeline (Progress)
├── Recent Orders (List)
└── Quick Order (Button)
```

### Partner Dashboard
```
├── Current Tier (Badge)
├── Total Earnings (Card)
├── This Month Orders (Card)
├── Pending Commission (Card)
├── Tier Progress (Bar)
├── Monthly Performance (Chart)
├── Recent Referrals (List)
└── Quick Actions (Buttons)
```

---

## 📄 FILE INI BERISI:
- Admin panel structure (40+ files)
- Client dashboard structure (30 files)
- Partner dashboard structure (30 files)
- Fitur per role
- Dashboard widgets

**LANJUT KE:** `BATCH_6_API_DATABASE_CRON.md`
