# 💎 SISTEM KOMISI & TIERING PARTNER

## 🎯 3 ROLE SISTEM

### 👨‍💼 ADMIN (Internal Team)
- Kelola website & orders
- Manage clients & partners
- Kerjakan semua project
- Approve pembayaran komisi

### 👤 CLIENT (Customer)
- Order jasa website
- Tracking progress
- Download hasil
- Bayar invoice

### 🤝 FREELANCER/MITRA/SALES (Partner)
- Cari client baru untuk Situneo
- Dapat komisi per order
- Dashboard tracking komisi
- Withdraw earnings
- Referral link unique

---

## 💰 SISTEM TIERING KOMISI (5 TIER)

### 🥉 BRONZE PARTNER (15% komisi)
**Starting Tier** - Semua partner baru mulai di sini
- Tidak ada maintenance requirement
- **Upgrade:** Capai 6 orders total

**Benefit:**
- Referral link
- Basic marketing materials
- Standard support

---

### 🥈 SILVER PARTNER (25% komisi)
**Syarat Naik:** Capai 6 orders total (dari Bronze)
- **Maintenance:** Minimum 3 orders/bulan
- **Gagal Maintain:** Turun ke Bronze
- **Re-Upgrade:** Harus capai 6 orders lagi

**Benefit:**
- Everything from Bronze
- Advanced marketing kit
- Priority support
- Monthly performance report

---

### 🥇 GOLD PARTNER (35% komisi)
**Syarat Naik:** Capai 16 orders total (dari Silver)
- **Maintenance:** Minimum 8 orders/bulan
- **Gagal Maintain:** Turun ke Silver
- **Re-Upgrade:** Harus capai 16 orders lagi

**Benefit:**
- Everything from Silver
- Custom marketing materials
- Dedicated account manager
- Quarterly business review
- Early access to new services

---

### 💎 PLATINUM PARTNER (45% komisi)
**Syarat Naik:** Capai 31 orders total (dari Gold)
- **Maintenance:** Minimum 15 orders/bulan
- **Gagal Maintain:** Turun ke Gold
- **Re-Upgrade:** Harus capai 31 orders lagi

**Benefit:**
- Everything from Gold
- Co-branding opportunities
- Joint marketing campaigns
- Premium support (24/7)
- Annual partnership retreat

---

### 👑 DIAMOND PARTNER (50% komisi - MAX!)
**Syarat Naik:** Capai 51 orders total (dari Platinum)
- **Maintenance:** Minimum 25 orders/bulan
- **Gagal Maintain:** Turun ke Platinum
- **Re-Upgrade:** Harus capai 51 orders lagi

**Benefit:**
- Everything from Platinum
- Exclusive partnership benefits
- Revenue sharing opportunities
- Strategic business planning
- VIP treatment
- Partnership awards & recognition

---

## 📊 CONTOH KASUS: MITRA A (Naik-Turun Tier)

### BULAN 1: 55 Orders 💪💪💪
```
Order 1-5:   Bronze (15%)
Order 6:     ✅ Upgrade ke Silver (25%)
Order 6-15:  Silver (25%)
Order 16:    ✅ Upgrade ke Gold (35%)
Order 16-30: Gold (35%)
Order 31:    ✅ Upgrade ke Platinum (45%)
Order 31-50: Platinum (45%)
Order 51:    ✅ Upgrade ke DIAMOND (50%)!
Order 51-55: Diamond (50%)
```
**Komisi Bulan 1:** ~Rp 45 juta (rata-rata 40%)

### BULAN 2: 20 Orders 😰
```
Current: Diamond
Maintenance: Min 25 orders
Actual: 20 orders
❌ TURUN KE PLATINUM!
```
**Komisi Bulan 2:** Rp 18 juta (45% Platinum)

### BULAN 3: 30 Orders 💪
```
Current: Platinum
Maintenance: Min 15 orders ✅ SAFE
Want Diamond? Need 51 orders!
Actual: 30 orders
⚠️ TETAP PLATINUM (kurang 21 orders)
```
**Komisi Bulan 3:** Rp 27 juta (45% Platinum)

### BULAN 4: 55 Orders! 🚀
```
Current: Platinum
Need 51 for Diamond
Actual: 55 orders
✅ NAIK LAGI KE DIAMOND!
```
**Komisi Bulan 4:** Rp 55 juta (50% Diamond)

### BULAN 5: 25 Orders ✅
```
Current: Diamond
Maintenance: Min 25 orders (tepat!)
✅ MAINTAIN DIAMOND
```
**Komisi Bulan 5:** Rp 25 juta (50% Diamond)

---

## 📧 EMAIL NOTIFICATION (Auto Send)

### Email Upgrade Tier
```
Subject: 🎉 Selamat! Tier Anda Naik ke Diamond!

Halo Mitra A,

Kami dengan senang hati mengumumkan bahwa tier partnership 
Anda telah naik ke DIAMOND! 💎

Performance bulan lalu:
✅ Total Orders: 55 orders
✅ Target untuk Diamond: 51 orders
✅ Komisi Rate: 50% (tertinggi!)

Mulai bulan ini, semua komisi Anda adalah 50% dari nilai 
jasa yang dikerjakan Situneo.

Untuk mempertahankan tier Diamond:
⚠️ Minimum 25 orders per bulan

Terima kasih atas dedikasi dan kerja keras Anda! 🚀
```

### Email Warning Turun Tier
```
Subject: ⚠️ Peringatan: Tier Anda Akan Turun

Halo Mitra B,

Tier Anda saat ini: Silver (25%)
Orders bulan ini: 1 order
Minimum required: 3 orders
Sisa waktu: 5 hari

Jika tidak mencapai 3 orders sebelum akhir bulan, 
tier Anda akan turun ke Bronze (15%) bulan depan.

Ayo semangat closing! 💪
```

---

## 📱 DASHBOARD WIDGET (Real-time)

```
┌──────────────────────────────────────────┐
│ TIER SAAT INI: 💎 DIAMOND (50%)        │
│                                          │
│ Performance Bulan Ini:                  │
│ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░ 15/25 orders     │
│                                          │
│ Status: ⚠️ Butuh 10 orders lagi!       │
│ Deadline: 15 hari lagi                  │
│                                          │
│ ⚠️ Warning: Jika <25 orders, turun ke   │
│    Platinum (45%) bulan depan           │
└──────────────────────────────────────────┘
```

---

## 📄 FILE INI BERISI:
- Sistem 3 role (Admin, Client, Partner)
- Detail 5 tier komisi (Bronze s/d Diamond)
- Benefit per tier
- Contoh kasus naik-turun tier
- Email notification template
- Dashboard widget

**LANJUT KE:** `BATCH_3_JASA_DAN_KOMISI.md`
