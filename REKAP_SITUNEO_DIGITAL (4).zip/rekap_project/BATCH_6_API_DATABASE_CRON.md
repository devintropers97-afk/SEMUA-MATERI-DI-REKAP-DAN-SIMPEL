# 🔧 API, DATABASE & CRON JOBS

## 📁 /api (20 files) - API ENDPOINTS

### /v1
```
├── index.php              ← API info
├── auth.php               ← Authentication API
├── services.php           ← Services API
├── orders.php             ← Orders API
└── webhooks.php           ← Webhook handlers
```

### /handlers
```
├── contact-submit.php         ← Contact form handler
├── demo-request.php           ← Demo request handler
├── newsletter-subscribe.php   ← Newsletter handler
├── upload-handler.php         ← File upload handler
└── search-handler.php         ← Search handler
```

### /integrations
```
├── midtrans.php           ← Payment gateway (optional)
├── whatsapp-api.php       ← WhatsApp API
└── email-api.php          ← Email API
```

---

## 📁 /database (15+ files)

### Main Files
```
└── situneo-complete.sql   ← Complete DB dump
```

### /migrations (Schema migrations)
```
├── 001-create-users.sql
├── 002-create-services.sql
├── 003-create-orders.sql
├── 004-create-partners.sql
├── 005-create-tiers.sql
└── ... (10+ migration files)
```

### /seeds (Seed data)
```
├── admin-user.sql             ← Default admin
├── divisi-1-services.sql      ← Division 1 services
├── divisi-2-services.sql      ← Division 2 services
├── divisi-3-services.sql      ← Division 3 services
├── divisi-4-services.sql      ← Division 4 services
├── divisi-5-services.sql      ← Division 5 services
├── divisi-6-services.sql      ← Division 6 services
├── divisi-7-services.sql      ← Division 7 services
├── divisi-8-services.sql      ← Division 8 services
├── divisi-9-services.sql      ← Division 9 services
├── divisi-10-services.sql     ← Division 10 services
├── tiers-config.sql           ← Tier configuration
└── settings-default.sql       ← Default settings
```

---

## 📁 /cron (10 files) - SCHEDULED TASKS

### Cron Jobs List
```
├── check-tiers.php                ← Check partner tiers (monthly)
├── send-notifications.php         ← Send pending notifications
├── send-reminders.php             ← Order reminders
├── cleanup-logs.php               ← Cleanup old logs
├── backup-database.php            ← Auto backup
├── generate-reports.php           ← Monthly reports
├── update-stats.php               ← Update statistics
├── check-expired-orders.php       ← Check expired orders
├── send-newsletter.php            ← Newsletter blast
└── optimize-images.php            ← Image optimization
```

### Cron Schedule (Recommended)

#### Daily Crons (00:00)
```bash
0 0 * * * php /path/to/cron/send-notifications.php
0 1 * * * php /path/to/cron/cleanup-logs.php
0 2 * * * php /path/to/cron/backup-database.php
0 3 * * * php /path/to/cron/optimize-images.php
```

#### Weekly Crons (Sunday 00:00)
```bash
0 0 * * 0 php /path/to/cron/send-reminders.php
0 1 * * 0 php /path/to/cron/update-stats.php
```

#### Monthly Crons (1st day 00:00)
```bash
0 0 1 * * php /path/to/cron/check-tiers.php
0 1 1 * * php /path/to/cron/generate-reports.php
0 2 1 * * php /path/to/cron/check-expired-orders.php
```

---

## 📁 /uploads (Folder structure)

### Upload Folders
```
├── /orders            ← Order files
├── /avatars           ← User avatars
├── /portfolio         ← Portfolio images
├── /documents         ← Documents
├── /temp              ← Temporary files
└── .htaccess          ← Prevent direct access
```

### .htaccess Content
```apache
# Prevent direct access to uploaded files
<Files *>
    Order Deny,Allow
    Deny from all
</Files>

# Allow access through PHP scripts only
<FilesMatch "\.(jpg|jpeg|png|gif|pdf|doc|docx)$">
    Order Allow,Deny
    Allow from all
</FilesMatch>
```

---

## 📁 /docs (10 files) - DOCUMENTATION

### Documentation Files
```
├── README.md              ← Main readme
├── INSTALLATION.md        ← Installation guide
├── DATABASE.md            ← Database schema
├── API.md                 ← API documentation
├── DEPLOYMENT.md          ← Deployment guide
├── TROUBLESHOOTING.md     ← Common issues
├── CHANGELOG.md           ← Version history
├── LICENSE.txt            ← License
└── CONTRIBUTING.md        ← Contribution guide
```

---

## 📁 /tests (Optional - 10 files)

### Test Files
```
├── test-database.php      ← Test DB connection
├── test-email.php         ← Test email sending
├── test-upload.php        ← Test file upload
├── test-payment.php       ← Test payment gateway
├── test-api.php           ← Test API endpoints
├── test-auth.php          ← Test authentication
├── test-tier.php          ← Test tier system
└── ... (other tests)
```

---

## 🗄️ DATABASE TABLES (Estimated)

### Core Tables
```
users               ← All users (admin, client, partner)
services            ← Services catalog
service_packages    ← Service packages
service_addons      ← Add-ons
orders              ← Orders
order_items         ← Order items detail
invoices            ← Invoices
payments            ← Payment records
```

### Partner System Tables
```
partners            ← Partner specific data
partner_tiers       ← Tier configuration
partner_earnings    ← Earnings history
partner_withdrawals ← Withdrawal requests
referrals           ← Referral tracking
tier_history        ← Tier changes log
```

### Content Tables
```
portfolio           ← Portfolio projects
blog_posts          ← Blog posts
testimonials        ← Testimonials
faqs                ← FAQs
contacts            ← Contact form submissions
demo_requests       ← Demo requests
newsletter          ← Newsletter subscribers
```

### System Tables
```
settings            ← System settings
notifications       ← Notifications
activity_logs       ← Activity logs
sessions            ← User sessions
email_queue         ← Email queue
```

---

## 🔌 API ENDPOINTS (Example)

### Authentication
```
POST   /api/v1/auth/login
POST   /api/v1/auth/register
POST   /api/v1/auth/logout
POST   /api/v1/auth/refresh
```

### Services
```
GET    /api/v1/services
GET    /api/v1/services/{id}
POST   /api/v1/services         (admin only)
PUT    /api/v1/services/{id}    (admin only)
DELETE /api/v1/services/{id}    (admin only)
```

### Orders
```
GET    /api/v1/orders
GET    /api/v1/orders/{id}
POST   /api/v1/orders
PUT    /api/v1/orders/{id}
DELETE /api/v1/orders/{id}
```

### Webhooks
```
POST   /api/v1/webhooks/payment
POST   /api/v1/webhooks/order-status
```

---

## 📄 FILE INI BERISI:
- API structure (20 files)
- Database migrations & seeds (15+ files)
- Cron jobs & schedule (10 files)
- Upload folder structure
- Documentation files (10 files)
- Test files (10 files)
- Database tables overview
- API endpoints example

**LANJUT KE:** `BATCH_7_KESIMPULAN.md`
