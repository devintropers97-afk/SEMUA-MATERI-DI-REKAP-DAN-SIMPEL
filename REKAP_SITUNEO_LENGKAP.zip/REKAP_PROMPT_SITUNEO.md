# 📋 REKAP INTI - PROMPT WEBSITE SITUNEO DIGITAL

## 🎯 RINGKASAN UTAMA

**Proyek:** Website SITUNEO DIGITAL untuk Hostinger Horizons AI
**Platform:** Digital Empowerment terbesar Indonesia
**Layanan:** 232+ layanan digital dalam 10 divisi spesialisasi

---

## 📌 INFORMASI BISNIS

- **Nama:** SITUNEO DIGITAL
- **Tagline:** "Build Your Future, Today"
- **Target:** Bisnis & entrepreneur yang butuh solusi digital
- **Keunggulan Utama:** 
  - 232+ layanan digital lengkap
  - Sistem partnership komisi hingga 55%
  - 50 demo website siap pakai
  - Harga transparan & terjangkau

**Brand Colors:**
- Primary: Blue (#1E5C99, #0F3057)
- Accent: Gold (#FFB400, #FFD700)
- Dark: #0a1628

---

## 🌐 STRUKTUR WEBSITE (10 HALAMAN)

### 1. HOMEPAGE
- Hero section dengan headline besar + 2 CTA
- Statistik: 1000+ Clients, 500+ Partners, 232+ Services, 99% Satisfaction
- Featured Services (6 layanan)
- 10 Divisi Spesialisasi (grid cards)
- Keunggulan SITUNEO
- Cara Kerja (3 langkah)
- Testimonials
- Partner Program
- CTA akhir + Footer

### 2. LAYANAN (SERVICES)
- Header "232+ Layanan Digital"
- Filter/tabs untuk 10 divisi
- Grid layanan dengan card design
- Sidebar kategori + search

### 3. TENTANG KAMI (ABOUT)
- Visi & Misi
- Filosofi SITUNEO
- Nilai perusahaan
- Tim & pencapaian
- Kenapa pilih SITUNEO

### 4. HARGA (PRICING)
- 2 Model Pricing:
  * Beli Putus: Rp 350,000/halaman
  * Sewa Bulanan: Rp 150,000/halaman/bulan (min 3 bulan)
- Kalkulator harga interaktif
- FAQ harga

### 5. PORTFOLIO
- Grid portfolio dengan filter
- Lightbox detail & screenshot
- CTA "Pesan Website Sejenis"

### 6. DEMO (50 WEBSITE)
- 50 demo website siap pakai
- Filter kategori:
  * E-Commerce (10)
  * Food & Beverage (8)
  * Services (12)
  * Property & Hospitality (6)
  * Education (4)
  * Professional Services (5)
  * Creative & Events (3)
  * Pet & Hobby (2)

### 7. PARTNER PROGRAM
- Benefit: Komisi 30-55%, Bonus ARPU, Training gratis
- Struktur komisi (tier 1-4)
- Testimoni partner
- FAQ partner

### 8. BLOG
- Grid blog posts
- Sidebar kategori
- Search & pagination

### 9. KONTAK
- Form kontak
- Email: info@situneo.my.id
- WhatsApp, Alamat, Map
- Social media links
- Jam operasional

### 10. FAQ
- Accordion FAQ dengan kategori:
  * Tentang SITUNEO
  * Layanan & Harga
  * Pemesanan & Pembayaran
  * Partner Program
  * Teknis & Support
- 20-30 FAQ + Search

---

## 🎨 DESIGN REQUIREMENTS

**Style:**
- Modern, professional, trustworthy
- Tech/digital aesthetic + corporate
- Clean & minimalist

**Elements:**
- Gradient backgrounds
- Card layouts dengan shadow
- Icon-based sections
- Smooth animations
- Responsive navbar

---

## 🔥 10 DIVISI SPESIALISASI

1. **Website & Sistem Digital** (35+ layanan)
   - E-commerce, Corporate, Landing Page, Blog, Custom Web App

2. **Digital Marketing** (30+ layanan)
   - SEO, SEM, Social Media Marketing, Content Marketing

3. **Automation & AI** (25+ layanan)
   - Chatbot, WhatsApp Blast, CRM, Workflow Automation

4. **Branding & Design** (20+ layanan)
   - Logo, Brand Identity, UI/UX, Graphic Design

5. **Content & Copywriting** (15+ layanan)
   - Article Writing, Copywriting, Translation

6. **Data & Analytics** (20+ layanan)
   - Data Analysis, BI, Dashboard, Reports

7. **Legal & Domain** (15+ layanan)
   - Domain, Hosting, SSL, Legal Docs, NIB

8. **Customer Experience** (10+ layanan)
   - Support System, Live Chat, Call Center

9. **Training & Education** (15+ layanan)
   - Digital Marketing Training, Consulting

10. **Partnership & Integration** (10+ layanan)
    - API Integration, Payment Gateway

---

## ⚡ FEATURES WAJIB

**Interactivity:**
- Smooth scroll navigation
- Hover effects
- Animated counter
- Image lightbox
- Accordion FAQ
- Testimonials slider
- Price calculator

**Conversion:**
- CTA buttons di banyak tempat
- WhatsApp floating button (bottom right, hijau)
- Contact form simple
- Social proof (testimonials, angka)

**Performance:**
- Fast loading < 3 detik
- Mobile responsive WAJIB
- SEO friendly

---

## 📱 NAVIGATION

**Main Menu:**
Home | Layanan (dropdown 10 divisi) | Tentang Kami | Harga | Portfolio | Demo | Partner Program | Blog | Kontak

**Footer:**
- Perusahaan (About, Team, Careers)
- Layanan (10 divisi)
- Partner (Program, Daftar, Login)
- Support (FAQ, Kontak, Help)
- Legal (Terms, Privacy)
- Social Media + Newsletter

---

## 🎯 CALL-TO-ACTIONS

- "Mulai Sekarang"
- "Pesan Layanan"
- "Konsultasi Gratis"
- "Lihat Demo"
- "Daftar Jadi Partner"
- "Hubungi Kami"
- "Request Quote"

---

## 🔑 SEO KEYWORDS

- jasa pembuatan website
- digital marketing agency
- platform digital Indonesia
- website murah berkualitas
- jasa SEO
- partner program komisi tinggi
- solusi digital bisnis
- website e-commerce

---

## ✅ CHECKLIST SETELAH JADI

- [ ] Semua 10 pages
- [ ] Navigation lengkap
- [ ] Footer dengan links
- [ ] Contact form working
- [ ] WhatsApp button
- [ ] Mobile responsive
- [ ] Fast loading
- [ ] SEO meta tags
- [ ] Social media links
- [ ] Clear CTAs

---

## 💡 TIPS IMPLEMENTASI

1. Pastikan mobile responsive
2. Optimize semua gambar
3. Button "Pesan Sekarang" menonjol
4. WhatsApp floating button (bottom right hijau)
5. Contact info mudah ditemukan
6. Sticky navbar, smooth scroll
7. Form simple
8. Warna konsisten (Blue + Gold)

---

**CARA PAKAI:**
Copy paste prompt di file asli ke Hostinger Horizons AI Website Builder. Jika AI tidak bisa sekaligus, minta bertahap mulai dari Homepage → Services → About → dst.

---

*Dibuat untuk: SITUNEO DIGITAL Platform*
*File Rekap dari: PROMPT_HOSTINGER_HORIZONS_LENGKAP.md*
