# 🎨 DESIGN GUIDELINES & SPESIFIKASI TEKNIS

## 🎯 BRAND IDENTITY

### Color Palette
**Primary Colors:**
- Deep Blue: `#1E5C99`
- Dark Blue: `#0F3057`

**Accent Colors:**
- Bright Gold: `#FFB400`
- Rich Gold: `#FFD700`

**Background Colors:**
- Dark Navy: `#0a1628`
- Pure White: `#FFFFFF`
- Light Gray: `#F5F5F5`

**Text Colors:**
- White on Dark: `#FFFFFF`
- Dark on Light: `#0a1628`
- Gray Text: `#666666`

### Gradient Examples
```css
/* Hero Gradient */
background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%);

/* Gold Accent Gradient */
background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);

/* Dark Overlay */
background: linear-gradient(180deg, rgba(10,22,40,0.9) 0%, rgba(15,48,87,0.8) 100%);
```

---

## 📐 LAYOUT SPECIFICATIONS

### Grid System
- **Container Width:** Max 1200px
- **Gutter:** 30px
- **Columns:** 12-column grid
- **Breakpoints:**
  - Mobile: 320px - 767px
  - Tablet: 768px - 1023px
  - Desktop: 1024px+

### Spacing Scale
- **XS:** 8px
- **SM:** 16px
- **MD:** 24px
- **LG:** 32px
- **XL:** 48px
- **2XL:** 64px
- **3XL:** 96px

---

## ✍️ TYPOGRAPHY

### Font Family
**Primary:** Poppins, Inter, atau Montserrat
**Secondary:** Open Sans atau Roboto

### Font Sizes
```css
/* Headlines */
H1: 60px (mobile: 36px) - Bold
H2: 48px (mobile: 32px) - Bold
H3: 36px (mobile: 28px) - SemiBold
H4: 24px (mobile: 20px) - SemiBold
H5: 20px (mobile: 18px) - Medium

/* Body Text */
Body Large: 18px - Regular
Body Default: 16px - Regular
Body Small: 14px - Regular
Caption: 12px - Regular
```

### Line Height
- Headlines: 1.2
- Body Text: 1.6
- Captions: 1.4

---

## 🎭 COMPONENT SPECIFICATIONS

### 1. BUTTONS

#### Primary Button (Gold)
```css
background: linear-gradient(135deg, #FFB400, #FFD700);
color: #0a1628;
padding: 16px 40px;
border-radius: 8px;
font-weight: 600;
font-size: 16px;
box-shadow: 0 4px 15px rgba(255, 180, 0, 0.3);
transition: all 0.3s ease;
```
**Hover:**
```css
transform: translateY(-2px);
box-shadow: 0 6px 20px rgba(255, 180, 0, 0.5);
```

#### Secondary Button (Blue Outline)
```css
background: transparent;
border: 2px solid #1E5C99;
color: #1E5C99;
padding: 14px 40px;
border-radius: 8px;
font-weight: 600;
font-size: 16px;
transition: all 0.3s ease;
```
**Hover:**
```css
background: #1E5C99;
color: #FFFFFF;
```

### 2. CARDS

#### Service Card
```css
background: #FFFFFF;
border-radius: 16px;
padding: 32px;
box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
transition: all 0.3s ease;
```
**Hover:**
```css
transform: translateY(-8px);
box-shadow: 0 16px 40px rgba(0, 0, 0, 0.12);
```

**Structure:**
- Icon (64px × 64px, colorful)
- Title (H4, Bold)
- Description (Body, 2-3 lines)
- Price tag (if applicable)
- CTA Button (Primary/Secondary)

#### Division Card
```css
background: linear-gradient(135deg, #0F3057, #1E5C99);
border-radius: 12px;
padding: 24px;
text-align: center;
min-height: 200px;
```
**Elements:**
- Large Icon/Emoji (48px)
- Division Name (H5, White, Bold)
- Brief Description (14px, White/Gray)
- Service Count Badge

### 3. HERO SECTION

**Dimensions:** Full viewport height (100vh)
**Background:** Dark gradient + overlay pattern

**Structure:**
```
[Logo/Nav - Sticky]
          ↓
[    Vertical Center    ]
[  H1 - Super Large     ]
[  Subheadline          ]
[  Description Paragraph]
[  [Primary] [Secondary]]
          ↓
[Scroll Indicator Icon  ]
```

### 4. STATS SECTION

**Layout:** 4 columns equal width
**Alignment:** Center

**Each Stat:**
```
    [Icon 48px]
        ↓
   [Number Bold]
   (Animated Counter)
        ↓
    [Label Text]
```

**Animation:** Count up from 0 when scrolled into view

### 5. NAVIGATION

#### Desktop Nav
```css
background: rgba(10, 22, 40, 0.95);
backdrop-filter: blur(10px);
position: sticky;
top: 0;
z-index: 1000;
padding: 20px 0;
```

**Menu Items:**
- Font: 14px, Medium
- Spacing: 32px between items
- Hover: Gold underline animation

#### Mobile Nav
- Hamburger icon (right)
- Slide-in menu (full height)
- Dark background
- Close icon (X)

### 6. FOOTER

**Background:** Dark Navy (#0a1628)
**Structure:** 4 columns (desktop), stacked (mobile)

**Sections:**
1. Company Info + Logo
2. Quick Links
3. Services Links
4. Contact Info

**Bottom Bar:**
- Copyright text (center)
- Social media icons (right)
- Back to top button

---

## 🎬 ANIMATIONS & INTERACTIONS

### Scroll Animations
```javascript
// Fade in from bottom
fadeInUp: {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  duration: 0.6s
}

// Fade in from left/right
fadeInSide: {
  initial: { opacity: 0, x: -30/30 },
  animate: { opacity: 1, x: 0 },
  duration: 0.6s
}
```

### Hover Effects
- **Cards:** Lift + shadow increase
- **Buttons:** Slight lift + glow
- **Links:** Color change + underline
- **Images:** Scale (1.05) + brightness

### Loading States
- Skeleton screens for content
- Spinner for buttons
- Progress bar for forms

---

## 📱 RESPONSIVE DESIGN

### Mobile First Approach
**320px - 767px (Mobile):**
- Single column layout
- Stacked navigation
- Larger touch targets (min 44px)
- Simplified hero section
- Collapsible sections

**768px - 1023px (Tablet):**
- 2-column layouts
- Side navigation optional
- Optimized card grids (2 columns)

**1024px+ (Desktop):**
- Full multi-column layouts
- Hover states active
- Larger imagery
- Advanced animations

---

## 🚀 PERFORMANCE OPTIMIZATION

### Images
- **Format:** WebP with JPG fallback
- **Lazy Loading:** Below the fold content
- **Compression:** 70-80% quality
- **Max Width:** 1920px
- **Thumbnails:** 400px × 300px

### Code
- **Minification:** CSS, JS
- **Concatenation:** Combine files
- **Caching:** Browser caching enabled
- **CDN:** Use for static assets

### Target Metrics
- **First Contentful Paint:** < 1.5s
- **Time to Interactive:** < 3.0s
- **Largest Contentful Paint:** < 2.5s
- **Cumulative Layout Shift:** < 0.1

---

## 🔐 SEO REQUIREMENTS

### Meta Tags (Every Page)
```html
<title>SITUNEO DIGITAL - Platform Digital Empowerment</title>
<meta name="description" content="232+ layanan digital lengkap. Komisi hingga 55%. 50 demo website. Harga transparan.">
<meta name="keywords" content="jasa website, digital marketing, SEO, design">
<meta name="author" content="SITUNEO DIGITAL">
<link rel="canonical" href="https://situneo.my.id">

<!-- Open Graph -->
<meta property="og:title" content="SITUNEO DIGITAL">
<meta property="og:description" content="...">
<meta property="og:image" content="og-image.jpg">
<meta property="og:url" content="https://situneo.my.id">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
```

### Heading Structure
- **H1:** One per page (main title)
- **H2:** Section headers
- **H3-H6:** Sub-sections

### Internal Linking
- Footer links to all pages
- Breadcrumbs on subpages
- Related services linking
- Blog post cross-linking

---

## 🎯 CONVERSION OPTIMIZATION

### Call-to-Actions
**Placement:**
- Hero section (above fold)
- After every major section
- End of page (final CTA)
- Floating WhatsApp button

**Copy Guidelines:**
- Action-oriented ("Mulai Sekarang", "Pesan Layanan")
- Benefit-focused ("Konsultasi Gratis", "Lihat Demo")
- Urgency (when appropriate)

### Forms
**Best Practices:**
- Minimal fields (3-5 max)
- Clear labels
- Placeholder examples
- Inline validation
- Success/error messages
- Privacy assurance

### Trust Signals
- Client logos (if available)
- Testimonials with photos
- Statistics (1000+ Clients)
- Security badges
- Money-back guarantee (if applicable)

---

## 🔧 TECHNICAL SPECIFICATIONS

### Browser Support
- Chrome (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Edge (latest 2 versions)
- Mobile browsers (iOS Safari, Chrome Mobile)

### Hosting Requirements
- **Server:** Apache/Nginx
- **PHP:** 7.4+ (if dynamic)
- **Database:** MySQL 5.7+ (if needed)
- **SSL:** Required (HTTPS)
- **Backup:** Daily automated

### Security
- HTTPS enforced
- CSRF protection
- XSS prevention
- SQL injection prevention
- Regular security updates
- Secure form submissions

---

## 📊 ANALYTICS TRACKING

### Google Analytics Events
- Button clicks (CTAs)
- Form submissions
- Service card clicks
- Demo preview clicks
- Partner registration starts
- Phone/WhatsApp clicks
- Email clicks

### Conversion Goals
1. Contact form submission
2. Phone call initiated
3. WhatsApp chat initiated
4. Demo preview
5. Partner registration
6. Service order

---

## ✅ QUALITY CHECKLIST

### Design
- [ ] Brand colors consistent
- [ ] Typography hierarchy clear
- [ ] Spacing consistent
- [ ] Icons uniform style
- [ ] Images high quality
- [ ] Mobile responsive

### Functionality
- [ ] All links working
- [ ] Forms submitting
- [ ] Navigation smooth
- [ ] Search working
- [ ] Filters working
- [ ] CTAs visible

### Performance
- [ ] Loading < 3 seconds
- [ ] Images optimized
- [ ] No console errors
- [ ] Mobile friendly
- [ ] Cross-browser tested

### SEO
- [ ] Meta tags complete
- [ ] Alt texts on images
- [ ] Heading structure correct
- [ ] Sitemap.xml present
- [ ] Robots.txt configured
- [ ] Schema markup added

### Content
- [ ] No typos/grammar errors
- [ ] Contact info correct
- [ ] Pricing accurate
- [ ] Services described
- [ ] CTAs compelling

---

*Design Guidelines untuk: SITUNEO DIGITAL*
*Spesifikasi Lengkap: Dari Brand hingga Technical*
