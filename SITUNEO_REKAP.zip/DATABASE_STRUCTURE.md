# 💾 DATABASE STRUCTURE SITUNEO DIGITAL
## Total: 85 Tables

---

## 📊 CATEGORY BREAKDOWN

```
1. Users & Auth        → 10 tables
2. Clients             → 6 tables
3. Partners            → 10 tables
4. SPV                 → 8 tables
5. Managers            → 8 tables
6. Hierarchy           → 4 tables
7. Services            → 7 tables
8. Orders & Payments   → 15 tables
9. Leaderboard         → 10 tables
10. Tasks & Support    → 5 tables
11. Website Content    → 8 tables
12. Settings & Logs    → 5 tables
```

---

## 1️⃣ USERS & AUTHENTICATION (10 tables)

### users
```sql
id, username, email, password_hash, role (admin/client/partner/spv/manager),
status (active/inactive/pending), created_at, updated_at
```

### user_sessions
```sql
session_id, user_id, ip_address, user_agent, last_activity, created_at
```

### user_activity_logs
```sql
id, user_id, action, details, ip_address, timestamp
```

### user_permissions
```sql
id, role, permission, can_access
```

### password_resets
```sql
id, user_id, token, expires_at, created_at
```

### email_verifications
```sql
id, user_id, token, verified_at, created_at
```

### login_attempts
```sql
id, email, ip_address, attempts_count, last_attempt, locked_until
```

---

## 2️⃣ CLIENTS (6 tables)

### clients
```sql
id, user_id, company_name, phone, address, city, province,
referral_partner_id (FK), created_at, updated_at
```

### client_orders
```sql
id, client_id, service_id, package_type, price, status,
partner_id (assigned), created_at, completed_at
```

### client_payments
```sql
id, order_id, amount, payment_method, payment_proof (file),
status (pending/verified/rejected), verified_by, verified_at
```

### client_invoices
```sql
id, order_id, invoice_number, issue_date, due_date, total_amount,
status (paid/unpaid), pdf_path
```

### client_demo_requests
```sql
id, client_id, 
-- Informasi Bisnis (8 fields)
business_name, business_type, business_description, business_address,
business_phone, business_email, business_instagram, business_facebook,
-- Target Market (4 fields)
target_audience, target_location, target_age_range, target_income,
-- Fitur Website (7 fields)
need_ecommerce, need_booking, need_gallery, need_blog, 
need_whatsapp, need_maps, other_features,
-- Design Preferences (4 fields)
preferred_colors, preferred_style, reference_websites, additional_notes,
-- Contact Info (3 fields)
contact_person, contact_phone, contact_email,
status (pending/approved/rejected), created_at
```

### client_notifications
```sql
id, client_id, type, title, message, read_at, created_at
```

---

## 3️⃣ PARTNERS (10 tables)

### partners
```sql
id, user_id, tier (rookie/bronze/silver/gold/platinum),
monthly_orders, total_earnings, spv_id (FK), manager_id (FK),
ktp_file, cv_file, bank_account, bank_name, account_holder,
application_status (pending/approved/rejected), approved_at, approved_by
```

### partner_tiers
```sql
id, partner_id, current_tier, orders_this_month, commission_rate,
next_tier, orders_needed, updated_at
```

### partner_tier_history
```sql
id, partner_id, old_tier, new_tier, changed_at, reason
```

### partner_referral_codes
```sql
id, partner_id, referral_code (username), qr_code_path,
total_referrals, successful_conversions, created_at
```

### partner_commissions
```sql
id, partner_id, order_id, order_amount, commission_rate,
commission_amount, status (pending/paid), paid_at
```

### partner_withdrawals
```sql
id, partner_id, amount, bank_name, account_number, account_holder,
status (pending/approved/rejected), requested_at, processed_at, processed_by
```

### partner_applications
```sql
id, user_id, full_name, phone, address, ktp_file, cv_file,
motivation_letter, status (pending/approved/rejected),
reviewed_by, reviewed_at, rejection_reason, applied_at
```

### partner_documents
```sql
id, partner_id, document_type (ktp/cv/contract), file_path,
uploaded_at, verified
```

### partner_tasks
```sql
id, task_id (FK), partner_id, application_status, assigned,
submission, submission_file, status (applied/assigned/submitted/approved/rejected),
commission_amount, paid_at
```

### partner_task_applications
```sql
id, task_id, partner_id, cover_letter, applied_at,
status (pending/accepted/rejected)
```

---

## 4️⃣ SPV (Supervisor) (8 tables)

### spv_profiles
```sql
id, user_id, area_name, target_arpu, current_arpu, active_partners_count,
total_earnings, bank_account, created_at
```

### spv_teams
```sql
id, spv_id, partner_id, assigned_at, status (active/inactive)
```

### spv_base_commissions
```sql
id, spv_id, order_id, partner_id, partner_commission,
spv_commission (10%), earned_at
```

### spv_bonus_tiers
```sql
id, spv_id, month, year, arpu_achieved, bonus_tier (1/2/3/4),
bonus_amount, paid_at
```

### spv_arpu_monthly
```sql
id, spv_id, month, year, total_revenue, active_partners,
arpu_calculated, updated_at
```

### spv_performance_stats
```sql
id, spv_id, month, year, total_partners, active_partners,
new_partners, total_orders, total_revenue, total_earnings
```

### spv_referral_codes
```sql
id, spv_id, referral_code, qr_code_path, total_partner_recruits,
successful_recruits, created_at
```

### spv_leaderboard_stats
```sql
id, spv_id, ranking, arpu_score, partner_count, total_orders,
total_revenue, last_updated
```

---

## 5️⃣ MANAGERS (8 tables)

### manager_profiles
```sql
id, user_id, area_name, target_arpu, current_arpu, 
active_spv_count, active_partners_count, total_earnings,
bank_account, created_at
```

### manager_areas
```sql
id, manager_id, province, city, coverage_radius, created_at
```

### manager_spv_teams
```sql
id, manager_id, spv_id, assigned_at, status (active/inactive)
```

### manager_base_commissions
```sql
id, manager_id, order_id, spv_id, partner_id, spv_commission,
manager_commission (5%), earned_at
```

### manager_bonus_tiers
```sql
id, manager_id, month, year, arpu_achieved, bonus_tier (1/2/3/4),
bonus_amount, paid_at
```

### manager_arpu_monthly
```sql
id, manager_id, month, year, total_revenue, active_spv_count,
active_partner_count, arpu_calculated, updated_at
```

### manager_performance_stats
```sql
id, manager_id, month, year, total_spv, active_spv,
total_partners, active_partners, total_orders, total_revenue, total_earnings
```

### manager_referral_codes
```sql
id, manager_id, referral_code, qr_code_path, total_spv_recruits,
successful_recruits, created_at
```

---

## 6️⃣ HIERARCHY (4 tables)

### hierarchy_structures
```sql
id, partner_id, spv_id, manager_id, level (partner/spv/manager),
assigned_at, reassigned_count
```

### hierarchy_history
```sql
id, entity_id, entity_type (partner/spv), old_supervisor_id,
new_supervisor_id, reassigned_by, reassigned_at, reason
```

### hierarchy_commissions
```sql
id, order_id, client_id, partner_id, partner_commission,
spv_id, spv_commission, manager_id, manager_commission,
total_commission, created_at
```

### hierarchy_reassignments
```sql
id, admin_id, entity_id, entity_type, from_supervisor, to_supervisor,
reason, reassigned_at
```

---

## 7️⃣ SERVICES (7 tables)

### service_categories
```sql
id, name (18 kategori), slug, description, icon, order_position
```

**18 Kategori:**
1. Website Development
2. Mobile App
3. UI/UX Design
4. Digital Marketing
5. SEO
6. Social Media
7. Content Writing
8. Graphic Design
9. Branding
10. E-commerce
11. CMS
12. Hosting & Domain
13. Maintenance
14. Consulting
15. Training
16. Custom Software
17. IoT Solutions
18. AI Integration

### services
```sql
id, category_id, name, slug, description, features (JSON),
base_price, is_active, created_at
```

### service_pricing
```sql
id, service_id, package_type (basic/standard/premium),
price, duration_days, features (JSON), is_popular
```

### service_packages
```sql
id, name, description, services (JSON array of service_ids),
total_price, discount_percentage, final_price
```

### service_addons
```sql
id, service_id, addon_name, description, additional_price
```

---

## 8️⃣ ORDERS & PAYMENTS (15 tables)

### orders
```sql
id, order_number, client_id, service_id, package_type,
total_amount, status (pending/in-progress/completed/cancelled),
partner_id (assigned), created_at, completed_at
```

### order_items
```sql
id, order_id, item_type (service/addon), item_id, quantity,
unit_price, subtotal
```

### order_timeline
```sql
id, order_id, status, description, changed_by, changed_at
```

### order_partner_assignments
```sql
id, order_id, partner_id, assigned_by, assigned_at,
status (assigned/working/completed)
```

### payments
```sql
id, order_id, payment_method (transfer/qris/wallet),
amount, payment_proof, status (pending/verified/rejected),
verified_by, verified_at
```

### payment_verifications
```sql
id, payment_id, admin_id, action (approve/reject),
notes, verified_at
```

### payment_methods
```sql
id, name (BCA/Mandiri/QRIS/etc), account_number, account_holder,
is_active, display_order
```

### invoices
```sql
id, order_id, invoice_number, issue_date, due_date,
subtotal, tax, discount, total_amount, status (paid/unpaid), pdf_path
```

### invoice_items
```sql
id, invoice_id, description, quantity, unit_price, subtotal
```

### commissions
```sql
id, order_id, recipient_id, recipient_type (partner/spv/manager),
commission_type (base/bonus/arpu), amount, status (pending/paid), paid_at
```

### commission_breakdown
```sql
id, order_id, partner_id, partner_commission, partner_rate,
spv_id, spv_commission, manager_id, manager_commission,
total_paid, calculated_at
```

### commission_history
```sql
id, commission_id, old_amount, new_amount, adjusted_by,
adjustment_reason, adjusted_at
```

---

## 9️⃣ LEADERBOARD & ANALYTICS (10 tables)

### leaderboard_partner
```sql
id, partner_id, ranking, month, year, total_orders, total_revenue,
total_earnings, conversion_rate, last_updated
```

### leaderboard_spv
```sql
id, spv_id, ranking, month, year, arpu_achieved, partner_count,
team_orders, team_revenue, total_earnings, last_updated
```

### leaderboard_manager
```sql
id, manager_id, ranking, month, year, arpu_achieved, spv_count,
partner_count, area_orders, area_revenue, total_earnings, last_updated
```

### analytics_daily
```sql
id, date, new_users, new_orders, total_revenue,
successful_payments, active_partners, active_spv, active_managers
```

### analytics_monthly
```sql
id, month, year, total_users, total_orders, total_revenue,
avg_order_value, conversion_rate, partner_growth, spv_growth, manager_growth
```

### revenue_reports
```sql
id, period_type (daily/weekly/monthly/yearly), period_start, period_end,
gross_revenue, partner_commissions, spv_commissions, manager_commissions,
net_revenue, generated_at
```

### conversion_tracking
```sql
id, referral_code, visitor_ip, visited_at, converted,
conversion_date, order_id
```

---

## 🔟 TASKS & SUPPORT (5 tables)

### admin_tasks
```sql
id, title, description, requirements, deadline, commission_amount,
slots_available, status (open/assigned/closed), created_by, created_at
```

### task_applications
```sql
id, task_id, partner_id, cover_letter, portfolio_link,
applied_at, status (pending/accepted/rejected)
```

### support_tickets
```sql
id, user_id, subject, priority (low/medium/high/urgent),
status (open/in-progress/resolved/closed), created_at, updated_at
```

### ticket_messages
```sql
id, ticket_id, user_id, message, attachments (JSON), created_at
```

### notifications
```sql
id, user_id, type, title, message, link, read_at, created_at
```

---

## 1️⃣1️⃣ WEBSITE CONTENT (8 tables)

### homepage_content
```sql
id, section (hero/about/services/portfolio/testimonials),
content (JSON), is_active, order_position, updated_at
```

### service_pages
```sql
id, service_id, slug, seo_title, seo_description, seo_keywords,
content (HTML), is_published, updated_at
```

### portfolio_items
```sql
id, title, description, demo_url, thumbnail, category,
technologies (JSON), completion_date, is_featured, views_count
```

### testimonials
```sql
id, client_name, company, rating, review_text, profile_photo,
is_approved, is_featured, created_at
```

### blog_posts
```sql
id, title, slug, excerpt, content, featured_image,
author_id, category, tags (JSON), views, status (draft/published),
published_at
```

### faqs
```sql
id, category, question, answer, order_position, is_active
```

### contact_submissions
```sql
id, name, email, phone, subject, message, ip_address,
status (new/contacted/resolved), submitted_at
```

### newsletter_subscribers
```sql
id, email, name, subscribed_at, unsubscribed_at, is_active
```

---

## 1️⃣2️⃣ SETTINGS & LOGS (5 tables)

### company_settings
```sql
id, setting_key, setting_value, updated_at
```

**Keys:**
- company_name, company_phone, company_email
- company_address, nib_number
- whatsapp_number, instagram, facebook, tiktok
- maintenance_mode, site_title, site_description

### email_templates
```sql
id, template_name, subject, body (HTML), variables (JSON),
is_active, updated_at
```

**Templates:**
- welcome_client, welcome_partner, order_confirmation
- payment_verification, tier_upgrade, withdrawal_approved
- task_assigned, demo_request_received, etc.

### system_logs
```sql
id, user_id, action, module, details (JSON), ip_address, timestamp
```

### backup_logs
```sql
id, backup_type (database/files), file_path, file_size,
status (success/failed), created_by, created_at
```

### seo_settings
```sql
id, page_url, meta_title, meta_description, meta_keywords,
og_image, canonical_url, updated_at
```

---

## 📝 INDEXES (Important!)

### Primary Keys
- All tables: `id` (AUTO_INCREMENT)

### Foreign Keys
```sql
-- Clients
clients.user_id → users.id
clients.referral_partner_id → partners.id
client_orders.client_id → clients.id
client_orders.partner_id → partners.id

-- Partners
partners.user_id → users.id
partners.spv_id → spv_profiles.id
partners.manager_id → manager_profiles.id

-- SPV
spv_profiles.user_id → users.id
spv_teams.spv_id → spv_profiles.id
spv_teams.partner_id → partners.id

-- Managers
manager_profiles.user_id → users.id
manager_spv_teams.manager_id → manager_profiles.id
manager_spv_teams.spv_id → spv_profiles.id

-- Hierarchy
hierarchy_structures.partner_id → partners.id
hierarchy_structures.spv_id → spv_profiles.id
hierarchy_structures.manager_id → manager_profiles.id

-- Orders
orders.client_id → clients.id
orders.service_id → services.id
orders.partner_id → partners.id
```

### Performance Indexes
```sql
-- Users
INDEX idx_users_email (email)
INDEX idx_users_role (role)
INDEX idx_users_status (status)

-- Orders
INDEX idx_orders_status (status)
INDEX idx_orders_created (created_at)
INDEX idx_orders_client (client_id)
INDEX idx_orders_partner (partner_id)

-- Commissions
INDEX idx_commissions_recipient (recipient_id, recipient_type)
INDEX idx_commissions_status (status)
INDEX idx_commissions_order (order_id)

-- Leaderboard
INDEX idx_leaderboard_month (month, year)
INDEX idx_leaderboard_ranking (ranking)

-- Referrals
INDEX idx_referral_code (referral_code)
UNIQUE idx_referral_username (username)
```

---

## 🔗 RELATIONSHIPS SUMMARY

```
Client (1) ←→ (N) Orders
Order (1) ←→ (1) Payment
Order (1) ←→ (1) Invoice
Order (1) ←→ (N) Commission Breakdown

Partner (N) ←→ (1) SPV
SPV (N) ←→ (1) Manager

Partner (1) ←→ (N) Orders (assigned)
Partner (1) ←→ (N) Commissions
Partner (1) ←→ (N) Referral Clients

SPV (1) ←→ (N) Partners (team)
SPV (1) ←→ (N) Base Commissions
SPV (1) ←→ (N) Bonus Tiers

Manager (1) ←→ (N) SPV (team)
Manager (1) ←→ (N) Base Commissions
Manager (1) ←→ (N) Bonus Tiers
```

---

**Total Tables: 85**
**Total Relationships: 50+**
**Production-Ready Database Schema for SITUNEO Digital**
