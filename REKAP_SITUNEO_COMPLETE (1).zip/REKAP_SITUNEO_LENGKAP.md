# REKAP LENGKAP LAYANAN SITUNEO DIGITAL

## INFORMASI UMUM
- **Nama Perusahaan**: SITUNEO (PT Situs Tuneo Sentosa Digital)
- **Fokus Bisnis**: Jasa Digital Marketing & Website Development
- **Target Market**: UMKM & Bisnis yang ingin Go Digital

---

## DIVISI 1: WEBSITE DEVELOPMENT

### A. PAKET WEBSITE

#### 1. Website Basic (Rp 2.500.000)
**Fitur Utama:**
- 1-5 halaman (Home, About, Services, Contact)
- Desain template responsif
- Domain .com/.id (1 tahun)
- Hosting 1GB
- SSL certificate
- Formulir kontak
- Integrasi Google Maps
- WhatsApp click-to-chat
- Optimasi SEO dasar (meta tags, sitemap)

**Cocok untuk:**
- Landing page promosi
- Profil perusahaan sederhana
- Portofolio freelancer/personal branding

#### 2. Website Standard (Rp 5.000.000)
**Fitur Tambahan dari Basic:**
- 6-10 halaman
- Hosting 5GB
- Formulir multi-step/conditional
- Integrasi email marketing (Mailchimp/Sendinblue)
- Blog sederhana (5 artikel)
- Gallery/portfolio showcase
- Social media feed integration
- Google Analytics & Search Console

**Cocok untuk:**
- Website bisnis profesional
- Toko offline yang butuh online presence
- Konsultan/jasa yang perlu showcase portfolio

#### 3. Website Professional (Rp 10.000.000)
**Fitur Tambahan dari Standard:**
- 11-20 halaman
- Hosting 10GB
- Custom design (unik, tidak template)
- Multi-language support (2 bahasa)
- Member area login
- CMS untuk update konten mandiri
- Advanced SEO on-page
- Speed optimization (GTmetrix score A)
- Backup otomatis mingguan

**Cocok untuk:**
- Perusahaan menengah yang butuh branding kuat
- Bisnis dengan katalog produk/jasa kompleks
- Organisasi yang perlu update konten rutin

#### 4. E-Commerce (Rp 15.000.000)
**Fitur E-Commerce:**
- Platform WooCommerce/Shopify
- Unlimited produk
- Sistem keranjang belanja
- Integrasi payment gateway (Midtrans/Xendit)
- Sistem member/customer account
- Tracking order & invoice otomatis
- Integrasi ekspedisi (JNE, SiCepat, dll)
- Product filter & search
- Review & rating system
- Diskon & kupon voucher
- Hosting 20GB
- SSL Premium

**Cocok untuk:**
- Toko online
- Bisnis retail yang ekspansi online
- Dropshipper/reseller dengan skala besar

#### 5. Website Custom/Enterprise (Rp 25.000.000+)
**Fitur Full Custom:**
- Unlimited halaman
- Custom development (PHP, Laravel, Node.js)
- Sistem booking/reservasi
- Dashboard admin kompleks
- API integration (third-party systems)
- Multi-role user management
- Advanced analytics & reporting
- Cloud hosting dedicated
- 99.9% uptime guarantee
- Priority support 24/7

**Cocok untuk:**
- Perusahaan besar dengan sistem kompleks
- Platform marketplace
- SaaS/aplikasi web

---

### B. ADD-ON WEBSITE

1. **Custom Feature Development** (Rp 2.000.000 - 10.000.000)
   - Booking system
   - Membership system
   - Live chat integration
   - Custom calculator/tools

2. **Extra Design** (Rp 1.000.000 - 3.000.000)
   - Revisi desain unlimited
   - Custom illustration/graphics
   - Animasi interaktif

3. **Performance Boost** (Rp 1.500.000)
   - CDN implementation
   - Image optimization
   - Code minification
   - Lazy loading

4. **Security Enhancement** (Rp 1.000.000)
   - Firewall setup
   - Malware scanning
   - DDoS protection
   - Regular security audit

---

## DIVISI 2: SEO & DIGITAL ADVERTISING

### A. SEO (SEARCH ENGINE OPTIMIZATION)

#### 1. SEO Basic (Rp 3.000.000/bulan)
**Deliverables:**
- Keyword research (10 keywords)
- On-page SEO optimization
- Meta tags & description
- XML sitemap
- Google Search Console setup
- Monthly report (ranking, traffic)

**Target:**
- Ranking halaman 2-3 Google (3-6 bulan)
- Peningkatan traffic 30-50%

#### 2. SEO Standard (Rp 6.000.000/bulan)
**Deliverables Tambahan:**
- 20 keywords target
- Content creation (4 artikel/bulan)
- Backlink building (10 backlinks/bulan)
- Competitor analysis
- Google My Business optimization
- Technical SEO audit
- Local SEO optimization

**Target:**
- Ranking halaman 1 Google (4-8 bulan)
- Peningkatan traffic 50-100%
- Meningkatkan konversi leads

#### 3. SEO Professional (Rp 12.000.000/bulan)
**Deliverables Tambahan:**
- 50+ keywords target
- Content creation (8 artikel/bulan)
- Advanced link building (25 backlinks/bulan)
- Schema markup implementation
- E-A-T optimization
- International SEO (multi-region)
- Video SEO
- Conversion rate optimization

**Target:**
- Top 3 ranking Google (6-12 bulan)
- Traffic organik 100-300% increase
- ROI terukur dari organic traffic

---

### B. GOOGLE ADS (PPC)

#### 1. Google Ads Basic (Rp 2.500.000 + budget iklan)
**Setup & Management:**
- Campaign setup (Search/Display)
- Keyword research & targeting
- Ad copywriting (5 variasi)
- Landing page recommendation
- Weekly monitoring & optimization
- Monthly performance report

**Minimum Budget Iklan:** Rp 3.000.000/bulan

**Target:**
- CTR minimal 2%
- Conversion rate 3-5%
- Cost per click efisien

#### 2. Google Ads Standard (Rp 5.000.000 + budget iklan)
**Fitur Tambahan:**
- Multi-campaign (Search + Display + Shopping)
- Remarketing setup
- A/B testing ads (10 variasi)
- Audience targeting advanced
- Call tracking
- Google Analytics conversion tracking
- Bi-weekly optimization

**Minimum Budget Iklan:** Rp 5.000.000/bulan

#### 3. Google Ads Professional (Rp 10.000.000 + budget iklan)
**Full Management:**
- All campaign types (Search, Display, Video, Shopping, Performance Max)
- Dynamic remarketing
- Customer Match targeting
- Advanced bidding strategies
- Landing page optimization
- Call & form tracking
- CRM integration
- Daily monitoring & optimization
- Dedicated account manager

**Minimum Budget Iklan:** Rp 10.000.000/bulan

---

### C. SOCIAL MEDIA ADVERTISING

#### 1. Meta Ads Basic (Rp 2.500.000 + budget iklan)
**Platform:** Facebook & Instagram
- Campaign setup
- Audience research & targeting
- Ad creative design (5 variasi)
- Weekly optimization
- Monthly report

**Minimum Budget Iklan:** Rp 2.000.000/bulan

#### 2. Meta Ads Standard (Rp 5.000.000 + budget iklan)
**Fitur Tambahan:**
- Multi-objective campaigns
- Advanced targeting (lookalike, custom audience)
- Video ads & carousel
- A/B testing
- Pixel setup & conversion tracking
- Retargeting campaign
- Bi-weekly optimization

**Minimum Budget Iklan:** Rp 5.000.000/bulan

#### 3. Meta Ads Professional (Rp 10.000.000 + budget iklan)
**Full Management:**
- Full funnel campaign (awareness, consideration, conversion)
- Dynamic product ads
- Lead generation forms
- Chatbot integration
- Advanced analytics & attribution
- CRM integration
- Daily monitoring
- Creative refresh 2x/bulan

**Minimum Budget Iklan:** Rp 10.000.000/bulan

---

### D. ADD-ON SEO & ADS

1. **Content Marketing Premium** (Rp 5.000.000/bulan)
   - 12 artikel SEO optimized
   - Infographic design
   - Video script & production
   - Content distribution

2. **Link Building Campaign** (Rp 3.000.000/bulan)
   - Guest posting
   - PR distribution
   - Directory submission
   - Influencer outreach

3. **Conversion Rate Optimization** (Rp 4.000.000/bulan)
   - Heatmap analysis
   - A/B testing
   - User behavior tracking
   - Landing page optimization

---

## DIVISI 3: CONTENT CREATION

### A. COPYWRITING

#### 1. Copywriting Basic (Rp 1.500.000)
**Deliverables:**
- Company profile (1 halaman)
- Product description (10 produk)
- Landing page copy
- Email template (3 template)

#### 2. Copywriting Standard (Rp 3.000.000)
**Deliverables:**
- Semua dari Basic
- Blog articles (5 artikel @ 800 kata)
- Social media captions (20 post)
- Email marketing series (5 email)
- Ad copywriting (10 variasi)

#### 3. Copywriting Professional (Rp 6.000.000)
**Deliverables:**
- Semua dari Standard
- Long-form content (3 artikel @ 2000 kata)
- Case studies (2 case study)
- White paper/e-book
- Sales funnel copywriting
- Video script (5 script)

---

### B. GRAPHIC DESIGN

#### 1. Design Basic (Rp 2.000.000)
**Deliverables:**
- Logo design (3 konsep, unlimited revisi)
- Business card
- Letterhead
- Social media template (5 template)

#### 2. Design Standard (Rp 4.000.000)
**Deliverables:**
- Semua dari Basic
- Brochure/flyer (3 desain)
- Banner/poster (5 desain)
- Social media content (20 post)
- Presentation template

#### 3. Design Professional (Rp 8.000.000)
**Deliverables:**
- Semua dari Standard
- Brand guideline lengkap
- Packaging design
- Infographic (5 desain)
- Motion graphics (3 video)
- UI/UX design (mockup)

---

### C. VIDEO PRODUCTION

#### 1. Video Basic (Rp 3.000.000)
**Deliverables:**
- Company profile video (1-2 menit)
- Simple editing
- Background music
- Subtitle
- HD quality

#### 2. Video Standard (Rp 6.000.000)
**Deliverables:**
- Product showcase video (2-3 menit)
- Professional editing
- Motion graphics
- Voice over
- Color grading
- Multiple format export

#### 3. Video Professional (Rp 12.000.000)
**Deliverables:**
- Commercial quality video (3-5 menit)
- Storyboard & scripting
- Professional shooting equipment
- Advanced editing & effects
- 3D animation
- Sound design
- Multiple revisions

---

### D. SOCIAL MEDIA MANAGEMENT

#### 1. Social Media Basic (Rp 2.500.000/bulan)
**Deliverables:**
- 2 platform (FB + IG)
- 12 post/bulan (3x seminggu)
- Content calendar
- Basic engagement (reply comment)
- Monthly report

#### 2. Social Media Standard (Rp 5.000.000/bulan)
**Deliverables:**
- 3 platform (FB + IG + TikTok/Twitter)
- 20 post/bulan (5x seminggu)
- Content creation (foto/video simple)
- Story posting (daily)
- Community management
- Hashtag research
- Bi-weekly report

#### 3. Social Media Professional (Rp 10.000.000/bulan)
**Deliverables:**
- 4+ platform (all major platforms)
- 30 post/bulan (daily posting)
- Professional content creation
- Reels/TikTok video (8 video/bulan)
- Influencer collaboration
- Campaign management
- Crisis management
- Weekly report & strategy meeting

---

## DIVISI 4: MAINTENANCE & SUPPORT

### A. WEBSITE MAINTENANCE

#### 1. Maintenance Basic (Rp 500.000/bulan)
**Services:**
- Security monitoring
- Plugin/theme update
- Backup mingguan
- Uptime monitoring
- Email support (response 24 jam)

#### 2. Maintenance Standard (Rp 1.000.000/bulan)
**Services Tambahan:**
- Content update (2x/bulan)
- Performance monitoring
- Backup harian
- Malware scanning
- Chat support (response 12 jam)
- Minor bug fix

#### 3. Maintenance Professional (Rp 2.000.000/bulan)
**Services Tambahan:**
- Unlimited content update
- Priority support (response 4 jam)
- Phone support
- Emergency fix (2 jam response)
- Monthly performance report
- SEO health check
- Competitor monitoring

---

### B. DOMAIN & HOSTING

#### 1. Domain Registration
- .com: Rp 150.000/tahun
- .id: Rp 200.000/tahun
- .co.id: Rp 300.000/tahun

#### 2. Hosting Package
**Shared Hosting:**
- Starter (1GB): Rp 300.000/tahun
- Business (5GB): Rp 600.000/tahun
- Professional (10GB): Rp 1.200.000/tahun

**Cloud Hosting:**
- Basic: Rp 2.000.000/tahun
- Standard: Rp 4.000.000/tahun
- Premium: Rp 8.000.000/tahun

---

## DIVISI 5: TECH SUPPORT & INTEGRATION

### A. SYSTEM INTEGRATION

#### 1. CRM Integration (Rp 5.000.000)
**Services:**
- HubSpot/Zoho CRM setup
- Contact import & management
- Email automation
- Lead scoring
- Sales pipeline setup
- Training basic

#### 2. Payment Gateway (Rp 3.000.000)
**Services:**
- Midtrans/Xendit/Doku setup
- Multiple payment methods
- Auto invoice
- Transaction monitoring
- Security compliance

#### 3. API Development (Rp 8.000.000+)
**Services:**
- Custom API development
- Third-party integration
- Documentation
- Testing & debugging
- Maintenance support

---

### B. CHATBOT & AI

#### 1. WhatsApp Chatbot Basic (Rp 3.000.000 setup + Rp 500.000/bulan)
**Features:**
- Auto reply 24/7
- FAQ automation
- Product catalog
- Order confirmation
- Basic analytics

#### 2. WhatsApp Chatbot Pro (Rp 6.000.000 setup + Rp 1.500.000/bulan)
**Features Tambahan:**
- AI natural language
- CRM integration
- Payment via chat
- Broadcast message
- Advanced analytics
- Multi-agent support

#### 3. AI Customer Service (Rp 10.000.000 setup + Rp 3.000.000/bulan)
**Features Full:**
- Multi-channel (WA, IG, FB, Web)
- Advanced AI training
- Sentiment analysis
- Automatic ticket creation
- Escalation to human
- Full CRM integration
- Custom reporting

---

## PAKET BUNDLING HEMAT

### PAKET A: STARTUP DIGITAL (Rp 8.000.000)
**Isi Paket:**
- Website Basic
- SEO Basic (3 bulan)
- Social Media Basic (3 bulan)
- Domain + Hosting (1 tahun)
- **HEMAT: Rp 2.000.000**

### PAKET B: BISNIS GROWTH (Rp 20.000.000)
**Isi Paket:**
- Website Standard
- SEO Standard (6 bulan)
- Google Ads Standard (3 bulan) + Budget Ads
- Social Media Standard (6 bulan)
- Copywriting Standard
- Maintenance Standard (1 tahun)
- **HEMAT: Rp 6.000.000**

### PAKET C: SCALE UP BUSINESS (Rp 50.000.000)
**Isi Paket:**
- Website Professional
- SEO Professional (12 bulan)
- Google Ads Professional (6 bulan) + Budget Ads
- Meta Ads Professional (6 bulan) + Budget Ads
- Social Media Professional (12 bulan)
- Content Creation Premium
- WhatsApp Chatbot Pro
- Maintenance Professional (1 tahun)
- **HEMAT: Rp 15.000.000**

### PAKET D: E-COMMERCE COMPLETE (Rp 35.000.000)
**Isi Paket:**
- Website E-Commerce
- SEO Standard (6 bulan)
- Google Shopping Ads (6 bulan) + Budget
- Social Media Standard (6 bulan)
- Product Photography (50 produk)
- Payment Gateway Integration
- Maintenance Standard (1 tahun)
- **HEMAT: Rp 10.000.000**

---

## SISTEM PEMBAYARAN

### Opsi Pembayaran:
1. **Full Payment**: Discount 5%
2. **50% DP - 50% Setelah Selesai**: Standard
3. **Cicilan 3x**: Khusus project >Rp 10 juta
4. **Berlangganan Bulanan**: Untuk maintenance & ads management

### Metode Pembayaran:
- Transfer Bank (BCA, Mandiri, BRI)
- E-wallet (GoPay, OVO, Dana)
- QRIS
- PayPal (international client)

---

## TIMELINE PENGERJAAN

**Website Basic:** 7-14 hari
**Website Standard:** 14-21 hari
**Website Professional:** 21-30 hari
**E-Commerce:** 30-45 hari
**Website Custom:** 45-60 hari

**SEO:** Hasil terlihat 3-6 bulan
**Ads Management:** Setup 3-5 hari
**Content Creation:** 7-14 hari
**Video Production:** 14-21 hari

---

## GARANSI & SUPPORT

1. **Website Development:**
   - Garansi bug fix 30 hari
   - Revisi desain (sesuai paket)
   - Training penggunaan

2. **SEO & Ads:**
   - Tidak garansi ranking (melawan Google policy)
   - Garansi setup & optimization sesuai best practice
   - Refund jika tidak ada improvement (after 6 bulan)

3. **Maintenance:**
   - Uptime guarantee 99.5%
   - Response time sesuai paket
   - Emergency support available

---

## KLIEN & PORTOFOLIO

**Industry Yang Sudah Ditangani:**
- E-commerce & Retail
- F&B (Restaurant, Cafe, Catering)
- Jasa Profesional (Konsultan, Lawyer, Accountant)
- Healthcare (Klinik, Lab, Apotek)
- Education (Kursus, Training Center)
- Property
- Automotive
- Beauty & Spa

**Hasil Yang Dicapai:**
- 200+ website telah dibuat
- Traffic increase rata-rata 150%
- Conversion rate improvement 50%
- ROI ads management rata-rata 300%

---

## CARA PEMESANAN

### Step 1: Konsultasi (GRATIS)
- Isi form di website
- WhatsApp: [nomor]
- Email: hello@situneo.com
- Jadwal video call

### Step 2: Proposal & Quotation
- Analisa kebutuhan
- Proposal solusi
- Quotation detail
- Timeline project

### Step 3: Agreement
- Review & revisi proposal
- Tanda tangan kontrak
- Pembayaran DP
- Kickoff meeting

### Step 4: Eksekusi
- Development/campaign execution
- Progress update berkala
- Review & revisi
- Testing & QA

### Step 5: Delivery & Training
- Final delivery
- Training penggunaan
- Handover dokumen
- Post-launch support

---

## FAQ (FREQUENTLY ASKED QUESTIONS)

**Q: Berapa lama website jadi?**
A: Tergantung paket, mulai 7 hari (Basic) hingga 60 hari (Custom).

**Q: Apakah bisa revisi desain?**
A: Ya, sesuai paket (Basic: 2x, Standard: 3x, Professional: unlimited).

**Q: Apakah ada garansi ranking SEO?**
A: Tidak ada yang bisa jamin ranking, tapi kami garansi proses optimization sesuai best practice Google.

**Q: Berapa budget minimal untuk iklan?**
A: Google Ads minimal Rp 3 juta/bulan, Meta Ads minimal Rp 2 juta/bulan.

**Q: Apakah bisa bayar cicilan?**
A: Bisa, untuk project di atas Rp 10 juta bisa cicil 3x tanpa bunga.

**Q: Siapa yang pegang domain & hosting?**
A: Domain & hosting atas nama klien, SITUNEO hanya manage.

**Q: Bagaimana jika tidak puas?**
A: Ada masa revisi sesuai paket. Jika masih tidak puas, bisa diskusi solusi atau refund sebagian (terms apply).

**Q: Apakah ada kontrak minimal?**
A: Untuk website: tidak ada. Untuk SEO & Ads: minimal 3 bulan. Maintenance: minimal 6 bulan.

---

## KONTAK & SUPPORT

**SITUNEO Digital**
PT Situs Tuneo Sentosa Digital

**Head Office:**
[Alamat lengkap]

**Contact:**
- Phone: [nomor]
- WhatsApp: [nomor]
- Email: hello@situneo.com
- Website: www.situneo.com

**Social Media:**
- Instagram: @situneo.digital
- Facebook: SITUNEO Digital
- LinkedIn: SITUNEO Digital
- TikTok: @situneo.digital

**Jam Operasional:**
Senin - Jumat: 09.00 - 18.00 WIB
Sabtu: 09.00 - 15.00 WIB
Minggu & Tanggal Merah: Closed (Emergency support available)

---

## KESIMPULAN & VALUE PROPOSITION

**Mengapa Pilih SITUNEO?**

1. **One-Stop Digital Solution**
   - Semua kebutuhan digital dalam satu tempat
   - Tidak perlu koordinasi banyak vendor

2. **Experienced Team**
   - 5+ tahun pengalaman
   - Certified professionals (Google, Meta, HubSpot)
   - 200+ project completed

3. **Result-Oriented**
   - Focus pada ROI & conversion
   - Data-driven decision
   - Transparent reporting

4. **Flexible & Scalable**
   - Paket bisa disesuaikan budget
   - Mudah upgrade seiring pertumbuhan bisnis
   - Add-on system yang modular

5. **After-Sales Support**
   - Maintenance & support tersedia
   - Training & consultation
   - Long-term partnership

**Visi SITUNEO:**
"Membantu UMKM Indonesia Go Digital dengan solusi yang terjangkau, berkualitas, dan terukur."

**Misi SITUNEO:**
- Memberikan solusi digital terbaik untuk setiap skala bisnis
- Meningkatkan literasi digital UMKM Indonesia
- Menciptakan ekosistem digital yang sehat dan berkelanjutan

---

**Last Updated:** November 2024
**Version:** 2.0

---

## CATATAN PENTING

Dokumen ini adalah katalog internal SITUNEO yang berisi seluruh layanan, harga, dan sistem operasional. Untuk presentasi ke klien, bisa disesuaikan dengan kebutuhan spesifik mereka.

**Untuk Tim Sales:**
- Gunakan katalog ini sebagai panduan
- Sesuaikan paket dengan budget & kebutuhan klien
- Selalu tawarkan bundling untuk value lebih
- Focus pada problem solving, bukan hard selling

**Untuk Tim Operasional:**
- Pastikan deliverables sesuai katalog
- Komunikasi rutin dengan klien
- Dokumentasi semua proses
- Quality control sebelum delivery

**Untuk Management:**
- Review & update katalog setiap 6 bulan
- Monitor pricing vs kompetitor
- Evaluate profitability setiap paket
- Develop new service based on market demand

---

**END OF DOCUMENT**
