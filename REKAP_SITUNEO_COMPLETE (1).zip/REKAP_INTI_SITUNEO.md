# REKAP INTI - KATALOG LAYANAN SITUNEO

## 🎯 RINGKASAN EKSEKUTIF

**Perusahaan:** PT Situs Tuneo Sentosa Digital (SITUNEO)
**Bisnis:** Jasa Digital Marketing & Website Development untuk UMKM
**Klien:** 200+ project completed, berbagai industri

---

## 📊 5 DIVISI UTAMA

### **DIVISI 1: WEBSITE DEVELOPMENT**
| Paket | Harga | Fitur Utama |
|-------|-------|-------------|
| Basic | Rp 2.5 jt | 1-5 halaman, template responsif, domain, hosting 1GB |
| Standard | Rp 5 jt | 6-10 halaman, hosting 5GB, blog, analytics |
| Professional | Rp 10 jt | 11-20 halaman, custom design, multi-language, CMS |
| E-Commerce | Rp 15 jt | Toko online, payment gateway, unlimited produk |
| Custom/Enterprise | Rp 25 jt+ | Full custom, API, cloud hosting, 99.9% uptime |

**Timeline:** 7-60 hari (tergantung paket)

---

### **DIVISI 2: SEO & DIGITAL ADVERTISING**

#### A. SEO (Search Engine Optimization)
| Paket | Harga/Bulan | Target |
|-------|-------------|--------|
| Basic | Rp 3 jt | Halaman 2-3 Google (3-6 bulan), +30-50% traffic |
| Standard | Rp 6 jt | Halaman 1 Google (4-8 bulan), +50-100% traffic |
| Professional | Rp 12 jt | Top 3 Google (6-12 bulan), +100-300% traffic |

#### B. Google Ads
| Paket | Fee Jasa | Budget Iklan Minimal |
|-------|----------|---------------------|
| Basic | Rp 2.5 jt | Rp 3 jt/bulan |
| Standard | Rp 5 jt | Rp 5 jt/bulan |
| Professional | Rp 10 jt | Rp 10 jt/bulan |

#### C. Meta Ads (Facebook & Instagram)
| Paket | Fee Jasa | Budget Iklan Minimal |
|-------|----------|---------------------|
| Basic | Rp 2.5 jt | Rp 2 jt/bulan |
| Standard | Rp 5 jt | Rp 5 jt/bulan |
| Professional | Rp 10 jt | Rp 10 jt/bulan |

---

### **DIVISI 3: CONTENT CREATION**

| Layanan | Harga |
|---------|-------|
| **Copywriting** Basic | Rp 1.5 jt (company profile, 10 product desc) |
| **Copywriting** Standard | Rp 3 jt (+ 5 artikel, 20 social post) |
| **Copywriting** Pro | Rp 6 jt (+ long-form, case study, e-book) |
| **Graphic Design** Basic | Rp 2 jt (logo, business card, 5 template) |
| **Graphic Design** Standard | Rp 4 jt (+ brochure, banner, 20 social post) |
| **Graphic Design** Pro | Rp 8 jt (+ brand guideline, packaging, motion) |
| **Video Production** Basic | Rp 3 jt (1-2 menit company profile) |
| **Video Production** Standard | Rp 6 jt (2-3 menit product showcase) |
| **Video Production** Pro | Rp 12 jt (3-5 menit commercial quality) |
| **Social Media Management** Basic | Rp 2.5 jt/bln (2 platform, 12 post) |
| **Social Media Management** Standard | Rp 5 jt/bln (3 platform, 20 post) |
| **Social Media Management** Pro | Rp 10 jt/bln (4+ platform, 30 post) |

---

### **DIVISI 4: MAINTENANCE & SUPPORT**

| Paket | Harga/Bulan | Fitur |
|-------|-------------|-------|
| Basic | Rp 500 rb | Security monitor, backup mingguan, support 24 jam |
| Standard | Rp 1 jt | + Update 2x/bulan, backup harian, support 12 jam |
| Professional | Rp 2 jt | + Unlimited update, priority support 4 jam |

**Domain & Hosting:**
- Domain .com: Rp 150 rb/tahun
- Hosting Shared: Rp 300 rb - 1.2 jt/tahun
- Cloud Hosting: Rp 2 jt - 8 jt/tahun

---

### **DIVISI 5: TECH SUPPORT & INTEGRATION**

| Layanan | Harga |
|---------|-------|
| CRM Integration | Rp 5 jt (setup HubSpot/Zoho) |
| Payment Gateway | Rp 3 jt (Midtrans/Xendit) |
| API Development | Rp 8 jt+ (custom integration) |
| WhatsApp Chatbot Basic | Rp 3 jt setup + Rp 500 rb/bln |
| WhatsApp Chatbot Pro | Rp 6 jt setup + Rp 1.5 jt/bln |
| AI Customer Service | Rp 10 jt setup + Rp 3 jt/bln |

---

## 💎 PAKET BUNDLING HEMAT

| Paket | Harga | Isi | Hemat |
|-------|-------|-----|-------|
| **A. STARTUP DIGITAL** | Rp 8 jt | Website Basic + SEO 3 bln + Social Media 3 bln + Domain/Hosting | Rp 2 jt |
| **B. BISNIS GROWTH** | Rp 20 jt | Website Standard + SEO 6 bln + Google Ads 3 bln + Social Media 6 bln + Copywriting + Maintenance 1 thn | Rp 6 jt |
| **C. SCALE UP BUSINESS** | Rp 50 jt | Website Pro + SEO 12 bln + Google & Meta Ads 6 bln + Social Media 12 bln + Content Premium + Chatbot + Maintenance 1 thn | Rp 15 jt |
| **D. E-COMMERCE COMPLETE** | Rp 35 jt | E-Commerce + SEO 6 bln + Shopping Ads 6 bln + Social Media 6 bln + Foto Produk + Payment Gateway + Maintenance 1 thn | Rp 10 jt |

---

## 💰 SISTEM PEMBAYARAN

**Opsi Pembayaran:**
1. Full Payment: Diskon 5%
2. DP 50% - Pelunasan: Standard
3. Cicilan 3x: Project >Rp 10 juta (tanpa bunga)
4. Berlangganan: Maintenance & ads management

**Metode:** Bank Transfer, E-wallet, QRIS, PayPal

---

## ⏱️ TIMELINE PENGERJAAN

- Website Basic: 7-14 hari
- Website Standard: 14-21 hari
- Website Professional: 21-30 hari
- E-Commerce: 30-45 hari
- Website Custom: 45-60 hari
- SEO: Hasil 3-6 bulan
- Content Creation: 7-14 hari

---

## 🛡️ GARANSI

✅ Website: Bug fix 30 hari
✅ SEO/Ads: Setup & optimization guarantee
✅ Maintenance: Uptime 99.5%, response time sesuai paket
✅ Revisi desain sesuai paket

---

## 📈 TRACK RECORD

✅ 200+ website dibuat
✅ Traffic increase rata-rata 150%
✅ Conversion improvement 50%
✅ ROI ads rata-rata 300%

**Industri:** E-commerce, F&B, Jasa Profesional, Healthcare, Education, Property, Automotive, Beauty

---

## 📞 KONTAK

**SITUNEO Digital**
PT Situs Tuneo Sentosa Digital

📱 WhatsApp: [nomor]
📧 Email: hello@situneo.com
🌐 Website: www.situneo.com
📷 Instagram: @situneo.digital

**Jam Operasional:**
Senin-Jumat: 09.00-18.00 WIB
Sabtu: 09.00-15.00 WIB

---

## ⭐ KEUNGGULAN SITUNEO

1. **One-Stop Digital Solution** - Semua kebutuhan digital dalam satu vendor
2. **Experienced Team** - 5+ tahun, certified professionals
3. **Result-Oriented** - Focus ROI & conversion, data-driven
4. **Flexible & Scalable** - Paket modular, mudah upgrade
5. **After-Sales Support** - Training, maintenance, consultation

---

## 🎯 CARA PEMESANAN

**Step 1:** Konsultasi GRATIS (WhatsApp/Video Call)
**Step 2:** Proposal & Quotation detail
**Step 3:** Agreement & DP
**Step 4:** Eksekusi project
**Step 5:** Delivery & Training

---

**Visi:** Membantu UMKM Indonesia Go Digital dengan solusi terjangkau & berkualitas
**Misi:** Memberikan solusi digital terbaik untuk setiap skala bisnis

---

**Last Updated:** November 2024
