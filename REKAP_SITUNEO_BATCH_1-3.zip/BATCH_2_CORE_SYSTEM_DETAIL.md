# ⚙️ BATCH 2: CORE SYSTEM - DETAIL LENGKAP

**Status:** 🔴 Belum Mulai  
**Prioritas:** 🔥 CRITICAL  
**Estimasi:** 4-6 hari kerja  
**Dependencies:** Batch 1 (Database harus sudah selesai)

---

## 🎯 TUJUAN

Membangun sistem inti aplikasi yang mencakup:
- Database Connection (PDO)
- Configuration Management
- Router System (Multi-role routing)
- Helper Functions (15+ utilities)
- Middleware (Authentication & Authorization)
- Asset Management (CSS, JS, Images)

---

## 📂 FILE STRUCTURE

```
/config/
├── database.php         (Database connection)
├── config.php          (Application settings)
└── constants.php       (Global constants)

/core/
├── Router.php          (Routing engine)
├── Controller.php      (Base controller)
├── Model.php          (Base model)
└── Middleware.php     (Auth & role middleware)

/helpers/
├── functions.php      (15 utility functions)
└── validation.php     (Form validation)

/assets/
├── css/
│   ├── main.css           (~800 lines)
│   ├── animations.css     (~300 lines)
│   └── responsive.css     (~400 lines)
├── js/
│   ├── main.js            (~500 lines)
│   ├── animations.js      (~300 lines)
│   └── utils.js           (~200 lines)
└── img/
    ├── logo.png
    ├── nib-badge.png
    └── [50+ image files]

/.htaccess              (URL rewriting)
/.env                   (Environment variables)
/index.php             (Application entry point)
```

---

## 🔧 COMPONENT DETAILS

### 1. DATABASE CONNECTION (config/database.php)

**Features:**
- PDO dengan prepared statements (SQL injection prevention)
- Connection pooling
- Error handling
- Charset UTF-8 support
- Transaction support

**Key Functions:**
```php
getConnection()         // Get PDO instance
query($sql, $params)   // Execute query
fetchAll($sql, $params) // Fetch multiple rows
fetchOne($sql, $params) // Fetch single row
insert($table, $data)  // Insert data
update($table, $data, $where) // Update data
delete($table, $where) // Delete data
beginTransaction()     // Start transaction
commit()              // Commit transaction
rollback()            // Rollback transaction
```

**Connection Settings:**
```php
PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
PDO::ATTR_EMULATE_PREPARES => false
PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
```

---

### 2. CONFIGURATION (config/config.php)

**Application Settings:**
```php
// Site Info
define('SITE_NAME', 'SITUNEO Digital');
define('SITE_URL', 'https://situneo.my.id');
define('SITE_EMAIL', 'vins@situneo.my.id');

// Paths
define('BASE_PATH', __DIR__ . '/..');
define('UPLOAD_PATH', BASE_PATH . '/uploads');
define('LOG_PATH', BASE_PATH . '/logs');

// Security
define('SESSION_LIFETIME', 3600); // 1 hour
define('PASSWORD_HASH_ALGO', PASSWORD_BCRYPT);
define('CSRF_TOKEN_LENGTH', 32);

// Pagination
define('ITEMS_PER_PAGE', 20);

// File Upload
define('MAX_FILE_SIZE', 10485760); // 10MB
define('ALLOWED_FILE_TYPES', ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx']);

// Email Settings
define('SMTP_HOST', 'mail.situneo.my.id');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'noreply@situneo.my.id');
define('SMTP_PASSWORD', 'your_password');

// Commission Rates
define('TIER_1_RATE', 0.10); // 10%
define('TIER_2_RATE', 0.15); // 15%
define('TIER_3_RATE', 0.20); // 20%
define('TIER_MAX_RATE', 0.25); // 25%
define('ARPU_BONUS_THRESHOLD', 3500000);
define('ARPU_BONUS_RATE', 0.05); // +5%
```

---

### 3. ROUTER SYSTEM (core/Router.php)

**Features:**
- Multi-role routing (Admin, Manager, SPV, Partner, Client, Public)
- Middleware support
- Dynamic parameters
- Named routes
- Route groups

**Route Definitions:**
```php
// Public Routes
Router::get('/', 'PublicController@home');
Router::get('/about', 'PublicController@about');
Router::get('/services', 'PublicController@services');
Router::post('/contact', 'PublicController@contactSubmit');

// Auth Routes
Router::get('/login', 'AuthController@login');
Router::post('/login', 'AuthController@loginSubmit');
Router::get('/register', 'AuthController@register');
Router::post('/register', 'AuthController@registerSubmit');
Router::get('/logout', 'AuthController@logout');

// Client Routes (Protected)
Router::group(['prefix' => '/client', 'middleware' => 'auth:client'], function() {
    Router::get('/dashboard', 'ClientController@dashboard');
    Router::get('/orders', 'ClientController@orders');
    Router::get('/profile', 'ClientController@profile');
});

// Partner Routes (Protected)
Router::group(['prefix' => '/partner', 'middleware' => 'auth:partner'], function() {
    Router::get('/dashboard', 'PartnerController@dashboard');
    Router::get('/commissions', 'PartnerController@commissions');
    Router::get('/clients', 'PartnerController@clients');
});

// Admin Routes (Protected)
Router::group(['prefix' => '/admin', 'middleware' => 'auth:admin'], function() {
    Router::get('/dashboard', 'AdminController@dashboard');
    Router::get('/users', 'AdminController@users');
    Router::get('/orders', 'AdminController@orders');
});
```

**URL Rewriting (.htaccess):**
```apache
RewriteEngine On
RewriteBase /

# Redirect www to non-www
RewriteCond %{HTTP_HOST} ^www\.(.*)$ [NC]
RewriteRule ^(.*)$ https://%1/$1 [R=301,L]

# Force HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]

# Route all requests to index.php
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]
```

---

### 4. HELPER FUNCTIONS (helpers/functions.php)

**15 Utility Functions:**

```php
1. sanitize($data)
   - Clean user input (XSS prevention)
   - Trim whitespace
   - Strip HTML tags

2. redirect($url, $statusCode = 302)
   - Redirect to URL
   - Support for 301, 302, 303, 307

3. asset($path)
   - Generate asset URL
   - Support versioning
   - Example: asset('css/main.css')

4. url($path)
   - Generate full URL
   - Example: url('/about')

5. flash($key, $message = null)
   - Set/get flash messages
   - Auto-expire after display

6. old($key, $default = null)
   - Get old input value (after validation error)

7. csrf_token()
   - Generate CSRF token

8. csrf_field()
   - Generate CSRF hidden input

9. verify_csrf_token($token)
   - Verify CSRF token

10. auth_user()
    - Get current logged-in user

11. is_logged_in()
    - Check if user is logged in

12. has_role($role)
    - Check if user has specific role

13. format_currency($amount)
    - Format number to Rupiah
    - Example: 1000000 → Rp 1.000.000

14. format_date($date, $format = 'd M Y')
    - Format date to Indonesian
    - Example: 2025-01-15 → 15 Jan 2025

15. upload_file($file, $directory)
    - Handle file upload
    - Validate file type & size
    - Generate unique filename
```

**Validation Functions (helpers/validation.php):**
```php
validate_required($value)
validate_email($email)
validate_phone($phone)
validate_min_length($value, $min)
validate_max_length($value, $max)
validate_numeric($value)
validate_alpha($value)
validate_alphanumeric($value)
validate_url($url)
validate_date($date)
validate_file_upload($file, $allowedTypes, $maxSize)
```

---

### 5. MIDDLEWARE (core/Middleware.php)

**Authentication Middleware:**
```php
class AuthMiddleware {
    public function handle() {
        if (!is_logged_in()) {
            flash('error', 'Silakan login terlebih dahulu');
            redirect('/login');
        }
    }
}
```

**Role-based Authorization:**
```php
class RoleMiddleware {
    public function handle($allowedRoles) {
        $user = auth_user();
        
        if (!$user || !in_array($user['role'], $allowedRoles)) {
            flash('error', 'Anda tidak memiliki akses ke halaman ini');
            redirect('/');
        }
    }
}
```

**CSRF Protection:**
```php
class CsrfMiddleware {
    public function handle() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = $_POST['csrf_token'] ?? '';
            
            if (!verify_csrf_token($token)) {
                http_response_code(403);
                die('Invalid CSRF token');
            }
        }
    }
}
```

---

### 6. BASE CONTROLLER (core/Controller.php)

**Features:**
```php
class Controller {
    protected $db;
    protected $user;
    
    public function __construct() {
        $this->db = getConnection();
        $this->user = auth_user();
    }
    
    protected function view($view, $data = []) {
        extract($data);
        require_once BASE_PATH . "/views/$view.php";
    }
    
    protected function json($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
    
    protected function validate($data, $rules) {
        // Validation logic
    }
}
```

---

### 7. BASE MODEL (core/Model.php)

**Features:**
```php
class Model {
    protected $db;
    protected $table;
    protected $primaryKey = 'id';
    
    public function __construct() {
        $this->db = getConnection();
    }
    
    public function find($id) {
        return $this->db->fetchOne(
            "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ?",
            [$id]
        );
    }
    
    public function all() {
        return $this->db->fetchAll("SELECT * FROM {$this->table}");
    }
    
    public function create($data) {
        return $this->db->insert($this->table, $data);
    }
    
    public function update($id, $data) {
        return $this->db->update(
            $this->table,
            $data,
            "{$this->primaryKey} = $id"
        );
    }
    
    public function delete($id) {
        return $this->db->delete(
            $this->table,
            "{$this->primaryKey} = $id"
        );
    }
}
```

---

## 🎨 ASSETS DETAILS

### CSS Files

**1. main.css (~800 lines)**
- Typography styles
- Color variables
- Layout components
- Button styles
- Form styles
- Card styles
- Navigation styles
- Footer styles

**2. animations.css (~300 lines)**
- Fade effects
- Slide animations
- Bounce effects
- Rotate animations
- Pulse effects
- Hover transitions
- Loading spinners

**3. responsive.css (~400 lines)**
- Mobile breakpoints
- Tablet breakpoints
- Desktop optimizations
- Print styles

### JavaScript Files

**1. main.js (~500 lines)**
- Navigation toggle
- Smooth scrolling
- Form validation
- Modal handlers
- Ajax requests
- Toast notifications

**2. animations.js (~300 lines)**
- GSAP animations
- AOS initialization
- Scroll triggers
- Parallax effects

**3. utils.js (~200 lines)**
- Helper functions
- Cookie management
- Local storage
- Date formatting
- Number formatting

---

## ✅ SUCCESS CRITERIA

### Testing Checklist
- [ ] Database connection working
- [ ] Router handling all routes correctly
- [ ] Middleware protecting routes
- [ ] Helper functions tested
- [ ] CSRF protection working
- [ ] File uploads working
- [ ] Assets loading correctly
- [ ] Error handling functional
- [ ] Logging system active
- [ ] Session management working

### Performance Tests
- [ ] Page load < 2 seconds
- [ ] Database queries optimized
- [ ] Assets minified (for production)
- [ ] Gzip compression enabled
- [ ] Browser caching configured

---

## 📋 IMPLEMENTATION STEPS

### Day 1: Configuration & Database
1. Setup database connection
2. Create config files
3. Setup constants
4. Test database queries

### Day 2: Router & Middleware
5. Build router system
6. Create .htaccess rules
7. Implement middleware
8. Test route protection

### Day 3: Controllers & Models
9. Create base controller
10. Create base model
11. Test CRUD operations

### Day 4: Helper Functions
12. Build utility functions
13. Create validation helpers
14. Test all helpers

### Day 5-6: Assets & Testing
15. Create CSS files
16. Create JavaScript files
17. Organize images/icons
18. Integration testing
19. Performance optimization
20. Documentation

---

## 🚀 NEXT STEPS AFTER BATCH 2

Setelah Batch 2 selesai:
1. ✅ Batch 3: Public Website (11 pages)
2. ✅ Batch 4: Authentication System
3. ✅ Batch 5: Client Dashboard

---

**Total Estimasi Batch 2: 4-6 hari kerja**  
**Output: Complete core system, ~3500 lines code, Ready for development**
