# 🌐 BATCH 3: PUBLIC WEBSITE - DETAIL LENGKAP

**Status:** 🔴 Belum Mulai  
**Prioritas:** 🔥 CRITICAL  
**Estimasi:** 5-7 hari kerja  
**Dependencies:** Batch 2 (Core System harus sudah selesai)

---

## 🎯 TUJUAN

Membangun website publik lengkap dengan 11 halaman yang responsive, SEO-friendly, dan dilengkapi animasi modern.

---

## 📄 11 PUBLIC PAGES

### 1. HOME (/)
**Features:**
- Hero section dengan CTA button
- Featured services (6 layanan unggulan)
- Statistics counter (animated)
- How it works (3 steps)
- Client testimonials (carousel)
- Partner registration CTA
- Latest blog posts
- FAQ accordion
- Newsletter signup

**Sections:**
```html
- Hero Section (Full screen, background image/video)
- Features Section (Icon + text, 4 columns)
- Services Preview (6 cards)
- Stats Counter (Orders, Clients, Partners, Projects)
- Process Steps (3 steps with icons)
- Testimonials Slider (3-5 testimonials)
- CTA Section (Partner registration)
- Blog Preview (3 latest posts)
- FAQ (5 common questions)
- Newsletter Form
```

---

### 2. ABOUT (/about)
**Features:**
- Company overview
- Vision & Mission
- Core values (4 values)
- Team members (10 people)
- Company timeline
- Awards & certifications
- NIB badge display
- Company statistics

**Content:**
```
Company Name: SITUNEO Digital
NIB: 20250-9261-4570-4515-5453
Address: Jl. Bekasi Timur IX Dalam No. 27, Jakarta Timur 13450
Phone: 021-8880-7229
WhatsApp: +62 831-7386-8915
Email: vins@situneo.my.id
```

---

### 3. SERVICES (/services)
**Features:**
- 232+ services display
- 10 divisions filter
- Search functionality
- Price range filter
- Service type filter (per halaman / tetap)
- Service cards (image + title + description + price)
- Quick order button
- Demo request button

**10 Service Divisions:**
1. Website Development (45 services)
2. SEO & Digital Marketing (38 services)
3. Social Media Management (25 services)
4. Graphic Design & Branding (32 services)
5. Video Production (18 services)
6. E-commerce Solutions (22 services)
7. Mobile App Development (15 services)
8. Content Writing (20 services)
9. IT Support & Maintenance (12 services)
10. Custom Software Development (5 services)

**Service Card Template:**
```html
<div class="service-card">
    <img src="service-icon.png" alt="">
    <h4>Service Name</h4>
    <p>Short description...</p>
    <div class="price">
        <span class="amount">Rp 5.000.000</span>
        <span class="type">per halaman</span>
    </div>
    <div class="actions">
        <button class="btn-order">Pesan Sekarang</button>
        <button class="btn-demo">Minta Demo</button>
    </div>
</div>
```

---

### 4. PRICING (/pricing)
**Features:**
- 3 package comparison table
- Feature comparison
- Custom quote request
- FAQ about pricing
- Money-back guarantee badge
- Payment methods display

**3 Packages:**

**1. STARTER PACKAGE**
```
Price: Rp 5.000.000
Best for: Small business, personal website
Features:
- Website 5 halaman
- Responsive design
- SEO basic
- Google Analytics
- 1 bulan support
- Hosting 1 tahun
- Domain .com/id 1 tahun
- SSL certificate
- Contact form
```

**2. BUSINESS PACKAGE** (Most Popular)
```
Price: Rp 15.000.000
Best for: Growing business, online store
Features:
- All Starter features
- Website 10 halaman
- E-commerce integration
- Payment gateway
- SEO advanced
- Social media integration
- 3 bulan support
- Backup & security
- Live chat integration
- Email marketing setup
```

**3. PREMIUM PACKAGE**
```
Price: Rp 35.000.000
Best for: Enterprise, large business
Features:
- All Business features
- Unlimited pages
- Custom development
- Mobile app (Android/iOS)
- Advanced SEO & SEM
- Social media management
- Video production
- Graphic design support
- 6 bulan support
- Priority customer service
- Monthly report & analytics
- Content writing (10 articles)
```

---

### 5. PORTFOLIO (/portfolio)
**Features:**
- Portfolio grid (masonry layout)
- Category filter (Website, Design, Marketing, etc)
- Lightbox view
- Client name & industry
- Project description
- Technologies used
- Launch date
- View live button

**Portfolio Item Template:**
```html
<div class="portfolio-item">
    <img src="project-thumbnail.jpg" alt="">
    <div class="overlay">
        <h4>Project Name</h4>
        <p>Client Name - Industry</p>
        <div class="tags">
            <span>Website</span>
            <span>E-commerce</span>
            <span>SEO</span>
        </div>
        <button class="btn-view">Lihat Detail</button>
    </div>
</div>
```

---

### 6. TESTIMONIALS (/testimonials)
**Features:**
- Client testimonials grid
- Star ratings
- Client photo & name
- Company name
- Project type
- Video testimonials
- Filter by rating
- Pagination

**Testimonial Card:**
```html
<div class="testimonial-card">
    <div class="rating">
        ★★★★★ (5.0)
    </div>
    <p class="review">
        "SITUNEO Digital sangat profesional..."
    </p>
    <div class="client-info">
        <img src="client-photo.jpg" alt="">
        <div>
            <h5>John Doe</h5>
            <p>CEO, Company Name</p>
        </div>
    </div>
    <div class="project-type">
        <small>Project: E-commerce Website</small>
    </div>
</div>
```

---

### 7. CONTACT (/contact)
**Features:**
- Contact form (name, email, phone, message)
- Google Maps embed
- Office address
- Phone numbers
- Email address
- WhatsApp button
- Social media links
- Business hours
- Form validation
- Email notification

**Contact Form Fields:**
```php
- Full Name (required)
- Email (required, email validation)
- Phone (required, format validation)
- Subject (required)
- Message (required, min 20 chars)
- CSRF Token (hidden)
- Submit button
```

**Contact Information:**
```
Office Address:
Jl. Bekasi Timur IX Dalam No. 27
Jakarta Timur 13450

Phone: 021-8880-7229
WhatsApp: +62 831-7386-8915
Email: vins@situneo.my.id

Business Hours:
Senin - Jumat: 09.00 - 18.00 WIB
Sabtu: 09.00 - 15.00 WIB
Minggu: Tutup
```

---

### 8. FAQ (/faq)
**Features:**
- FAQ accordion
- Search FAQ
- Categories (Umum, Layanan, Harga, Teknis, Partner)
- Popular questions highlight
- Contact support CTA

**FAQ Categories:**
```
1. Pertanyaan Umum (10 questions)
   - Apa itu SITUNEO Digital?
   - Layanan apa saja yang ditawarkan?
   - Berapa lama pengerjaan website?
   - dll.

2. Layanan & Harga (12 questions)
   - Berapa harga membuat website?
   - Apakah ada paket bundling?
   - Apa saja yang termasuk dalam paket?
   - dll.

3. Proses & Teknis (8 questions)
   - Bagaimana cara memesan?
   - Apa yang perlu disiapkan?
   - Bagaimana proses revisi?
   - dll.

4. Partnership (6 questions)
   - Bagaimana cara menjadi partner?
   - Apa keuntungan menjadi partner?
   - Berapa komisi yang didapat?
   - dll.

5. Support & Maintenance (5 questions)
   - Apakah ada support setelah project selesai?
   - Bagaimana cara request revisi?
   - dll.
```

---

### 9. BLOG (/blog)
**Features:**
- Blog post listing
- Category filter
- Tag filter
- Search blog
- Pagination
- Featured posts
- Related posts
- Share buttons
- Comment section

**Blog Post Template:**
```html
<article class="blog-post">
    <img src="featured-image.jpg" alt="">
    <div class="post-meta">
        <span class="category">SEO Tips</span>
        <span class="date">15 Nov 2025</span>
        <span class="author">Admin</span>
    </div>
    <h2>Post Title</h2>
    <p class="excerpt">
        Post excerpt...
    </p>
    <a href="/blog/post-slug" class="read-more">
        Baca Selengkapnya →
    </a>
</article>
```

---

### 10. TERMS & CONDITIONS (/terms)
**Features:**
- Terms of service
- User agreement
- Service guarantee
- Refund policy
- Intellectual property
- Limitation of liability
- Table of contents
- Print-friendly

**Key Sections:**
```
1. Ketentuan Umum
2. Layanan yang Ditawarkan
3. Proses Pemesanan
4. Pembayaran
5. Revisi & Perubahan
6. Hak Cipta & Kepemilikan
7. Jaminan Layanan
8. Kebijakan Refund
9. Batasan Tanggung Jawab
10. Perubahan Ketentuan
```

---

### 11. PRIVACY POLICY (/privacy)
**Features:**
- Privacy statement
- Data collection
- Data usage
- Cookie policy
- Third-party services
- Data security
- User rights
- Contact information

**Key Sections:**
```
1. Informasi yang Kami Kumpulkan
2. Bagaimana Kami Menggunakan Data
3. Penyimpanan Data
4. Keamanan Data
5. Cookie Policy
6. Layanan Pihak Ketiga
7. Hak Pengguna
8. Perubahan Kebijakan
9. Kontak
```

---

## 🎨 DESIGN COMPONENTS

### Reusable Components

**1. Header/Navbar**
- Sticky navigation
- Logo (clickable → home)
- Menu items (Home, About, Services, Pricing, Portfolio, Contact)
- Dropdown menu (Services → 10 divisions)
- Login button
- Register button (CTA style)
- Mobile hamburger menu
- Search icon (opens search modal)

**2. Footer**
- 5 columns layout
- Column 1: Company info + social media
- Column 2: Quick links
- Column 3: Services
- Column 4: Contact info
- Column 5: NIB badge
- Copyright notice
- Terms & Privacy links

**3. WhatsApp Float Button**
- Fixed position (bottom right)
- Green circle with WhatsApp icon
- Pulse animation
- Link to WhatsApp chat

**4. Back to Top Button**
- Appears after scroll 300px
- Fixed position (bottom left)
- Smooth scroll animation
- Arrow up icon

**5. Loading Spinner**
- Full screen overlay
- SITUNEO logo animation
- Progress text

**6. Toast Notifications**
- Success (green)
- Error (red)
- Warning (yellow)
- Info (blue)
- Auto-dismiss (3 seconds)

---

## 🎭 ANIMATIONS

### Page Load Animations (AOS)
```javascript
// Fade effects
data-aos="fade-up"
data-aos="fade-down"
data-aos="fade-left"
data-aos="fade-right"

// Zoom effects
data-aos="zoom-in"
data-aos="zoom-out"

// Flip effects
data-aos="flip-up"
data-aos="flip-down"
```

### GSAP Animations
```javascript
// Hero text animation
gsap.from(".hero-title", {
    opacity: 0,
    y: 100,
    duration: 1,
    ease: "power3.out"
});

// Counter animation
gsap.to(".counter", {
    innerText: targetValue,
    duration: 2,
    snap: { innerText: 1 }
});

// Parallax scrolling
gsap.to(".parallax-bg", {
    yPercent: 50,
    ease: "none",
    scrollTrigger: {
        trigger: ".parallax-section",
        scrub: true
    }
});
```

### CSS Animations
```css
/* Pulse effect (NIB badge) */
@keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

/* Fade in */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Slide in */
@keyframes slideInUp {
    from {
        transform: translateY(100px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}
```

---

## 📱 RESPONSIVE DESIGN

### Breakpoints
```css
/* Mobile First */
@media (min-width: 576px) { /* Small tablets */ }
@media (min-width: 768px) { /* Tablets */ }
@media (min-width: 992px) { /* Desktops */ }
@media (min-width: 1200px) { /* Large desktops */ }
```

### Mobile Optimizations
- Touch-friendly buttons (min 44px)
- Collapsible navigation
- Simplified layouts
- Optimized images (lazy loading)
- Reduced animations
- Easy-to-tap CTAs

---

## 🔍 SEO OPTIMIZATION

### Meta Tags (per page)
```html
<!-- Title -->
<title>Page Title | SITUNEO Digital</title>

<!-- Description -->
<meta name="description" content="Page description...">

<!-- Keywords -->
<meta name="keywords" content="keyword1, keyword2, keyword3">

<!-- Open Graph (Facebook) -->
<meta property="og:title" content="Page Title">
<meta property="og:description" content="Description">
<meta property="og:image" content="image.jpg">
<meta property="og:url" content="https://situneo.my.id/page">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Page Title">
<meta name="twitter:description" content="Description">
<meta name="twitter:image" content="image.jpg">

<!-- Canonical URL -->
<link rel="canonical" href="https://situneo.my.id/page">
```

### Structured Data (JSON-LD)
```html
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "SITUNEO Digital",
    "url": "https://situneo.my.id",
    "logo": "https://situneo.my.id/assets/img/logo.png",
    "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+62-831-7386-8915",
        "contactType": "Customer Service",
        "areaServed": "ID",
        "availableLanguage": ["id", "en"]
    },
    "sameAs": [
        "https://facebook.com/situneo",
        "https://instagram.com/situneo",
        "https://linkedin.com/company/situneo"
    ]
}
</script>
```

---

## ✅ SUCCESS CRITERIA

### Functionality Tests
- [ ] All 11 pages accessible
- [ ] Navigation working (all links)
- [ ] Forms submitting correctly
- [ ] Contact form sends email
- [ ] Search functionality working
- [ ] Filters working (services, portfolio, blog)
- [ ] Mobile menu working
- [ ] WhatsApp button working
- [ ] Back to top working

### Performance Tests
- [ ] Page load time < 3 seconds
- [ ] Images optimized (WebP format)
- [ ] CSS/JS minified
- [ ] Lazy loading images
- [ ] Google PageSpeed score > 90

### Responsive Tests
- [ ] Mobile (320px - 480px)
- [ ] Tablet (768px - 1024px)
- [ ] Desktop (1200px+)
- [ ] Touch gestures working
- [ ] No horizontal scroll

### SEO Tests
- [ ] All meta tags present
- [ ] Structured data valid
- [ ] Alt text on images
- [ ] Heading hierarchy correct (H1, H2, H3)
- [ ] Internal linking
- [ ] Sitemap generated
- [ ] robots.txt configured

### Cross-browser Tests
- [ ] Chrome
- [ ] Firefox
- [ ] Safari
- [ ] Edge
- [ ] Mobile browsers

---

## 📋 IMPLEMENTATION STEPS

### Day 1-2: Core Pages
1. Setup page structure
2. Create Home page
3. Create About page
4. Create Services page
5. Create Pricing page

### Day 3-4: Supporting Pages
6. Create Portfolio page
7. Create Testimonials page
8. Create Contact page
9. Create FAQ page
10. Create Blog page

### Day 5: Legal Pages
11. Create Terms page
12. Create Privacy page

### Day 6-7: Polish & Testing
13. Implement animations
14. Responsive testing
15. Cross-browser testing
16. SEO optimization
17. Performance optimization
18. Final QA testing

---

## 🚀 NEXT STEPS AFTER BATCH 3

Setelah Batch 3 selesai:
1. ✅ Batch 4: Authentication System (Login/Register/Reset)
2. ✅ Batch 5: Client Dashboard (20+ pages)
3. ✅ Batch 6: Partner Dashboard (30+ pages)

---

**Total Estimasi Batch 3: 5-7 hari kerja**  
**Output: 11 public pages, ~6000 lines code, Full responsive website**
