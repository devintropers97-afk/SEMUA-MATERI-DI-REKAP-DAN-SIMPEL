# 📦 BATCH 1: DATABASE SETUP - DETAIL LENGKAP

**Status:** 🔴 Belum Mulai  
**Prioritas:** 🔥 CRITICAL  
**Estimasi:** 3-5 hari kerja  
**Dependencies:** None (starting point)

---

## 🎯 TUJUAN

Membuat seluruh struktur database lengkap (85+ tables) dengan:
- Relasi yang benar antar tabel
- Indexes yang optimal untuk performance
- Foreign keys yang tepat
- Default values & constraints

---

## 📂 DELIVERABLES

### 1. Database Schema File
**File:** `/database/schema.sql`  
**Size:** ~5000 baris SQL  
**Includes:**
- 85+ CREATE TABLE statements
- All constraints (PRIMARY KEY, FOREIGN KEY, UNIQUE)
- All indexes (performance optimization)
- Default values & auto-increment
- Comments (explaining each table purpose)

### 2. Migration Scripts (20 Files)
```
/database/migrations/
├── 001_create_user_tables.sql (6 tables)
├── 002_create_client_tables.sql (6 tables)
├── 003_create_partner_tables.sql (10 tables)
├── 004_create_spv_tables.sql (8 tables)
├── 005_create_manager_tables.sql (8 tables)
├── 006_create_hierarchy_tables.sql (4 tables)
├── 007_create_service_tables.sql (7 tables)
├── 008_create_order_tables.sql (5 tables)
├── 009_create_payment_tables.sql (5 tables)
├── 010_create_demo_tables.sql (3 tables)
├── 011_create_commission_tables.sql (6 tables)
├── 012_create_withdrawal_tables.sql (4 tables)
├── 013_create_task_tables.sql (5 tables)
├── 014_create_cms_tables.sql (6 tables)
├── 015_create_leaderboard_tables.sql (4 tables)
├── 016_create_settings_tables.sql (5 tables)
├── 017_create_notification_tables.sql (3 tables)
├── 018_create_analytics_tables.sql (7 tables)
├── 019_create_support_tables.sql (3 tables)
└── 020_create_misc_tables.sql (5 tables)
```

### 3. Seed Data (Sample Data)
```
/database/seeds/
├── seed_admin.sql (Admin: vins@situneo.my.id)
├── seed_services.sql (232+ services catalog)
├── seed_packages.sql (3 packages)
├── seed_settings.sql (Default system settings)
├── seed_email_templates.sql (14 email templates)
└── seed_demo_data.sql (5 sample clients/partners)
```

### 4. Documentation
```
/database/documentation/
├── ERD.pdf (Visual schema diagram)
├── TABLE_REFERENCE.md (All tables + columns)
├── RELATIONS.md (Foreign keys explained)
└── INDEXES.md (Performance indexes)
```

---

## 🔐 DATABASE CREDENTIALS

```ini
DB_HOST=localhost
DB_USER=nrrskfvk_user_situneo_digital
DB_PASS=Devin1922$
DB_NAME=nrrskfvk_situneo_digital
DB_CHARSET=utf8mb4
DB_COLLATION=utf8mb4_unicode_ci
```

---

## 🗄️ KEY TABLES

### 1. users (Master User Table)
**Purpose:** Central user management untuk semua roles

**Columns:**
- id (PRIMARY KEY, AUTO_INCREMENT)
- role (admin, manager, spv, partner, client)
- username (UNIQUE)
- email (UNIQUE)
- password_hash
- phone
- full_name
- status (active, inactive, suspended, pending)
- language_preference (id, en)
- created_at, updated_at, last_login
- email_verified
- avatar

**Indexes:**
- idx_role
- idx_status
- idx_email

---

### 2. partners (Partner Management)
**Purpose:** Manage partner data dengan tier system

**Columns:**
- partner_id (PRIMARY KEY)
- user_id (FK to users)
- spv_id (FK to spv_supervisors)
- tier_current (1, 2, 3, MAX)
- total_orders_lifetime
- monthly_orders
- commission_balance
- commission_pending
- commission_paid_total
- referral_code (UNIQUE)
- status
- registered_at

**Business Logic:**
- Tier 1: 0-9 orders
- Tier 2: 10-49 orders
- Tier 3: 50-99 orders
- Tier MAX: 100+ orders

---

### 3. orders (Order Management)
**Purpose:** Track all client orders

**Columns:**
- order_id (PRIMARY KEY)
- client_id (FK to clients)
- partner_id (FK to partners)
- service_id (FK to services)
- package_id (FK to packages)
- order_type (beli_putus, sewa)
- total_pages
- total_amount
- status (pending, in_progress, testing, completed, cancelled)
- assigned_to
- created_at, completed_at
- deadline

**Status Flow:**
pending → in_progress → testing → completed

---

### 4. commissions (Commission System)
**Purpose:** Auto-calculate komisi berdasarkan tier & ARPU

**Columns:**
- commission_id (PRIMARY KEY)
- order_id (FK to orders)
- partner_id (FK to partners)
- tier_at_calculation
- arpu_value
- commission_rate (%)
- commission_amount
- status (pending, paid, cancelled)
- calculated_at, paid_at

**Commission Rates:**
- Tier 1: 10%
- Tier 2: 15%
- Tier 3: 20%
- Tier MAX: 25%

**ARPU Formula:**
```
ARPU = Total Order Value / Total Pages
If ARPU ≥ 3,500,000 → Bonus +5%
```

---

### 5. services (Service Catalog)
**Purpose:** 232+ layanan yang ditawarkan

**Columns:**
- service_id (PRIMARY KEY)
- division_id (10 divisions)
- service_name
- service_description
- base_price
- price_type (per_halaman, tetap)
- is_featured
- display_order
- status

**10 Divisions:**
1. Website Development
2. SEO & Digital Marketing
3. Social Media Management
4. Graphic Design & Branding
5. Video Production
6. E-commerce Solutions
7. Mobile App Development
8. Content Writing
9. IT Support & Maintenance
10. Custom Software Development

---

### 6. packages (Pricing Packages)
**Purpose:** 3 paket bundling layanan

**Packages:**
1. **Starter Package**
   - Harga: 5,000,000
   - Features: Basic website + SEO basic

2. **Business Package**
   - Harga: 15,000,000
   - Features: Advanced website + SEO + Social media

3. **Premium Package**
   - Harga: 35,000,000
   - Features: Complete solution + prioritas support

---

## 📊 TABLE GROUPS

### User Management (6 tables)
- users
- user_sessions
- user_login_history
- user_activity_logs
- user_notifications
- user_preferences

### Client Management (6 tables)
- clients
- client_projects
- client_domains
- client_hosting
- client_invoices
- client_support_tickets

### Partner Management (10 tables)
- partners
- partner_hierarchy
- partner_commissions
- partner_withdrawals
- partner_performance
- partner_targets
- partner_bonuses
- partner_referrals
- partner_training_progress
- partner_documents

### SPV Management (8 tables)
- spv_supervisors
- spv_teams
- spv_assignments
- spv_performance
- spv_reports
- spv_targets
- spv_team_performance
- spv_override_commissions

### Manager Management (8 tables)
- managers
- manager_departments
- manager_reports
- manager_approvals
- manager_targets
- manager_performance_reviews
- manager_team_metrics
- manager_budget_allocations

### Order & Service (12 tables)
- orders
- order_items
- order_status_history
- order_revisions
- services
- service_categories
- service_divisions
- packages
- package_services
- order_files
- order_notes
- order_timeline

### Financial (11 tables)
- payments
- payment_methods
- invoices
- invoice_items
- commissions
- commission_history
- withdrawals
- withdrawal_requests
- transactions
- wallet_balance
- refunds

### System & Settings (10 tables)
- settings
- system_logs
- email_templates
- email_logs
- notifications
- notification_preferences
- media_library
- file_uploads
- seo_settings
- analytics_tracking

### Content & Marketing (9 tables)
- cms_pages
- cms_posts
- cms_categories
- cms_tags
- testimonials
- portfolio_items
- portfolio_categories
- faqs
- blog_posts

### Demo & Tasks (8 tables)
- demo_requests (26 fields)
- demo_status_history
- demo_websites
- tasks
- task_assignments
- task_submissions
- task_reviews
- task_categories

### Support & Communication (6 tables)
- support_tickets
- support_responses
- support_categories
- chat_messages
- chat_rooms
- announcements

### Leaderboard & Gamification (4 tables)
- leaderboard_monthly
- leaderboard_yearly
- achievements
- badges

---

## ✅ SUCCESS CRITERIA

### Testing Checklist
- [ ] Database import tanpa error
- [ ] All tables created successfully (85+)
- [ ] All foreign keys working
- [ ] All indexes created
- [ ] Seed data inserted successfully
- [ ] Query test passed (10 test queries)
- [ ] Documentation complete
- [ ] ERD diagram generated

### 10 Test Queries
1. SELECT all users dengan role partner
2. JOIN partners dengan users
3. SELECT orders dengan status pending
4. CALCULATE total commission per partner
5. SELECT services by division
6. JOIN orders dengan clients
7. SELECT top 10 partners by orders
8. CALCULATE monthly revenue
9. SELECT pending withdrawals
10. JOIN demo_requests dengan clients

---

## 📋 IMPLEMENTATION STEPS

### Day 1-2: Core Tables
1. Create users table
2. Create clients table
3. Create partners table
4. Create orders table
5. Create services table
6. Create commissions table

### Day 2-3: Supporting Tables
7. Create payment tables (5)
8. Create SPV tables (8)
9. Create manager tables (8)
10. Create task tables (5)

### Day 3-4: Advanced Tables
11. Create demo tables (3)
12. Create CMS tables (6)
13. Create analytics tables (7)
14. Create support tables (3)
15. Create leaderboard tables (4)

### Day 4-5: Documentation & Testing
16. Generate ERD diagram
17. Write table reference documentation
18. Create seed data
19. Run test queries
20. Optimize indexes

---

## 🚀 NEXT STEPS AFTER BATCH 1

Setelah Batch 1 selesai:
1. ✅ Batch 2: Core System (Router, Config, Helpers)
2. ✅ Batch 3: Public Website (11 pages)
3. ✅ Batch 4: Authentication System
4. ✅ Batch 5: Client Dashboard

---

**Total Estimasi Batch 1: 3-5 hari kerja**  
**Output: 85+ tables, 5000+ lines SQL, Complete documentation**
