# 🚀 SITUNEO DIGITAL - QUICK GUIDE

**Baca ini dulu! 5 menit langsung paham.**

---

## 🎯 APA INI?

Platform jasa pembuatan website dengan sistem komisi bertingkat.

**Tagline:** "Website Paling Bagus & Paling Mahal Se-Indonesia!"

---

## 💰 MODEL BISNIS

### Harga ke Client:
- **Beli Putus:** Rp 350K/halaman
- **Sewa Bulanan:** Rp 150K/halaman/bulan (NO SETUP FEE!)

### Layanan:
- **232+ layanan** dalam 10 divisi
- **53 kategori** → 1500+ tipe website

---

## 👥 5 ROLE SYSTEM

1. **ADMIN** - Kontrol penuh
2. **MANAGER AREA** - 5% komisi + bonus ARPU
3. **SPV** - 10% komisi + bonus ARPU
4. **PARTNER** - 30-55% komisi (tier-based)
5. **CLIENT** - Order & tracking

---

## 💸 SISTEM KOMISI (CASCADE)

### Contoh Order Rp 10 Juta:
```
Client bayar: Rp 10,000,000
├─ Partner (40%): Rp 4,000,000
├─ SPV (10%): Rp 1,000,000
└─ Manager (5%): Rp 500,000
```

### Tier Partner:
- **Tier 1:** 0-10 order → 30%
- **Tier 2:** 10-25 order → 40%
- **Tier 3:** 50+ order → 50%
- **Tier MAX:** 75+ order → 55%

**Penting:** Tier TIDAK PERNAH TURUN!

---

## 🔗 REFERRAL SYSTEM

- Partner→Client: `situneo.my.id/register/client/USERNAME`
- SPV→Partner: `situneo.my.id/register/partner/USERNAME`
- Manager→SPV: `situneo.my.id/register/spv/USERNAME`

---

## 🎨 50 DEMO WEBSITES

**Production-ready demos:**
- Real business names
- Real content (bukan dummy)
- Unsplash images
- Design premium

**Top 10:**
1. Toko Baju Modis Jakarta
2. Restoran Nusantara Enak
3. Klinik Sehat Keluarga
4. Konsultan Bisnis Profesional
5. Kursus Online Berkualitas
6. Laundry Express Cepat
7. Properti Rumah Impian
8. Cuci Mobil Premium Shine
9. Service Laptop Cepat Aman
10. Hotel Grand Jakarta

---

## 🔧 CARA BUILD (CLAUDE CODE)

### 1. Install Claude Code:
```bash
curl -fsSL https://claude.ai/install.sh | sh
```

### 2. Login:
```bash
claude auth login
```

### 3. Create Project:
```bash
mkdir situneo-digital
cd situneo-digital
```

### 4. Buat BUILD_INSTRUCTIONS.md (copy dari file asli)

### 5. Run:
```bash
claude code "Baca file BUILD_INSTRUCTIONS.md dan buat COMPLETE SITUNEO Digital Platform..."
```

### 6. Wait 30-60 minutes

### 7. Deploy ke cPanel!

---

## ✅ HASIL AKHIR

```
400+ files modular
85 database tables
50 demo websites
5 complete dashboards
Full automation
Complete security
Production-ready!
```

---

## 📞 INFO PERUSAHAAN

**PT SITUNEO DIGITAL SOLUSI INDONESIA**
- NIB: 20250-9261-4570-4515-5453
- Website: https://situneo.my.id
- Email: admin@situneo.my.id

---

## 🎯 TARGET KUALITAS

✅ Design: WOW factor, premium  
✅ Performance: <3 detik loading  
✅ Mobile: Perfect responsive  
✅ Security: Complete protection  
✅ SEO: Fully optimized  
✅ Code: Clean & modular  

---

**SELESAI! Baca file lain untuk detail teknis.**
