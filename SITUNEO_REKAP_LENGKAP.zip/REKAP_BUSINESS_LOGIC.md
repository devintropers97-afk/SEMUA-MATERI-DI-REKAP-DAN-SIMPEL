# 💰 SITUNEO DIGITAL - BUSINESS LOGIC & COMMISSION SYSTEM

**Logika bisnis lengkap, sistem komisi, dan automation.**

---

## 💼 MODEL BISNIS

### Pricing ke Client:

#### 1. Beli Putus (One-time Purchase)
```
Rp 350,000 per halaman
✅ Full ownership
✅ Source code included
✅ Lifetime support (maintenance available)
✅ Komisi dibayar setelah: LUNAS + SERAH TERIMA + ADMIN APPROVE
```

#### 2. Sewa Bulanan (Monthly Subscription)
```
Rp 150,000 per halaman/bulan
✅ NO SETUP FEE!
✅ Maintenance included
✅ Hosting included
✅ Client wajib min 3 bulan
✅ Komisi dibayar 1x di bulan pertama
⚠️  Stop <3 bulan: Partner kena potong komisi (cascade ke SPV/Manager)
```

### Contoh Perhitungan:

**Website 5 Halaman:**
- Beli Putus: 5 × Rp 350K = **Rp 1,750,000**
- Sewa Bulanan: 5 × Rp 150K = **Rp 750,000/bulan**

---

## 👥 HIERARCHY SYSTEM (5 ROLES)

```
ADMIN (Full Control)
  │
  ├── MANAGER AREA (5% komisi + bonus ARPU)
  │     │
  │     └── SPV (10% komisi + bonus ARPU)
  │           │
  │           └── PARTNER (30-55% komisi, tier-based)
  │                 │
  │                 └── CLIENT (Order & tracking)
```

### Role Permissions:

#### 1. ADMIN
```
✅ Full control everything
✅ Approve/reject partner applications
✅ Approve/reject orders
✅ Calculate & release commissions
✅ Approve withdrawals
✅ Post tasks
✅ Manage website settings
✅ View all reports
```

#### 2. MANAGER AREA
```
✅ View area performance
✅ View team hierarchy (SPV + Partners)
✅ Track ARPU (Rp 45M/105M/225M/600M targets)
✅ View earnings (5% + bonus)
✅ Request withdrawals
✅ Referral SPV (link: situneo.my.id/register/spv/USERNAME)
✅ View leaderboard
```

#### 3. SPV (Supervisor)
```
✅ View team performance (Partners under them)
✅ Track ARPU (Rp 15M/35M/75M/200M targets)
✅ View earnings (10% + bonus)
✅ Request withdrawals
✅ Referral Partners (link: situneo.my.id/register/partner/USERNAME)
✅ View leaderboard
```

#### 4. PARTNER
```
✅ View earnings (30-55%, tier-based)
✅ View tier progress
✅ Request withdrawals (min Rp 50K)
✅ Referral Clients (link: situneo.my.id/register/client/USERNAME)
✅ Apply for tasks
✅ Submit task results
✅ View leaderboard (public)
```

#### 5. CLIENT
```
✅ Create orders
✅ Upload payment proof
✅ Request demo (26 fields form)
✅ View invoices (format: INV-SITUNEO-DD-MMM-YYYY)
✅ Track order status
```

---

## 💸 COMMISSION SYSTEM (CASCADE)

### Tier System untuk Partner:

| Tier | Total Orders | Commission Rate | Status |
|------|-------------|-----------------|--------|
| **Tier 1** | 0 - 10 | **30%** | Starter |
| **Tier 2** | 10 - 25 | **40%** | Rising |
| **Tier 3** | 50+ | **50%** | Expert |
| **Tier MAX** | 75+ | **55%** | Champion |

**PENTING:** 
- Tier TIDAK PERNAH TURUN! (Maintenance)
- Upgrade otomatis saat mencapai target
- Dihitung dari total orders (bukan revenue)

### Cascade Distribution:

```
Client Order: Rp 10,000,000

Hierarchy:
Client
  └── Partner (Tier 2: 40%) = Rp 4,000,000
        └── SPV (10%) = Rp 1,000,000
              └── Manager (5%) = Rp 500,000

Total Commission: Rp 5,500,000 (55%)
Company Profit: Rp 4,500,000 (45%)
```

### Commission Rules:

#### Beli Putus:
```
1. Client order
2. Client upload payment proof
3. Admin verify payment
4. Website development
5. Serah terima (delivery)
6. Admin approve order
7. ✅ COMMISSION CALCULATED & RELEASED
```

#### Sewa Bulanan:
```
1. Client order (min 3 bulan commitment)
2. Client bayar bulan 1
3. Admin verify
4. ✅ COMMISSION PAID (1x untuk bulan pertama)
5. Bulan 2-3: No commission (goes to company)
6. If client stop <3 bulan:
   - Partner commission CUT
   - Commission CASCADE to SPV/Manager (mereka tetap dapat)
```

---

## 🎯 ARPU BONUS SYSTEM

### Manager ARPU Targets:

| Tier | ARPU Target | Bonus |
|------|-------------|-------|
| Bronze | Rp 45,000,000 | Rp 2,000,000 |
| Silver | Rp 105,000,000 | Rp 5,000,000 |
| Gold | Rp 225,000,000 | Rp 12,000,000 |
| Platinum | Rp 600,000,000 | Rp 35,000,000 |

### SPV ARPU Targets:

| Tier | ARPU Target | Bonus |
|------|-------------|-------|
| Bronze | Rp 15,000,000 | Rp 500,000 |
| Silver | Rp 35,000,000 | Rp 1,500,000 |
| Gold | Rp 75,000,000 | Rp 4,000,000 |
| Platinum | Rp 200,000,000 | Rp 12,000,000 |

**ARPU Calculation:**
```
ARPU = Total Revenue dari Team / Periode Waktu
```

**Update:**
- Real-time per order
- Dashboard shows current ARPU
- Progress bar to next tier
- Auto-bonus saat target tercapai

---

## 🔗 REFERRAL SYSTEM (3 TYPES)

### 1. Manager → SPV
```
URL: https://situneo.my.id/register/spv/MANAGER_USERNAME

Process:
1. Manager share link
2. SPV register via link
3. SPV uploaded KTP + CV
4. Admin review & approve
5. Hierarchy link created: SPV → Manager
6. SPV can now refer Partners
```

### 2. SPV → Partner
```
URL: https://situneo.my.id/register/partner/SPV_USERNAME

Process:
1. SPV share link
2. Partner register via link
3. Partner upload KTP + CV
4. Admin review & approve
5. Hierarchy link created: Partner → SPV → Manager
6. Partner can now refer Clients
```

### 3. Partner → Client
```
URL: https://situneo.my.id/register/client/PARTNER_USERNAME

Process:
1. Partner share link
2. Client register via link
3. No approval needed (instant)
4. Hierarchy link created: Client → Partner → SPV → Manager
5. Client can order immediately
```

### Referral Tracking:

Dashboard shows:
```
✅ Total referrals
✅ Active referrals
✅ Pending approvals
✅ Revenue from referrals
✅ Commission earned from referrals
```

---

## 💳 WITHDRAWAL SYSTEM

### Requirements:
```
Minimum: Rp 50,000
Processing: 1-3 hari kerja
Methods: Bank Transfer (BCA, Mandiri, BRI, BNI)
```

### Process:
```
1. User request withdrawal
   - Amount: min Rp 50K
   - Bank details: Bank name, account number, account name
   
2. Auto email to User + Admin
   - User: "Permintaan withdrawal sedang diproses"
   - Admin: "New withdrawal request from [Name]"
   
3. Admin review & approve
   - Check balance
   - Verify bank details
   - Approve/reject
   
4. If approved:
   - Balance deducted
   - Status: Completed
   - Email: "Transfer completed"
   
5. If rejected:
   - Balance unchanged
   - Status: Rejected
   - Email: "Withdrawal rejected" (with reason)
```

### Dashboard:
```
✅ Current balance
✅ Total withdrawn
✅ Pending withdrawals
✅ Withdrawal history (with status)
✅ Quick withdraw button
```

---

## 📋 DEMO REQUEST FORM (26 FIELDS)

### Bagian 1: Tentang Usaha (3 fields)
```
1. Jenis Usaha: [Dropdown 53 kategori]
2. Nama Usaha: [Text]
3. Deskripsi Usaha: [Textarea]
```

### Bagian 2: Tampilan Website (3 fields)
```
4. Warna Utama: [Color picker]
5. Warna Sekunder: [Color picker]
6. Referensi Design: [URL]
```

### Bagian 3: Halaman yang Dibutuhkan (2 fields)
```
7. Jumlah Halaman: [Number]
8. Detail Halaman: [Textarea - list halaman]
```

### Bagian 4: Fitur Khusus (2 fields)
```
9. Fitur Wajib: [Checkboxes: Form kontak, WhatsApp, Maps, dll]
10. Fitur Tambahan: [Textarea]
```

### Bagian 5: Gambar & Logo (2 fields)
```
11. Upload Logo: [File - max 2MB, JPG/PNG]
12. Upload Gambar Produk: [Multiple files - max 5 files]
```

### Bagian 6: Konten & Kontak (5 fields)
```
13. Alamat Lengkap: [Textarea]
14. Nomor WhatsApp: [Text]
15. Email: [Email]
16. Instagram: [Text]
17. Facebook: [Text]
```

### Bagian 7: Preferensi & Catatan (2 fields)
```
18. Paket: [Radio: Beli Putus / Sewa Bulanan]
19. Target Selesai: [Date]
20. Budget: [Number]
21. Catatan Tambahan: [Textarea]
```

### 7 Fields Tambahan (Custom):
```
22. Kompetitor Website: [URL]
23. Target Audience: [Text]
24. Fitur Prioritas: [Dropdown]
25. Domain (Jika ada): [Text]
26. Referensi Lain: [Textarea]
```

### "Copy Detail" Button (Admin Only):
```
Location: Admin → Demo Requests → Detail

Function: Copy semua 26 fields dalam format structured text

Format Output:
---
DEMO REQUEST DETAILS
Request ID: #12345
Client: John Doe
Date: 12 Nov 2025

TENTANG USAHA
- Jenis: Toko Online
- Nama: Toko Baju Modis
- Deskripsi: [...]

TAMPILAN
- Warna Utama: #1E5C99
- Warna Sekunder: #FFB400
- Referensi: https://example.com

[... semua fields ...]
---

Button Label: "Salin Data" (bukan "Copy for AI" - lebih subtle)
```

---

## 🏆 PUBLIC LEADERBOARD (No Login Required)

### URL:
```
https://situneo.my.id/leaderboard/partners
https://situneo.my.id/leaderboard/spv
https://situneo.my.id/leaderboard/managers
```

### Display (Top 10):

#### Partners Leaderboard:
```
Rank | Name | Tier | Orders | Revenue | Commission Earned
-----|------|------|--------|---------|------------------
1    | John | MAX  | 120    | 50M     | 25M
2    | Jane | 3    | 85     | 30M     | 15M
...
```

#### SPV Leaderboard:
```
Rank | Name | Team Size | Orders | ARPU | Bonus Tier
-----|------|-----------|--------|------|------------
1    | Mike | 25        | 350    | 180M | Platinum
2    | Sarah| 18        | 250    | 120M | Gold
...
```

#### Manager Leaderboard:
```
Rank | Name | Area | Team Size | Orders | ARPU | Bonus Tier
-----|------|------|-----------|--------|------|------------
1    | Alex | Jabodetabek | 150 | 1200 | 650M | Platinum
2    | Lisa | Jawa Barat  | 120 | 950  | 480M | Gold
...
```

### Features:
```
✅ Real-time updates (auto refresh every 5 min)
✅ Responsive design
✅ Search by name
✅ Filter by tier
✅ Export to PDF
✅ Share buttons (Twitter, LinkedIn)
```

---

## 📝 ADMIN TASK SYSTEM

### Task Posting (Admin):
```
1. Admin create task
   - Title
   - Description
   - Requirements
   - Payment: Rp [amount]
   - Deadline: [date]
   - Max applicants: [number]

2. Task published
   - Visible to all Partners
   - Status: Open

3. Partners apply
   - View task details
   - Click "Apply"
   - Write proposal (optional)

4. Admin review applications
   - View applicant profiles
   - Check tier, orders, rating
   - Approve & assign

5. Partner completes task
   - Upload result (file/link)
   - Submit for review

6. Admin review result
   - Approve: Release payment
   - Reject: Request revision
   - Complete: Task closed

7. Payment released
   - Added to Partner balance
   - Email notification
   - Commission NO cascade (task payment = direct)
```

### Task Dashboard (Partner):
```
✅ Available Tasks (can apply)
✅ Applied Tasks (waiting approval)
✅ Assigned Tasks (in progress)
✅ Completed Tasks (history)
✅ Total task earnings
```

---

## 📧 EMAIL AUTOMATION (11 TYPES)

### 1. Registration Confirmation
```
Subject: Selamat Datang di SITUNEO Digital!
Content: Akun berhasil dibuat, verify email
```

### 2. Partner Application Submitted
```
Subject: Aplikasi Partner Diterima
Content: Aplikasi sedang direview (1-3 hari)
```

### 3. Partner Approved
```
Subject: Selamat! Aplikasi Partner Disetujui
Content: Akun aktif, mulai referral clients
```

### 4. Partner Rejected
```
Subject: Aplikasi Partner Ditolak
Content: Alasan + cara apply ulang
```

### 5. Order Notification
```
Subject: Order Baru #12345
Content: Detail order + instruksi pembayaran
```

### 6. Payment Received
```
Subject: Pembayaran Diterima
Content: Konfirmasi + timeline pengerjaan
```

### 7. Order Completed
```
Subject: Website Anda Sudah Siap!
Content: URL + credentials + panduan
```

### 8. Commission Earned
```
Subject: Komisi Rp 4,000,000 Diterima!
Content: Breakdown + balance + withdraw info
```

### 9. Withdrawal Requested
```
Subject: Permintaan Withdrawal Rp 500,000
Content: Sedang diproses (1-3 hari)
```

### 10. Withdrawal Approved
```
Subject: Transfer Berhasil!
Content: Bank details + completion time
```

### 11. Demo Request Submitted
```
Subject: Demo Request Diterima
Content: Timeline + next steps
```

---

## 🔄 AUTOMATION CHECKLIST

### Real-time Automation:
```
âœ… Commission calculation (after admin approve order)
âœ… ARPU tracking (update per order)
âœ… Tier progression (auto upgrade when target reached)
âœ… Balance update (after commission/withdrawal)
âœ… Hierarchy linking (after registration via referral)
âœ… Email sending (11 types auto-trigger)
âœ… Invoice generation (format: INV-SITUNEO-DD-MMM-YYYY)
âœ… Leaderboard ranking (real-time update)
```

### Scheduled Tasks (Cron Jobs):
```
âœ… Daily: Update ARPU (00:00 WIB)
âœ… Daily: Check sewa bulanan status (00:00 WIB)
âœ… Weekly: Generate reports (Monday 00:00 WIB)
âœ… Monthly: Calculate ARPU bonus (1st of month)
âœ… Monthly: Send payment reminders (5th of month)
```

---

## 🎯 BUSINESS GOALS

### Revenue Targets (Year 1):
```
Q1: Rp 500,000,000
Q2: Rp 1,000,000,000
Q3: Rp 2,000,000,000
Q4: Rp 5,000,000,000
```

### Team Targets (Year 1):
```
Managers: 10
SPV: 50
Partners: 500
Clients: 2000+
```

### Key Metrics:
```
✅ Average Order Value: Rp 3,500,000
✅ Conversion Rate: 15%
✅ Customer Retention: 80%
✅ Partner Activity: 70%
✅ On-time Delivery: 95%
```

---

**Complete business logic! ✅**
