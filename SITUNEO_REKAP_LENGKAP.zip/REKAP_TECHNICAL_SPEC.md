# 🔧 SITUNEO DIGITAL - TECHNICAL SPECIFICATIONS

**Spesifikasi teknis lengkap untuk development.**

---

## 📊 DATABASE (85 TABLES)

### Breakdown by Category:

1. **Users & Auth (6 tables)**
   - users, user_sessions, user_roles, user_permissions, user_logs, password_resets

2. **Clients (6 tables)**
   - clients, client_orders, client_payments, client_invoices, client_demos, client_activity

3. **Partners (10 tables)**
   - partners, partner_applications, partner_documents, partner_earnings, partner_withdrawals, partner_referrals, partner_tiers, partner_tasks, partner_submissions, partner_activity

4. **SPV (8 tables)**
   - spv, spv_team, spv_earnings, spv_arpu, spv_referrals, spv_withdrawals, spv_bonuses, spv_activity

5. **Managers (8 tables)**
   - managers, manager_areas, manager_team, manager_earnings, manager_arpu, manager_referrals, manager_withdrawals, manager_bonuses

6. **Hierarchy (4 tables)**
   - hierarchy_links, hierarchy_tree, hierarchy_commissions, hierarchy_history

7. **Services (7 tables)**
   - services, service_categories, service_divisions, service_packages, service_pricing, service_addons, service_faqs

8. **Orders (5 tables)**
   - orders, order_items, order_status, order_timeline, order_files

9. **Payments (5 tables)**
   - payments, payment_methods, payment_proofs, payment_history, invoices

10. **Demos (3 tables)**
    - demo_websites, demo_requests, demo_categories

11. **Commissions (6 tables)**
    - commissions, commission_rules, commission_cascade, commission_history, commission_adjustments, commission_reports

12. **Withdrawals (4 tables)**
    - withdrawals, withdrawal_methods, withdrawal_history, withdrawal_limits

13. **Tasks (5 tables)**
    - tasks, task_applications, task_assignments, task_submissions, task_reviews

14. **Content (6 tables)**
    - pages, posts, media, banners, popups, faqs

15. **Leaderboard (4 tables)**
    - leaderboard_partners, leaderboard_spv, leaderboard_managers, leaderboard_history

16. **Settings (5 tables)**
    - site_settings, commission_settings, email_settings, payment_settings, security_settings

17. **Notifications (3 tables)**
    - notifications, email_queue, email_logs

18. **Analytics (7 tables)**
    - analytics_visits, analytics_orders, analytics_revenue, analytics_conversions, analytics_referrals, analytics_demos, analytics_reports

19. **Support (3 tables)**
    - tickets, ticket_replies, ticket_attachments

20. **SEO (3 tables)**
    - seo_meta, seo_redirects, seo_sitemap

21. **Media (2 tables)**
    - uploads, upload_categories

---

## 🎨 DESIGN SYSTEM

### Color Palette:
```css
:root {
  /* Primary Colors */
  --primary-blue: #1E5C99;
  --dark-blue: #0F3057;
  --gold: #FFB400;
  --bright-gold: #FFD700;
  
  /* Neutral Colors */
  --white: #FFFFFF;
  --light-gray: #F5F5F5;
  --medium-gray: #CCCCCC;
  --dark-gray: #333333;
  
  /* Status Colors */
  --success: #28A745;
  --warning: #FFC107;
  --danger: #DC3545;
  --info: #17A2B8;
}
```

### Typography:
```css
/* Fonts */
--font-body: 'Inter', sans-serif;
--font-heading: 'Plus Jakarta Sans', sans-serif;

/* Font Sizes */
--fs-hero: 3.5rem;
--fs-h1: 2.5rem;
--fs-h2: 2rem;
--fs-h3: 1.5rem;
--fs-body: 1rem;
--fs-small: 0.875rem;
```

### Animations (MANDATORY on ALL pages):
```javascript
// 1. Network Particle Background (30-40 particles)
initNetworkParticles(30);

// 2. Dynamic Loading Screen
showLoadingScreen('Memuat Dashboard...');

// 3. NIB Badge (Footer, Medium, Pulse)
addNIBBadge('footer', 'medium', 'pulse');

// 4. Circuit Pattern Overlay
applyCircuitPattern();

// 5. AOS (Animate On Scroll)
AOS.init({duration: 800, once: true});

// 6. GSAP (Smooth Animations)
gsap.from('.card', {y: 50, opacity: 0, stagger: 0.1});
```

---

## 📁 FILE STRUCTURE (400+ FILES)

```
situneo-digital/
├── config/
│   ├── database.php (PDO connection)
│   ├── constants.php (global constants)
│   ├── settings.php (site settings)
│   ├── email.php (SMTP config)
│   ├── paths.php (directory paths)
│   ├── session.php (session config)
│   └── security.php (security settings)
│
├── includes/
│   ├── header.php (global header)
│   ├── footer.php (with NIB badge)
│   ├── navigation.php (role-based nav)
│   └── components/
│       ├── loading.php
│       ├── particles.php
│       ├── modal.php
│       ├── alert.php
│       └── whatsapp-button.php
│
├── helpers/
│   ├── common.php (common functions)
│   ├── validation.php (input validation)
│   ├── formatting.php (format data)
│   ├── security.php (CSRF, XSS prevention)
│   ├── email.php (email sending)
│   └── upload.php (file upload)
│
├── core/
│   ├── Database.php (PDO wrapper)
│   ├── Router.php (URL routing)
│   ├── Session.php (session management)
│   ├── Auth.php (authentication)
│   ├── Validator.php (validation)
│   ├── Mailer.php (email sending)
│   └── Uploader.php (file upload)
│
├── assets/
│   ├── css/
│   │   ├── main.css (global styles)
│   │   ├── dashboard.css (dashboard styles)
│   │   ├── animations.css (animations)
│   │   └── responsive.css (media queries)
│   ├── js/
│   │   ├── main.js (global JS)
│   │   ├── particles.js (network particles)
│   │   ├── animations.js (GSAP, AOS)
│   │   ├── ajax.js (AJAX functions)
│   │   └── validation.js (form validation)
│   ├── images/
│   │   ├── logo.png
│   │   ├── nib-badge.png
│   │   └── ... (other images)
│   └── uploads/
│       ├── ktp/
│       ├── cv/
│       ├── payments/
│       └── demos/
│
├── auth/
│   ├── login.php
│   ├── register-client.php
│   ├── register-partner.php (with KTP/CV upload)
│   ├── logout.php
│   ├── forgot-password.php
│   └── reset-password.php
│
├── client/
│   ├── dashboard.php
│   ├── orders/
│   │   ├── index.php
│   │   ├── create.php
│   │   ├── detail.php
│   │   └── history.php
│   ├── demo-request.php (26 fields form)
│   ├── payments/
│   │   ├── index.php
│   │   ├── upload-proof.php
│   │   └── history.php
│   ├── invoices/
│   │   ├── index.php
│   │   └── download.php
│   └── profile.php
│
├── partner/
│   ├── dashboard.php
│   ├── earnings/
│   │   ├── index.php
│   │   ├── history.php
│   │   └── details.php
│   ├── referral/
│   │   ├── link.php
│   │   └── statistics.php
│   ├── withdrawal/
│   │   ├── request.php
│   │   ├── history.php
│   │   └── methods.php
│   ├── tier/
│   │   ├── current.php
│   │   └── progress.php
│   ├── tasks/
│   │   ├── available.php
│   │   ├── apply.php
│   │   ├── assigned.php
│   │   └── submit.php
│   ├── leaderboard.php
│   └── profile.php
│
├── spv/
│   ├── dashboard.php
│   ├── team/
│   │   ├── partners.php
│   │   ├── performance.php
│   │   └── hierarchy.php
│   ├── earnings/
│   │   ├── index.php
│   │   ├── commissions.php
│   │   └── bonuses.php
│   ├── arpu-tracking.php
│   ├── referral/
│   │   ├── link.php
│   │   └── statistics.php
│   ├── withdrawal/
│   │   ├── request.php
│   │   └── history.php
│   └── profile.php
│
├── manager/
│   ├── dashboard.php
│   ├── area-management/
│   │   ├── overview.php
│   │   └── statistics.php
│   ├── team/
│   │   ├── spv.php
│   │   ├── partners.php
│   │   └── hierarchy.php
│   ├── earnings/
│   │   ├── index.php
│   │   ├── commissions.php
│   │   └── bonuses.php
│   ├── arpu-tracking.php
│   ├── referral/
│   │   ├── link.php
│   │   └── statistics.php
│   ├── withdrawal/
│   │   ├── request.php
│   │   └── history.php
│   └── profile.php
│
├── admin/
│   ├── dashboard.php
│   ├── users/
│   │   ├── index.php
│   │   ├── create.php
│   │   ├── edit.php
│   │   └── delete.php
│   ├── hierarchy/
│   │   ├── view.php
│   │   └── manage.php
│   ├── services/
│   │   ├── index.php
│   │   ├── categories.php
│   │   ├── divisions.php
│   │   └── pricing.php
│   ├── orders/
│   │   ├── index.php
│   │   ├── detail.php
│   │   ├── approve.php
│   │   └── complete.php
│   ├── payments/
│   │   ├── index.php
│   │   ├── verify.php
│   │   └── history.php
│   ├── partners/
│   │   ├── applications.php (review KTP/CV)
│   │   ├── approve.php
│   │   ├── reject.php
│   │   └── manage.php
│   ├── commissions/
│   │   ├── overview.php
│   │   ├── calculate.php
│   │   ├── history.php
│   │   └── reports.php
│   ├── demo-requests/
│   │   ├── index.php
│   │   ├── detail.php (with Copy Detail button)
│   │   └── assign.php
│   ├── withdrawals/
│   │   ├── requests.php
│   │   ├── approve.php
│   │   └── history.php
│   ├── tasks/
│   │   ├── post.php
│   │   ├── applications.php
│   │   ├── assign.php
│   │   ├── review.php
│   │   └── payment.php
│   ├── website/
│   │   ├── settings.php
│   │   ├── pages.php
│   │   ├── banners.php
│   │   └── popups.php
│   ├── reports/
│   │   ├── revenue.php
│   │   ├── orders.php
│   │   ├── commissions.php
│   │   └── analytics.php
│   └── settings/
│       ├── general.php
│       ├── commission.php
│       ├── email.php
│       ├── payment.php
│       └── security.php
│
├── demos/
│   ├── toko-baju/
│   │   ├── index.php
│   │   ├── about.php
│   │   ├── products.php
│   │   ├── contact.php
│   │   ├── assets/
│   │   └── images/
│   ├── restoran/
│   └── ... (48 more demos)
│
├── leaderboard/ (PUBLIC - no login required)
│   ├── partners.php
│   ├── spv.php
│   └── managers.php
│
├── database/
│   ├── situneo_complete.sql (85 tables)
│   ├── schema.sql (structure only)
│   ├── test_data.sql (test accounts)
│   └── migrations/
│
├── .htaccess (security rules)
├── .env.example (environment variables)
├── README.md (installation guide)
└── index.php (main entry point)
```

---

## 🔐 SECURITY FEATURES (MANDATORY)

### 1. Password Security:
```php
// Hashing (bcrypt)
$hashed = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

// Verification
if (password_verify($input, $hashed)) {
    // Login success
}
```

### 2. CSRF Protection:
```php
// Generate token
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// Validate token
if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die('CSRF token mismatch');
}
```

### 3. SQL Injection Prevention:
```php
// Prepared statements
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
```

### 4. XSS Prevention:
```php
// Output escaping
echo htmlspecialchars($user_input, ENT_QUOTES, 'UTF-8');
```

### 5. File Upload Validation:
```php
// Size, type, extension checks
$allowed = ['jpg', 'jpeg', 'png', 'pdf'];
$max_size = 2 * 1024 * 1024; // 2MB
```

### 6. Session Security:
```php
// Session config
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_samesite', 'Strict');
```

### 7. Rate Limiting:
```php
// Login attempts
if ($attempts > 5) {
    // Lock account for 15 minutes
}
```

### 8. .htaccess Rules:
```apache
# Block access to sensitive files
<FilesMatch "\.(env|sql|md)$">
    Order allow,deny
    Deny from all
</FilesMatch>

# Prevent directory listing
Options -Indexes

# Enable HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

---

## ⚡ PERFORMANCE OPTIMIZATION

### 1. Image Optimization:
- WebP format (fallback JPG/PNG)
- Auto-compress on upload
- Lazy loading
- Responsive images

### 2. CSS/JS Optimization:
- Minification
- Concatenation
- CDN for libraries
- Async/defer loading

### 3. Database Optimization:
- Proper indexing
- Query optimization
- Connection pooling
- Caching (Redis/Memcached)

### 4. Browser Caching:
```apache
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

### 5. Target Performance:
- ✅ Loading time: <3 seconds
- ✅ First Contentful Paint: <1.5s
- ✅ Time to Interactive: <2.5s
- ✅ Lighthouse score: >90

---

## 📧 EMAIL NOTIFICATIONS (11 TYPES - AUTO)

### 1. Registration Confirmation
**Trigger:** User register  
**To:** New user  
**Content:** Welcome, verify email

### 2. Partner Application Submitted
**Trigger:** Partner submit application  
**To:** Partner + Admin  
**Content:** Application received, pending review

### 3. Partner Approved/Rejected
**Trigger:** Admin approve/reject  
**To:** Partner  
**Content:** Status + next steps

### 4. Order Notification
**Trigger:** Client create order  
**To:** Client + Admin  
**Content:** Order details, payment instructions

### 5. Payment Received
**Trigger:** Payment verified  
**To:** Client  
**Content:** Payment confirmed, order processing

### 6. Order Completed
**Trigger:** Admin mark complete  
**To:** Client  
**Content:** Website ready, credentials

### 7. Commission Earned
**Trigger:** Admin approve order + commission calculated  
**To:** Partner + SPV + Manager  
**Content:** Commission details, breakdown

### 8. Withdrawal Requested
**Trigger:** User request withdrawal  
**To:** User + Admin  
**Content:** Request received, processing

### 9. Withdrawal Approved
**Trigger:** Admin approve withdrawal  
**To:** User  
**Content:** Transfer details, completion time

### 10. Password Reset
**Trigger:** User request reset  
**To:** User  
**Content:** Reset link (expires 1 hour)

### 11. Demo Request Submitted
**Trigger:** Client request demo  
**To:** Client + Admin  
**Content:** Request received, timeline

---

## 🎯 SEO IMPLEMENTATION

### 1. Meta Tags (Every Page):
```html
<title>Page Title - SITUNEO Digital</title>
<meta name="description" content="Page description...">
<meta name="keywords" content="keywords, here">
<meta name="author" content="SITUNEO Digital">
<meta name="robots" content="index, follow">
<link rel="canonical" href="https://situneo.my.id/page">
```

### 2. Open Graph:
```html
<meta property="og:type" content="website">
<meta property="og:title" content="Page Title">
<meta property="og:description" content="Description">
<meta property="og:image" content="image.jpg">
<meta property="og:url" content="https://situneo.my.id/page">
```

### 3. Schema Markup (JSON-LD):
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "SITUNEO Digital",
  "url": "https://situneo.my.id",
  "logo": "https://situneo.my.id/assets/images/logo.png"
}
</script>
```

### 4. Google Analytics:
```html
<!-- G-RPW3MZ3RPY -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-RPW3MZ3RPY"></script>
```

### 5. Sitemap & Robots:
- `sitemap.xml` (auto-generated)
- `robots.txt` (configured)

---

## 🧪 TEST ACCOUNTS

```
Admin:
Email: admin@situneo.my.id
Password: admin123

Client:
Email: client@situneo.my.id
Password: client123

Partner:
Email: partner@situneo.my.id
Password: partner123

SPV:
Email: spv@situneo.my.id
Password: spv123

Manager:
Email: manager@situneo.my.id
Password: manager123
```

---

**Complete technical specifications! ✅**
