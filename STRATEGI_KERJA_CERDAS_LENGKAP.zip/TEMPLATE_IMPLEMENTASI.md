# 🔧 TEMPLATE IMPLEMENTASI - LANGKAH PRAKTIS

## 📝 CHECKLIST IMPLEMENTASI

### PHASE 1: PERSIAPAN
```
□ Identifikasi semua files yang dibutuhkan
□ Kelompokkan berdasarkan kesamaan
□ Tentukan base templates yang diperlukan
□ Buat daftar components reusable
```

### PHASE 2: FOUNDATION (5-6 Tool Calls)
```
□ Create base template admin-page.php
□ Create base template client-page.php
□ Create base template auth-page.php
□ Generate config files (database, settings, routes)
□ Generate core functions (auth, validation, helpers)
□ Setup design system (CSS framework, JS utilities)
```

**Estimasi:** 10-15 menit

---

### PHASE 3: COMPONENTS (4-5 Tool Calls)
```
□ Create header component
□ Create footer component
□ Create modal components (CRUD, confirm, alert)
□ Create form components (login, register, profile)
□ Create widget components (stats, charts, tables)
```

**Estimasi:** 10 menit

---

### PHASE 4: PAGES (8-10 Tool Calls)
```
PUBLIC PAGES (1 tool call):
□ index.php, about.php, contact.php, services.php, etc.

AUTH PAGES (1 tool call):
□ login.php, register.php, forgot-password.php, etc.

ADMIN PAGES (2-3 tool calls):
□ dashboard.php
□ CRUD pages (users, orders, products, etc.)
□ Settings & reports

CLIENT PAGES (2-3 tool calls):
□ client-dashboard.php
□ order-history.php, profile.php, etc.

PARTNER PAGES (2-3 tool calls):
□ partner-dashboard.php
□ partner-products.php, partner-reports.php, etc.
```

**Estimasi:** 20-30 menit

---

### PHASE 5: INTEGRATION (2-3 Tool Calls)
```
□ Link all components ke pages
□ Connect database integration
□ Setup routing system
□ Test basic functionality
□ Generate ZIP file
```

**Estimasi:** 5 menit

---

## 📋 TEMPLATE BASE PAGE

### Admin Base Template (admin-base-page.php)
```php
<?php
// Include config & auth check
require_once 'config/database.php';
require_once 'includes/auth.php';
checkAdminAuth();

$pageTitle = "TITLE_PLACEHOLDER";
$activeMenu = "MENU_PLACEHOLDER";
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $pageTitle; ?> - Admin Panel</title>
    <!-- Include CSS -->
</head>
<body>
    <?php include 'components/admin-header.php'; ?>
    <?php include 'components/admin-sidebar.php'; ?>
    
    <main>
        <!-- PAGE_CONTENT_PLACEHOLDER -->
    </main>
    
    <?php include 'components/admin-footer.php'; ?>
    <!-- Include JS -->
</body>
</html>
```

---

## 🎯 CONTOH PENGGUNAAN

### Cara Generate Admin Dashboard:
```
1. Copy admin-base-page.php
2. Replace TITLE_PLACEHOLDER dengan "Dashboard"
3. Replace MENU_PLACEHOLDER dengan "dashboard"
4. Replace PAGE_CONTENT_PLACEHOLDER dengan:
   - Stats widgets
   - Charts
   - Recent activity table
5. Save as admin-dashboard.php
```

### Cara Generate Admin Users Page:
```
1. Copy admin-base-page.php
2. Replace TITLE_PLACEHOLDER dengan "User Management"
3. Replace MENU_PLACEHOLDER dengan "users"
4. Replace PAGE_CONTENT_PLACEHOLDER dengan:
   - DataTable for users list
   - CRUD buttons (Add, Edit, Delete)
   - Modals for forms
5. Save as admin-users.php
```

**Hasil:** 2 admin pages dengan minimal effort!

---

## 💡 TIPS IMPLEMENTASI

### 1. Gunakan Placeholders
```
TITLE_PLACEHOLDER
MENU_PLACEHOLDER
TABLE_NAME_PLACEHOLDER
CRUD_ENTITY_PLACEHOLDER
```

### 2. Buat Function Generator
```php
function generateCRUDPage($entity, $fields) {
    $template = file_get_contents('base-template.php');
    $template = str_replace('ENTITY_PLACEHOLDER', $entity, $template);
    // ... replace other placeholders
    return $template;
}
```

### 3. Batch Generate dengan Loop
```php
$entities = ['users', 'products', 'orders', 'categories'];
foreach($entities as $entity) {
    $content = generateCRUDPage($entity, $fields[$entity]);
    file_put_contents("admin-{$entity}.php", $content);
}
```

---

## 📊 TRACKING PROGRESS

| Task | Status | Tool Calls Used | Time Spent |
|------|--------|----------------|------------|
| Foundation | ☐ | 0/6 | 0 min |
| Components | ☐ | 0/5 | 0 min |
| Pages | ☐ | 0/10 | 0 min |
| Integration | ☐ | 0/3 | 0 min |
| **TOTAL** | **0%** | **0/24** | **0 min** |

---

## ✅ SUCCESS CRITERIA

- [ ] Semua templates dibuat dan berfungsi
- [ ] Components reusable dan konsisten
- [ ] Semua pages ter-generate dengan benar
- [ ] Navigation dan routing berjalan
- [ ] Database connection established
- [ ] Authentication working
- [ ] ZIP file ready untuk deployment

---

## 🚀 READY TO START?

1. Mulai dari PHASE 1
2. Ikuti checklist secara berurutan
3. Test setiap phase sebelum lanjut
4. Track progress Anda
5. Celebrate efficiency! 🎉

---

*Template Implementation Guide*
*Siap untuk langsung dipraktekkan!*
