# ✅ TO-DO LIST PERBAIKAN BUG - SITUNEO DIGITAL

## 🔥 URGENT - KERJAKAN HARI INI!

### TASK 1: Fix Function `get()` ⏱️ 2 menit
**File:** `/helpers/common.php`

Tambahkan setelah function `get_input()` (sekitar line 439):

```php
/**
 * Get GET input (alias for get_input)
 */
function get($key = null, $default = null) {
    return get_input($key, $default);
}
```

---

### TASK 2: Fix Bootstrap Missing Files ⏱️ 5 menit
**File:** `/config/bootstrap.php` (lines 106-108)

**Pilihan A - Quick Fix (Buat file kosong):**
```bash
cd helpers/
touch validation.php security.php email.php
```

Isi setiap file dengan:
```php
<?php
defined('SITUNEO_ACCESS') or die('Direct access not permitted');
// TODO: Implement validation/security/email functions
```

**Pilihan B - Comment Out (Jika tidak dipakai):**
```php
// require_once HELPERS_PATH . 'validation.php';
// require_once HELPERS_PATH . 'security.php';
// require_once HELPERS_PATH . 'email.php';
```

---

### TASK 3: Fix Database query() Method ⏱️ 10 menit
**File:** `/core/Database.php`

Ganti method `query()` dengan:

```php
public function query($sql, $params = []) {
    $this->prepare($sql);
    
    if (!empty($params)) {
        foreach ($params as $key => $value) {
            $this->bind($key, $value);
        }
    }

    if (DB_LOG_QUERIES) {
        $this->query_log[] = [
            'sql' => $sql,
            'params' => $params,
            'time' => 0,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }

    return $this;
}
```

---

### TASK 4: Pindahkan Password ke .env ⏱️ 15 menit

**Step 1:** Buat file `.env` di root project:
```bash
DB_HOST=localhost
DB_USER=nrrskfvk_user_situneo_digital
DB_PASS=Devin1922$
DB_NAME=nrrskfvk_situneo_digital
DB_CHARSET=utf8mb4
DB_COLLATE=utf8mb4_unicode_ci
```

**Step 2:** Buat `.env.example`:
```bash
DB_HOST=localhost
DB_USER=your_database_user
DB_PASS=your_database_password
DB_NAME=your_database_name
DB_CHARSET=utf8mb4
DB_COLLATE=utf8mb4_unicode_ci
```

**Step 3:** Update `.gitignore`:
```bash
.env
*.log
config/database.php.local
```

**Step 4:** Update `/config/database.php` (lines 19-24):
```php
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: '');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_NAME', getenv('DB_NAME') ?: '');
define('DB_CHARSET', getenv('DB_CHARSET') ?: 'utf8mb4');
define('DB_COLLATE', getenv('DB_COLLATE') ?: 'utf8mb4_unicode_ci');
```

**Step 5:** Add .env loader di `/config/bootstrap.php` (sebelum line 46):
```php
// Load .env file
$env_file = dirname(__DIR__) . '/.env';
if (file_exists($env_file)) {
    $env_lines = file($env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($env_lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        list($key, $value) = explode('=', $line, 2);
        putenv(trim($key) . '=' . trim($value));
    }
}
```

---

## 📝 BISA DIKERJAKAN NANTI (Tapi perlu selesai)

### TASK 5: Buat Missing Route Files ⏱️ 30-60 menit

Buat 12 file yang hilang di `/public/`:

#### File Sederhana (Copy template):
1. **calculator.php** - Halaman kalkulator harga
2. **portfolio-detail.php** - Detail portfolio
3. **blog.php** - List blog posts
4. **blog-detail.php** - Detail blog post

#### Form Handlers:
5. **contact-submit.php** - Handler submit contact form
6. **demo-request.php** - Form request demo
7. **demo-submit.php** - Handler submit demo

#### Auth Handlers (di `/public/auth/`):
8. **login-submit.php**
9. **register-submit.php**
10. **register-freelancer.php**
11. **forgot-password-submit.php**
12. **reset-password-submit.php**

**Template dasar untuk semua file:**
```php
<?php
defined('SITUNEO_ACCESS') or die('Direct access not permitted');

$page_title = 'Page Title - SITUNEO DIGITAL';
include INCLUDES_PATH . 'header/public-header.php';
?>

<section class="py-5">
    <div class="container">
        <h1>Page Title</h1>
        <div class="alert alert-info">
            Feature coming soon!
        </div>
    </div>
</section>

<?php include INCLUDES_PATH . 'footer/public-footer.php'; ?>
```

---

## ✅ CHECKLIST SETELAH SELESAI

**Test Critical Fixes:**
- [ ] Akses admin panel - no error "undefined function get()"
- [ ] Refresh halaman - bootstrap load tanpa fatal error
- [ ] Test admin services page - queries berjalan
- [ ] Cek semua menu/routes - no 404 errors

**Test Security:**
- [ ] File `.env` sudah dibuat
- [ ] Password tidak terlihat di `/config/database.php`
- [ ] File `.env` ada di `.gitignore`
- [ ] Commit ke git - pastikan .env tidak ikut

**Test All Pages:**
- [ ] Homepage (/)
- [ ] About (/about)
- [ ] Services (/services)
- [ ] Portfolio (/portfolio)
- [ ] Contact (/contact)
- [ ] Calculator (/calculator) - NEW
- [ ] Blog (/blog) - NEW
- [ ] Login (/auth/login)
- [ ] Register (/auth/register)

---

## 🚨 JIKA ADA ERROR

**Error: "Undefined function get()"**
→ Check: File `/helpers/common.php` sudah ada function `get()`?

**Error: "Cannot load helper file"**
→ Check: Sudah buat file validation.php, security.php, email.php?

**Error: "Database connection failed"**
→ Check: File `.env` sudah benar? Credentials valid?

**Error: "404 Not Found"**
→ Check: File route handler sudah dibuat di `/public/`?

---

## 📞 ESTIMATED TIME

- Task 1-3: **20 menit** (Critical)
- Task 4: **15 menit** (Security)
- Task 5: **60 menit** (Missing files)

**Total:** ~1.5 jam untuk fix semua bug kritis

---

## 💾 BACKUP REMINDER

**SEBELUM mulai perbaikan:**
```bash
# Backup database
mysqldump -u username -p database_name > backup_$(date +%Y%m%d).sql

# Backup files
tar -czf backup_files_$(date +%Y%m%d).tar.gz /path/to/project
```

**SETELAH fix, test di development dulu!**

---

**Status:** ⏳ Waiting for implementation  
**Priority:** 🔴 HIGH - Fix ASAP  
**Impact:** Critical features tidak berfungsi
