-- ========================================
-- SITUNEO DIGITAL - Database Schema
-- NIB: 20250-9261-4570-4515-5453
-- ========================================

-- Create database
CREATE DATABASE IF NOT EXISTS situneo_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE situneo_db;

-- ========================================
-- Table: users
-- ========================================
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  address TEXT,
  role ENUM('user', 'admin') DEFAULT 'user',
  email_verified TINYINT(1) DEFAULT 0,
  verification_token VARCHAR(255),
  remember_token VARCHAR(255),
  remember_expiry INT,
  reset_token VARCHAR(255),
  reset_token_expiry INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_remember_token (remember_token),
  INDEX idx_verification_token (verification_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: services
-- ========================================
CREATE TABLE IF NOT EXISTS services (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  short_description VARCHAR(500),
  image VARCHAR(500),
  price DECIMAL(15,2) NOT NULL,
  discount_price DECIMAL(15,2),
  category VARCHAR(100),
  features JSON,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_name (name),
  INDEX idx_slug (slug),
  INDEX idx_category (category),
  INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: orders
-- ========================================
CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  service_id INT UNSIGNED NOT NULL,
  invoice_number VARCHAR(50) NOT NULL UNIQUE,
  status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
  payment_status ENUM('unpaid', 'paid', 'refunded') DEFAULT 'unpaid',
  total_amount DECIMAL(15,2) NOT NULL,
  discount_amount DECIMAL(15,2) DEFAULT 0,
  tax_amount DECIMAL(15,2) DEFAULT 0,
  final_amount DECIMAL(15,2) NOT NULL,
  requirements TEXT,
  notes TEXT,
  deadline DATE,
  completed_at DATETIME,
  cancelled_at DATETIME,
  cancellation_reason TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_service_id (service_id),
  INDEX idx_status (status),
  INDEX idx_payment_status (payment_status),
  INDEX idx_invoice_number (invoice_number),
  INDEX idx_created_at (created_at),
  INDEX idx_user_status (user_id, status),
  INDEX idx_user_created (user_id, created_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: payments
-- ========================================
CREATE TABLE IF NOT EXISTS payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  payment_method ENUM('bank_transfer', 'credit_card', 'e-wallet', 'cash') NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  transaction_id VARCHAR(255),
  payment_proof VARCHAR(500),
  status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
  verified_by INT UNSIGNED,
  verified_at DATETIME,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_order_id (order_id),
  INDEX idx_status (status),
  INDEX idx_transaction_id (transaction_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: activity_logs
-- ========================================
CREATE TABLE IF NOT EXISTS activity_logs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED,
  activity VARCHAR(255) NOT NULL,
  description TEXT,
  ip_address VARCHAR(45),
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_created_at (created_at),
  INDEX idx_ip_address (ip_address)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: portfolio
-- ========================================
CREATE TABLE IF NOT EXISTS portfolio (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  category VARCHAR(100),
  client_name VARCHAR(255),
  project_date DATE,
  images JSON,
  technologies JSON,
  project_url VARCHAR(500),
  is_featured TINYINT(1) DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_slug (slug),
  INDEX idx_category (category),
  INDEX idx_is_featured (is_featured),
  INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: testimonials
-- ========================================
CREATE TABLE IF NOT EXISTS testimonials (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED,
  order_id INT UNSIGNED,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  company VARCHAR(255),
  position VARCHAR(255),
  avatar VARCHAR(500),
  rating TINYINT(1) DEFAULT 5 CHECK (rating BETWEEN 1 AND 5),
  testimonial TEXT NOT NULL,
  is_featured TINYINT(1) DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
  INDEX idx_rating (rating),
  INDEX idx_is_featured (is_featured),
  INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: contact_messages
-- ========================================
CREATE TABLE IF NOT EXISTS contact_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  subject VARCHAR(255),
  message TEXT NOT NULL,
  status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
  replied_by INT UNSIGNED,
  replied_at DATETIME,
  reply_message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (replied_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_status (status),
  INDEX idx_email (email),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: settings
-- ========================================
CREATE TABLE IF NOT EXISTS settings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value TEXT,
  setting_type ENUM('text', 'number', 'boolean', 'json') DEFAULT 'text',
  description VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- Table: notifications
-- ========================================
CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  type ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
  link VARCHAR(500),
  is_read TINYINT(1) DEFAULT 0,
  read_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_is_read (is_read),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================
-- SAMPLE DATA - Admin User
-- ========================================
INSERT INTO users (name, email, password, role, email_verified) VALUES 
('Administrator', 'admin@situneo.my.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1);
-- Default password: password (change immediately!)

-- ========================================
-- SAMPLE DATA - Services
-- ========================================
INSERT INTO services (name, slug, description, short_description, price, category, features, is_active) VALUES 
('Website Development', 'website-development', 'Pembuatan website profesional untuk bisnis Anda', 'Website responsif dan modern', 5000000.00, 'Web Development', '["Responsive Design", "SEO Optimized", "Fast Loading", "Admin Panel"]', 1),
('Mobile App Development', 'mobile-app-development', 'Aplikasi mobile Android & iOS', 'Aplikasi native untuk semua platform', 15000000.00, 'Mobile Development', '["Android", "iOS", "Cross-platform", "API Integration"]', 1),
('Digital Marketing', 'digital-marketing', 'Strategi pemasaran digital terpadu', 'Tingkatkan brand awareness Anda', 3000000.00, 'Marketing', '["Social Media Marketing", "SEO/SEM", "Content Marketing", "Email Marketing"]', 1),
('UI/UX Design', 'ui-ux-design', 'Desain antarmuka yang user-friendly', 'Pengalaman pengguna yang optimal', 2500000.00, 'Design', '["User Research", "Wireframing", "Prototyping", "Usability Testing"]', 1);

-- ========================================
-- SAMPLE DATA - Settings
-- ========================================
INSERT INTO settings (setting_key, setting_value, setting_type, description) VALUES 
('site_name', 'SITUNEO DIGITAL', 'text', 'Nama website'),
('site_email', 'info@situneo.my.id', 'text', 'Email kontak'),
('site_phone', '+62 812 3456 7890', 'text', 'Nomor telepon'),
('site_address', 'Jakarta, Indonesia', 'text', 'Alamat perusahaan'),
('nib', '20250-9261-4570-4515-5453', 'text', 'Nomor Induk Berusaha'),
('tax_rate', '0.11', 'number', 'Tarif pajak (PPN 11%)'),
('remember_lifetime', '2592000', 'number', 'Remember me lifetime (30 days in seconds)');

-- ========================================
-- TRIGGERS
-- ========================================

-- Auto-generate invoice number
DELIMITER $$
CREATE TRIGGER before_order_insert
BEFORE INSERT ON orders
FOR EACH ROW
BEGIN
  IF NEW.invoice_number IS NULL OR NEW.invoice_number = '' THEN
    SET NEW.invoice_number = CONCAT('INV-', DATE_FORMAT(NOW(), '%Y%m%d'), '-', LPAD(NEW.id, 4, '0'));
  END IF;
END$$
DELIMITER ;

-- Auto-calculate final amount
DELIMITER $$
CREATE TRIGGER before_order_update_amount
BEFORE INSERT ON orders
FOR EACH ROW
BEGIN
  SET NEW.tax_amount = NEW.total_amount * 0.11;
  SET NEW.final_amount = NEW.total_amount - NEW.discount_amount + NEW.tax_amount;
END$$
DELIMITER ;

-- ========================================
-- VIEWS
-- ========================================

-- View: Active orders summary
CREATE OR REPLACE VIEW v_active_orders AS
SELECT 
  o.id,
  o.invoice_number,
  u.name as customer_name,
  u.email as customer_email,
  s.name as service_name,
  o.status,
  o.payment_status,
  o.final_amount,
  o.created_at
FROM orders o
JOIN users u ON o.user_id = u.id
JOIN services s ON o.service_id = s.id
WHERE o.status != 'cancelled'
ORDER BY o.created_at DESC;

-- View: Revenue summary
CREATE OR REPLACE VIEW v_revenue_summary AS
SELECT 
  DATE_FORMAT(created_at, '%Y-%m') as month,
  COUNT(*) as total_orders,
  SUM(CASE WHEN payment_status = 'paid' THEN final_amount ELSE 0 END) as paid_amount,
  SUM(CASE WHEN payment_status = 'unpaid' THEN final_amount ELSE 0 END) as unpaid_amount,
  SUM(final_amount) as total_amount
FROM orders
WHERE status != 'cancelled'
GROUP BY DATE_FORMAT(created_at, '%Y-%m')
ORDER BY month DESC;

-- ========================================
-- STORED PROCEDURES
-- ========================================

-- Get user's order statistics
DELIMITER $$
CREATE PROCEDURE sp_get_user_stats(IN p_user_id INT)
BEGIN
  SELECT 
    COUNT(*) as total_orders,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
    SUM(CASE WHEN payment_status = 'paid' THEN final_amount ELSE 0 END) as total_paid,
    SUM(CASE WHEN payment_status = 'unpaid' THEN final_amount ELSE 0 END) as total_unpaid
  FROM orders
  WHERE user_id = p_user_id;
END$$
DELIMITER ;

-- ========================================
-- INDEXES OPTIMIZATION
-- ========================================

-- Additional composite indexes for better performance
ALTER TABLE orders ADD INDEX idx_user_payment (user_id, payment_status);
ALTER TABLE orders ADD INDEX idx_status_created (status, created_at DESC);
ALTER TABLE activity_logs ADD INDEX idx_user_created (user_id, created_at DESC);

-- ========================================
-- DATABASE INFORMATION
-- ========================================

-- Database: situneo_db
-- Tables: 11
-- Total size: ~50KB (empty structure)
-- Character Set: utf8mb4
-- Collation: utf8mb4_unicode_ci
-- Engine: InnoDB
-- Foreign Keys: Enabled
-- Triggers: 2
-- Views: 2
-- Stored Procedures: 1

-- ========================================
-- NOTES
-- ========================================

-- 1. Change default admin password immediately after installation
-- 2. Backup database regularly
-- 3. Update indexes based on query performance
-- 4. Monitor table sizes and optimize as needed
-- 5. Use connection pooling for high traffic
-- 6. Enable query cache for read-heavy operations
-- 7. Consider partitioning large tables (orders, activity_logs)

-- ========================================
-- MAINTENANCE QUERIES
-- ========================================

-- Check table sizes
SELECT 
  table_name AS 'Table',
  ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'Size (MB)'
FROM information_schema.TABLES
WHERE table_schema = 'situneo_db'
ORDER BY (data_length + index_length) DESC;

-- Optimize all tables
-- OPTIMIZE TABLE users, services, orders, payments, activity_logs, portfolio, testimonials, contact_messages, settings, notifications;

-- Check index usage
-- SHOW INDEX FROM orders;

-- ========================================
-- END OF SCHEMA
-- ========================================
