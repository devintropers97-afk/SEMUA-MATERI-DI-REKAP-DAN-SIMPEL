# TECHNICAL SUMMARY - SITUNEO DIGITAL
**Quick Reference Guide for Developers**

---

## 🚀 QUICK START

### Installation:
```bash
# 1. Extract files
unzip situneo-digital.zip

# 2. Configure database
cp config/database.example.php config/database.php
nano config/database.php

# 3. Import database
mysql -u root -p < database.sql

# 4. Set permissions
chmod 755 -R .
chmod 644 -R *.php

# 5. Configure virtual host
# Point to main directory
```

---

## 📦 PROJECT STRUCTURE

```
situneo-digital/
├── config/
│   ├── database.php       # DB config
│   └── config.php         # Main config
├── pages/                 # Page templates
├── assets/                # Static files
├── uploads/              # User uploads
├── lanjutan31           # Router (Entry point)
├── lanjutan32           # Invoice page
└── lanjutan34           # Login page
```

---

## 🔑 KEY FILES

### 1. Router (lanjutan31)
```php
// Main entry point
// Clean URL routing
// Session handling
```

### 2. Invoice Page (lanjutan32)
```php
// Full invoice management
// Pagination + filters
// Print functionality
// Canvas animations
```

### 3. Login Page (lanjutan34)
```php
// Secure authentication
// Remember me feature
// Email verification
// Activity logging
```

---

## 🗄️ DATABASE CONFIG

```php
// config/database.php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'situneo_db');

// Connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
```

---

## 🔐 SECURITY FUNCTIONS

```php
// Password handling
hashPassword($password)      // Hash password
verifyPassword($input, $hash) // Verify password

// Session management
isLoggedIn()                 // Check login status
requireLogin()               // Force login redirect
getCurrentUser()             // Get current user data

// Token generation
generateToken()              // Generate secure token

// Activity tracking
logActivity($user_id, $action) // Log user actions
```

---

## 📊 DATABASE QUERIES

### Get Invoices (with pagination):
```php
$query = "SELECT o.*, s.name as service_name 
          FROM orders o 
          LEFT JOIN services s ON o.service_id = s.id 
          WHERE o.user_id = ? 
          AND o.status = ?
          ORDER BY o.created_at DESC 
          LIMIT ? OFFSET ?";
```

### User Login:
```php
$query = "SELECT * FROM users WHERE email = ?";
// Then verify password
// Set session variables
// Update remember_token if needed
```

### Check Remember Token:
```php
$query = "SELECT * FROM users 
          WHERE remember_token = ? 
          AND remember_expiry > ?";
```

---

## 🎨 CSS VARIABLES

```css
:root {
  --primary-blue: #1E5C99;
  --dark-blue: #0F3057;
  --gold: #FFB400;
  --bright-gold: #FFD700;
  --white: #ffffff;
  --gradient-primary: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
  --gradient-gold: linear-gradient(135deg, #FFD700 0%, #FFB400 100%);
}
```

---

## 📱 RESPONSIVE BREAKPOINTS

```css
/* Mobile: Default */
/* Tablet: 577px+ */
/* Desktop: 769px+ */
/* Large: 993px+ */
```

---

## 🔧 COMMON FUNCTIONS

```php
// Sanitize input
htmlspecialchars($string, ENT_QUOTES, 'UTF-8')

// Format currency
number_format($amount, 0, ',', '.')

// Format date
date('d M Y, H:i', strtotime($datetime))

// Generate invoice number
'INV-' . date('Ymd', strtotime($date)) . '-' . str_pad($id, 4, '0', STR_PAD_LEFT)
```

---

## 🌐 ROUTES

```
/                    → Home page
/about              → About page
/services           → Services listing
/portfolio          → Portfolio showcase
/pricing            → Pricing plans
/calculator         → Price calculator
/contact            → Contact form
/login.php          → Login page (lanjutan34)
/dashboard.php      → User dashboard
/invoices.php       → Invoice management (lanjutan32)
```

---

## 🎯 API ENDPOINTS (Future)

```
POST   /api/login
POST   /api/register
POST   /api/logout
GET    /api/invoices
GET    /api/invoices/:id
POST   /api/orders
GET    /api/services
```

---

## 🐛 DEBUG MODE

```php
// Enable in config.php
define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', '/path/to/error.log');
}
```

---

## ✅ TESTING CHECKLIST

### Authentication:
- [ ] Login with valid credentials
- [ ] Login with invalid credentials
- [ ] Remember me functionality
- [ ] Logout
- [ ] Email verification check
- [ ] Password reset (if implemented)

### Invoice System:
- [ ] View all invoices
- [ ] Filter by status
- [ ] Pagination
- [ ] View invoice details
- [ ] Print invoice
- [ ] Mobile responsiveness

### Security:
- [ ] SQL injection attempts
- [ ] XSS attempts
- [ ] CSRF protection
- [ ] Session hijacking
- [ ] Brute force attempts

---

## 🚨 COMMON ISSUES & SOLUTIONS

### 1. Database Connection Error
```
Solution: Check database.php credentials
Verify MySQL service is running
Check firewall settings
```

### 2. Session Not Persisting
```
Solution: Check session.save_path permissions
Verify session_start() is called
Check cookie settings
```

### 3. Remember Me Not Working
```
Solution: Verify cookie settings (secure, httponly)
Check remember_token expiry
Ensure HTTPS is enabled
```

### 4. Invoice Not Loading
```
Solution: Check user_id in session
Verify database foreign keys
Check SQL query syntax
```

---

## 📈 PERFORMANCE TIPS

1. **Database:**
   - Use indexes on frequently queried columns
   - Limit results with pagination
   - Use prepared statements
   - Cache common queries

2. **Frontend:**
   - Minify CSS/JS
   - Compress images
   - Use CDN for libraries
   - Lazy load images

3. **Server:**
   - Enable OPcache
   - Use Redis/Memcached for sessions
   - Enable gzip compression
   - Set proper cache headers

---

## 🔒 SECURITY BEST PRACTICES

```php
// 1. Always validate input
$email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);

// 2. Use prepared statements
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $email);

// 3. Hash passwords
$hashed = password_hash($password, PASSWORD_BCRYPT);

// 4. Sanitize output
echo htmlspecialchars($user_input, ENT_QUOTES, 'UTF-8');

// 5. Use HTTPS only cookies
setcookie('name', 'value', time()+3600, '/', '', true, true);

// 6. Regenerate session ID after login
session_regenerate_id(true);
```

---

## 📝 CODE STANDARDS

```php
// 1. Naming conventions
$userName           // camelCase for variables
function getUserData()  // camelCase for functions
class UserModel     // PascalCase for classes
define('DB_HOST')   // UPPERCASE for constants

// 2. Indentation
Use 4 spaces (not tabs)

// 3. Comments
// Single line comment
/* Multi-line
   comment */
/** DocBlock for functions */

// 4. File structure
<?php
/**
 * File description
 */

// Includes
require_once 'config.php';

// Variables
$var = 'value';

// Functions
function myFunction() {}

// Main logic
?>
```

---

## 🛠️ USEFUL COMMANDS

```bash
# Start MySQL
sudo systemctl start mysql

# Check PHP version
php -v

# Check Apache status
sudo systemctl status apache2

# View error logs
tail -f /var/log/apache2/error.log

# Database backup
mysqldump -u root -p situneo_db > backup.sql

# Database restore
mysql -u root -p situneo_db < backup.sql

# Set permissions
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;
```

---

## 📞 SUPPORT

**Email:** support@situneo.my.id  
**Documentation:** https://docs.situneo.my.id  
**GitHub:** [Private Repo]

---

*Last Updated: 2025-01-20*
