# SQL QUERIES & USE CASES
## SITUNEO DIGITAL DATABASE

---

## 📌 COMMON QUERIES

### 1. USER MANAGEMENT

#### Get Active Partners with Earnings
```sql
SELECT 
    u.full_name,
    p.partner_code,
    p.tier,
    p.total_earnings,
    p.total_referrals,
    p.status
FROM partners p
JOIN users u ON p.user_id = u.id
WHERE p.status = 'active'
ORDER BY p.total_earnings DESC;
```

#### Get SPV Performance
```sql
SELECT 
    u.full_name as spv_name,
    s.spv_code,
    s.team_size,
    s.monthly_target,
    s.total_achieved,
    s.performance_score,
    (s.total_achieved / s.monthly_target * 100) as achievement_percentage
FROM spv s
JOIN users u ON s.user_id = u.id
WHERE s.status = 'active'
ORDER BY s.performance_score DESC;
```

---

### 2. ORDER & REVENUE ANALYTICS

#### Monthly Revenue Report
```sql
SELECT 
    DATE_FORMAT(order_date, '%Y-%m') as month,
    COUNT(*) as total_orders,
    SUM(total_amount) as total_revenue,
    AVG(total_amount) as average_order_value,
    SUM(CASE WHEN payment_status = 'paid' THEN total_amount ELSE 0 END) as paid_revenue
FROM orders
WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY DATE_FORMAT(order_date, '%Y-%m')
ORDER BY month DESC;
```

#### Top Selling Services
```sql
SELECT 
    s.name as service_name,
    s.service_code,
    COUNT(oi.id) as total_orders,
    SUM(oi.quantity) as total_quantity,
    SUM(oi.total) as total_revenue,
    s.rating_average
FROM order_items oi
JOIN services s ON oi.service_id = s.id
WHERE oi.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
GROUP BY s.id
ORDER BY total_revenue DESC
LIMIT 10;
```

---

### 3. PARTNER PERFORMANCE

#### Partner Commission Report
```sql
SELECT 
    p.partner_code,
    u.full_name,
    p.tier,
    COUNT(DISTINCT pc.order_id) as total_orders,
    SUM(pc.order_amount) as total_sales,
    SUM(pc.commission_amount) as total_commission,
    SUM(CASE WHEN pc.status = 'paid' THEN pc.commission_amount ELSE 0 END) as paid_commission
FROM partners p
JOIN users u ON p.user_id = u.id
LEFT JOIN partner_commissions pc ON p.id = pc.partner_id
WHERE pc.created_at >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
GROUP BY p.id
ORDER BY total_commission DESC;
```

#### Referral Conversion Rate
```sql
SELECT 
    p.partner_code,
    u.full_name,
    COUNT(r.id) as total_referrals,
    COUNT(DISTINCT o.id) as converted_orders,
    (COUNT(DISTINCT o.id) / COUNT(r.id) * 100) as conversion_rate,
    SUM(o.total_amount) as total_revenue
FROM partners p
JOIN users u ON p.user_id = u.id
LEFT JOIN referrals r ON p.id = r.referrer_id
LEFT JOIN orders o ON r.referred_user_id = o.client_id
GROUP BY p.id
HAVING total_referrals > 0
ORDER BY conversion_rate DESC;
```

---

### 4. CLIENT ANALYTICS

#### Client Lifetime Value
```sql
SELECT 
    c.company_name,
    u.email,
    c.lifetime_value,
    COUNT(o.id) as total_orders,
    AVG(o.total_amount) as average_order,
    MAX(o.order_date) as last_order_date,
    DATEDIFF(CURDATE(), MAX(o.order_date)) as days_since_last_order
FROM clients c
JOIN users u ON c.user_id = u.id
LEFT JOIN orders o ON c.id = o.client_id
GROUP BY c.id
ORDER BY c.lifetime_value DESC
LIMIT 20;
```

#### Active Subscriptions
```sql
SELECT 
    c.company_name,
    s.name as service_name,
    cs.subscription_type,
    cs.start_date,
    cs.end_date,
    cs.monthly_price,
    cs.status
FROM client_subscriptions cs
JOIN clients c ON cs.client_id = c.id
JOIN services s ON cs.service_id = s.id
WHERE cs.status = 'active'
AND cs.end_date > CURDATE()
ORDER BY cs.monthly_price DESC;
```

---

### 5. BLOG & CONTENT

#### Popular Blog Posts
```sql
SELECT 
    bp.title,
    bp.slug,
    bc.name as category,
    u.full_name as author,
    bp.view_count,
    bp.published_at,
    COUNT(DISTINCT bt.tag_id) as tag_count
FROM blog_posts bp
JOIN blog_categories bc ON bp.category_id = bc.id
JOIN users u ON bp.author_id = u.id
LEFT JOIN post_tags bt ON bp.id = bt.post_id
WHERE bp.is_published = 1
GROUP BY bp.id
ORDER BY bp.view_count DESC
LIMIT 10;
```

---

### 6. FINANCIAL REPORTS

#### Outstanding Invoices
```sql
SELECT 
    i.invoice_number,
    c.company_name,
    i.invoice_date,
    i.due_date,
    i.total_amount,
    i.paid_amount,
    (i.total_amount - i.paid_amount) as outstanding_amount,
    DATEDIFF(CURDATE(), i.due_date) as days_overdue
FROM invoices i
JOIN orders o ON i.order_id = o.id
JOIN clients c ON o.client_id = c.id
WHERE i.status IN ('unpaid', 'partial')
ORDER BY days_overdue DESC;
```

#### Payment Success Rate
```sql
SELECT 
    payment_method,
    COUNT(*) as total_payments,
    SUM(CASE WHEN status = 'verified' THEN 1 ELSE 0 END) as verified_payments,
    (SUM(CASE WHEN status = 'verified' THEN 1 ELSE 0 END) / COUNT(*) * 100) as success_rate,
    SUM(amount) as total_amount
FROM payments
WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
GROUP BY payment_method
ORDER BY success_rate DESC;
```

---

### 7. SERVICE ANALYTICS

#### Service Performance Dashboard
```sql
SELECT 
    s.name,
    bc.name as category,
    s.order_count,
    s.view_count,
    (s.order_count / s.view_count * 100) as conversion_rate,
    s.rating_average,
    s.rating_count,
    s.base_price,
    (s.order_count * s.base_price) as estimated_revenue
FROM services s
JOIN business_categories bc ON s.category_id = bc.id
WHERE s.is_active = 1
ORDER BY estimated_revenue DESC
LIMIT 20;
```

---

### 8. SPV MANAGEMENT

#### SPV Team Performance
```sql
SELECT 
    s.spv_code,
    u.full_name as spv_name,
    COUNT(sp.partner_id) as team_size,
    SUM(p.total_earnings) as team_total_earnings,
    AVG(p.total_earnings) as avg_partner_earnings,
    s.monthly_target,
    s.total_achieved,
    s.bonus_earned
FROM spv s
JOIN users u ON s.user_id = u.id
LEFT JOIN spv_partners sp ON s.id = sp.spv_id
LEFT JOIN partners p ON sp.partner_id = p.id
WHERE sp.status = 'active'
GROUP BY s.id
ORDER BY team_total_earnings DESC;
```

---

## 🎯 BUSINESS INTELLIGENCE QUERIES

### Dashboard Metrics
```sql
-- Key Performance Indicators
SELECT 
    (SELECT COUNT(*) FROM orders WHERE order_date >= CURDATE() - INTERVAL 30 DAY) as monthly_orders,
    (SELECT SUM(total_amount) FROM orders WHERE payment_status = 'paid' AND order_date >= CURDATE() - INTERVAL 30 DAY) as monthly_revenue,
    (SELECT COUNT(*) FROM partners WHERE status = 'active') as active_partners,
    (SELECT COUNT(*) FROM clients WHERE status = 'active') as active_clients,
    (SELECT COUNT(*) FROM services WHERE is_active = 1) as active_services,
    (SELECT COUNT(*) FROM support_tickets WHERE status IN ('open', 'pending')) as open_tickets;
```

### Growth Trends
```sql
-- Month-over-Month Growth
SELECT 
    current_month.month,
    current_month.revenue as current_revenue,
    previous_month.revenue as previous_revenue,
    ((current_month.revenue - previous_month.revenue) / previous_month.revenue * 100) as growth_percentage
FROM (
    SELECT DATE_FORMAT(order_date, '%Y-%m') as month, SUM(total_amount) as revenue
    FROM orders WHERE payment_status = 'paid'
    GROUP BY DATE_FORMAT(order_date, '%Y-%m')
) current_month
LEFT JOIN (
    SELECT DATE_FORMAT(order_date, '%Y-%m') as month, SUM(total_amount) as revenue
    FROM orders WHERE payment_status = 'paid'
    GROUP BY DATE_FORMAT(order_date, '%Y-%m')
) previous_month ON previous_month.month = DATE_FORMAT(DATE_SUB(STR_TO_DATE(CONCAT(current_month.month, '-01'), '%Y-%m-%d'), INTERVAL 1 MONTH), '%Y-%m')
ORDER BY current_month.month DESC
LIMIT 12;
```

---

## 🔍 ADVANCED QUERIES

### Customer Segmentation
```sql
SELECT 
    CASE 
        WHEN c.lifetime_value >= 50000000 THEN 'VIP'
        WHEN c.lifetime_value >= 20000000 THEN 'Premium'
        WHEN c.lifetime_value >= 5000000 THEN 'Regular'
        ELSE 'New'
    END as segment,
    COUNT(*) as customer_count,
    AVG(c.lifetime_value) as avg_ltv,
    SUM(c.lifetime_value) as total_ltv
FROM clients c
WHERE c.status = 'active'
GROUP BY segment
ORDER BY avg_ltv DESC;
```

### Partner Tier Qualification
```sql
SELECT 
    p.partner_code,
    u.full_name,
    p.tier as current_tier,
    p.total_earnings,
    p.total_referrals,
    CASE 
        WHEN p.total_earnings >= 100000000 AND p.total_referrals >= 50 THEN 'platinum'
        WHEN p.total_earnings >= 50000000 AND p.total_referrals >= 25 THEN 'gold'
        WHEN p.total_earnings >= 20000000 AND p.total_referrals >= 10 THEN 'silver'
        ELSE 'bronze'
    END as qualified_tier,
    CASE 
        WHEN p.total_earnings >= 100000000 AND p.total_referrals >= 50 THEN 'Eligible for Platinum'
        WHEN p.total_earnings >= 50000000 AND p.total_referrals >= 25 THEN 'Eligible for Gold'
        WHEN p.total_earnings >= 20000000 AND p.total_referrals >= 10 THEN 'Eligible for Silver'
        ELSE 'Stay in Bronze'
    END as recommendation
FROM partners p
JOIN users u ON p.user_id = u.id
WHERE p.status = 'active';
```

---

**End of SQL Queries Document**
