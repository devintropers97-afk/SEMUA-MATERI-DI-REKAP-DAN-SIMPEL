# 🗺️ DATABASE RELATIONSHIP MAP
## SITUNEO DIGITAL - Entity Relationship Diagram

---

## 📐 MAIN ENTITIES & RELATIONSHIPS

```
┌─────────────────────────────────────────────────────────────┐
│                      CORE USER SYSTEM                        │
└─────────────────────────────────────────────────────────────┘

                         ┌──────────┐
                         │  USERS   │ (Master User Table)
                         │  id      │
                         │  email   │
                         │  role    │
                         └────┬─────┘
                              │
           ┌──────────────────┼──────────────────┐
           │                  │                  │
           ▼                  ▼                  ▼
    ┌──────────┐       ┌──────────┐      ┌──────────┐
    │ CLIENTS  │       │ PARTNERS │      │   SPV    │
    │  id      │       │  id      │      │  id      │
    │  user_id │       │  user_id │      │  user_id │
    └────┬─────┘       └────┬─────┘      └────┬─────┘
         │                  │                  │
         │                  │                  │
         ▼                  ▼                  ▼

┌─────────────────────────────────────────────────────────────┐
│                    BUSINESS OPERATIONS                       │
└─────────────────────────────────────────────────────────────┘

┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│   CLIENTS    │────────>│    ORDERS    │<────────│   PARTNERS   │
│              │         │              │         │  (referral)  │
│  - company   │         │  - order_no  │         │  - tier      │
│  - ltv       │         │  - total     │         │  - earnings  │
└──────┬───────┘         └──────┬───────┘         └──────┬───────┘
       │                        │                        │
       │                        │                        │
       ▼                        ▼                        ▼
┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│ CLIENT_      │         │ ORDER_ITEMS  │         │ PARTNER_     │
│ SUBSCRIPTIONS│         │              │         │ COMMISSIONS  │
└──────────────┘         │  - service   │         └──────────────┘
                         │  - quantity  │
                         │  - price     │
                         └──────┬───────┘
                                │
                                │
                                ▼
                         ┌──────────────┐
                         │   SERVICES   │ (232+ services)
                         │              │
                         │  - name      │
                         │  - price     │
                         │  - category  │
                         └──────┬───────┘
                                │
                                │
                         ┌──────┴───────┐
                         │              │
                         ▼              ▼
                  ┌──────────┐   ┌──────────┐
                  │ SERVICE_ │   │ SERVICE_ │
                  │ ADDONS   │   │ REVIEWS  │
                  └──────────┘   └──────────┘

┌─────────────────────────────────────────────────────────────┐
│                  PAYMENT & FINANCE FLOW                      │
└─────────────────────────────────────────────────────────────┘

   ┌──────────┐           ┌──────────┐           ┌──────────┐
   │  ORDERS  │──────────>│ PAYMENTS │──────────>│ INVOICES │
   │          │           │          │           │          │
   │  - total │           │ - amount │           │ - total  │
   │  - status│           │ - method │           │ - paid   │
   └────┬─────┘           │ - status │           └────┬─────┘
        │                 └──────────┘                │
        │                                             │
        ▼                                             ▼
   ┌──────────┐                               ┌──────────────┐
   │ REFUNDS  │                               │ INVOICE_     │
   │          │                               │ ITEMS        │
   │ - reason │                               └──────────────┘
   └──────────┘

┌─────────────────────────────────────────────────────────────┐
│                    SPV MANAGEMENT SYSTEM                     │
└─────────────────────────────────────────────────────────────┘

                    ┌──────────┐
                    │   SPV    │ (Supervisor)
                    │          │
                    │ - region │
                    │ - target │
                    └────┬─────┘
                         │
         ┌───────────────┼───────────────┐
         │               │               │
         ▼               ▼               ▼
   ┌──────────┐   ┌──────────┐   ┌──────────┐
   │SPV_      │   │SPV_      │   │SPV_      │
   │PARTNERS  │   │TARGETS   │   │REPORTS   │
   └────┬─────┘   └──────────┘   └──────────┘
        │
        │ manages
        ▼
   ┌──────────┐
   │ PARTNERS │
   │          │
   │ - tier   │
   └──────────┘

┌─────────────────────────────────────────────────────────────┐
│                  MARKETING & CONTENT SYSTEM                  │
└─────────────────────────────────────────────────────────────┘

   ┌──────────┐           ┌──────────┐           ┌──────────┐
   │  BLOG_   │──────────>│  BLOG_   │<──────────│  POST_   │
   │  POSTS   │           │CATEGORIES│           │  TAGS    │
   │          │           └──────────┘           └──────────┘
   │ - title  │
   │ - views  │
   └──────────┘

   ┌──────────┐           ┌──────────┐
   │CAMPAIGNS │──────────>│CAMPAIGN_ │
   │          │           │ANALYTICS │
   │ - budget │           │          │
   │ - status │           │ - clicks │
   └──────────┘           │ - conv.  │
                          └──────────┘

┌─────────────────────────────────────────────────────────────┐
│                   PROJECT MANAGEMENT                         │
└─────────────────────────────────────────────────────────────┘

   ┌──────────┐           ┌──────────┐
   │PORTFOLIOS│──────────>│PORTFOLIO_│
   │          │           │ IMAGES   │
   │ - client │           └──────────┘
   │ - order  │
   └────┬─────┘
        │
        │
        ▼
   ┌──────────┐           ┌──────────────┐
   │MILESTONES│──────────>│ MILESTONE_   │
   │          │           │ APPROVALS    │
   │ - due    │           └──────────────┘
   │ - status │
   └────┬─────┘
        │
        ▼
   ┌──────────┐
   │DELIVER-  │
   │ ABLES    │
   └──────────┘

┌─────────────────────────────────────────────────────────────┐
│                    SUPPORT & TICKETING                       │
└─────────────────────────────────────────────────────────────┘

   ┌──────────┐           ┌──────────┐
   │ SUPPORT_ │──────────>│ TICKET_  │
   │ TICKETS  │           │ MESSAGES │
   │          │           │          │
   │ - status │           │ - sender │
   │ - prio.  │           │ - msg    │
   └──────────┘           └──────────┘

┌─────────────────────────────────────────────────────────────┐
│                   PARTNER TASK SYSTEM                        │
└─────────────────────────────────────────────────────────────┘

                    ┌──────────┐
                    │ PARTNER_ │
                    │  TASKS   │
                    │          │
                    │ - reward │
                    └────┬─────┘
                         │
         ┌───────────────┼───────────────┐
         │               │               │
         ▼               ▼               ▼
   ┌──────────┐   ┌──────────┐   ┌──────────┐
   │  TASK_   │   │  TASK_   │   │  TASK_   │
   │APPLICA-  │   │SUBMISS-  │   │ REVIEWS  │
   │ TIONS    │   │ IONS     │   │          │
   └──────────┘   └──────────┘   └──────────┘

┌─────────────────────────────────────────────────────────────┐
│                    SYSTEM & SECURITY                         │
└─────────────────────────────────────────────────────────────┘

   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
   │  ACTIVITY_   │   │   AUDIT_     │   │   ADMIN_     │
   │   LOGS       │   │   LOGS       │   │  ACTIONS     │
   └──────────────┘   └──────────────┘   └──────────────┘

   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
   │  API_KEYS    │   │   USER_      │   │   LOGIN_     │
   │              │   │  SESSIONS    │   │  ATTEMPTS    │
   └──────────────┘   └──────────────┘   └──────────────┘

```

---

## 🔗 KEY RELATIONSHIPS SUMMARY

### 1-to-Many (1:N)
```
users        → clients, partners, spv, blog_posts
clients      → orders, subscriptions, interactions
partners     → referrals, commissions, leads
spv          → spv_partners, spv_targets, spv_reports
orders       → order_items, payments, invoices
services     → order_items, reviews, addons
portfolios   → portfolio_images, milestones
tickets      → ticket_messages
campaigns    → campaign_analytics
```

### Many-to-Many (M:N) - via Junction Tables
```
blog_posts ←→ blog_tags (via post_tags)
packages   ←→ services (via package_items)
spv        ←→ partners (via spv_partners)
```

### Self-Referencing
```
business_categories → parent_id (hierarchical)
```

---

## 📊 CARDINALITY EXAMPLES

```
[1] USER ────< [N] CLIENTS
[1] USER ────< [N] PARTNERS  
[1] USER ────< [N] SPV

[1] CLIENT ──< [N] ORDERS
[1] PARTNER ─< [N] COMMISSIONS
[1] SPV ─────< [N] SPV_PARTNERS

[1] ORDER ───< [N] ORDER_ITEMS
[1] ORDER ───< [N] PAYMENTS
[1] SERVICE ─< [N] ORDER_ITEMS

[N] ORDERS >─┤ [1] PARTNER (referral)
[N] ORDERS >─┤ [1] CLIENT
```

---

## 🎯 DATA FLOW EXAMPLES

### Order Flow:
```
USER (register) 
  → CLIENT (becomes)
    → SERVICES (browse)
      → ORDER (create)
        → ORDER_ITEMS (add)
          → PAYMENT (process)
            → INVOICE (generate)
              → COMMISSION (calculate - if via partner)
```

### Partner Flow:
```
USER (apply)
  → PARTNER_APPLICATION (submit)
    → PARTNER (approved)
      → REFERRAL (create link)
        → ORDER (referral converts)
          → COMMISSION (earned)
            → PAYOUT (request)
```

### SPV Flow:
```
SPV (assigned)
  → SPV_PARTNERS (manage team)
    → SPV_TARGETS (set targets)
      → SPV_REPORTS (track performance)
        → SPV_BONUSES (calculate)
```

---

**End of Relationship Map**
