# DETAIL STRUKTUR TABEL - PART 1
## SITUNEO DIGITAL DATABASE

---

## 1. USERS TABLE (`users`)
**Primary table untuk semua user sistem**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| username | VARCHAR(50) | Username unik |
| email | VARCHAR(100) | Email unik |
| password_hash | VARCHAR(255) | Password terenkripsi |
| full_name | VARCHAR(100) | Nama lengkap |
| phone | VARCHAR(20) | No telepon |
| role | ENUM | admin/partner/client/spv |
| status | ENUM | active/inactive/suspended |
| email_verified | TINYINT(1) | Status verifikasi email |
| last_login | DATETIME | Login terakhir |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Indexes:**
- PRIMARY KEY (`id`)
- UNIQUE (`username`, `email`)

**Relations:**
- Has many: orders, payments, partners, clients, spv

---

## 2. USER_PROFILES TABLE (`user_profiles`)
**Extended profile information untuk users**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| user_id | INT(11) | FK to users |
| avatar | VARCHAR(255) | Profile picture |
| bio | TEXT | Biografi |
| date_of_birth | DATE | Tanggal lahir |
| gender | ENUM | male/female/other |
| address | TEXT | Alamat lengkap |
| city | VARCHAR(100) | Kota |
| state | VARCHAR(100) | Provinsi |
| country | VARCHAR(100) | Negara |
| postal_code | VARCHAR(20) | Kode pos |
| website | VARCHAR(255) | Website pribadi |
| social_media | TEXT | JSON social media |
| created_at | TIMESTAMP | Waktu dibuat |

**Foreign Keys:**
- `user_id` → users(id) ON DELETE CASCADE

---

## 3. CLIENTS TABLE (`clients`)
**Data klien/customer**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| user_id | INT(11) | FK to users |
| company_name | VARCHAR(255) | Nama perusahaan |
| industry | VARCHAR(100) | Industri |
| company_size | VARCHAR(50) | Ukuran perusahaan |
| tax_id | VARCHAR(50) | NPWP |
| billing_address | TEXT | Alamat billing |
| shipping_address | TEXT | Alamat shipping |
| credit_limit | DECIMAL(15,2) | Limit kredit |
| lifetime_value | DECIMAL(15,2) | Total nilai transaksi |
| status | ENUM | active/inactive/blocked |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Belongs to: users
- Has many: orders, subscriptions, testimonials

---

## 4. PARTNERS TABLE (`partners`)
**Data partner/affiliate**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| user_id | INT(11) | FK to users |
| partner_code | VARCHAR(20) | Kode partner unik |
| tier | ENUM | bronze/silver/gold/platinum |
| commission_rate | DECIMAL(5,2) | Persentase komisi |
| total_earnings | DECIMAL(15,2) | Total penghasilan |
| total_referrals | INT(11) | Total referral |
| total_orders | INT(11) | Total order |
| status | ENUM | active/inactive/suspended |
| approved_at | DATETIME | Tanggal approval |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Belongs to: users
- Has many: referrals, commissions, tasks

---

## 5. SPV TABLE (`spv`)
**Data Supervisor**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| user_id | INT(11) | FK to users |
| spv_code | VARCHAR(20) | Kode SPV unik |
| region | VARCHAR(100) | Wilayah tanggung jawab |
| team_size | INT(11) | Jumlah partner |
| monthly_target | DECIMAL(15,2) | Target bulanan |
| total_achieved | DECIMAL(15,2) | Total pencapaian |
| bonus_earned | DECIMAL(15,2) | Bonus yang didapat |
| performance_score | DECIMAL(5,2) | Skor performa |
| status | ENUM | active/inactive |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Belongs to: users
- Has many: spv_partners, spv_targets, spv_reports

---

## 6. BUSINESS_CATEGORIES TABLE (`business_categories`)
**Kategori layanan bisnis**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| name | VARCHAR(100) | Nama kategori |
| slug | VARCHAR(100) | URL-friendly name |
| icon | VARCHAR(50) | Icon class |
| description | TEXT | Deskripsi |
| parent_id | INT(11) | Parent category |
| order_index | INT(11) | Urutan tampilan |
| is_active | TINYINT(1) | Status aktif |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Categories:**
1. Web Development
2. Mobile Apps
3. Digital Marketing
4. Branding & Design
5. E-Commerce
6. Cloud Services
7. Consulting
8. Maintenance
9. Training
10. Custom Solutions

---

## 7. SERVICES TABLE (`services`)
**Master layanan digital (232+ services)**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| category_id | INT(11) | FK to categories |
| service_code | VARCHAR(50) | Kode layanan |
| name | VARCHAR(255) | Nama layanan |
| slug | VARCHAR(255) | URL slug |
| short_description | TEXT | Deskripsi singkat |
| full_description | LONGTEXT | Deskripsi lengkap |
| features | LONGTEXT | JSON features |
| base_price | DECIMAL(15,2) | Harga dasar |
| setup_fee | DECIMAL(15,2) | Biaya setup |
| monthly_fee | DECIMAL(15,2) | Biaya bulanan |
| currency | VARCHAR(3) | Mata uang (IDR) |
| duration_days | INT(11) | Durasi pengerjaan |
| is_subscription | TINYINT(1) | Layanan berlangganan |
| is_featured | TINYINT(1) | Featured service |
| is_active | TINYINT(1) | Status aktif |
| view_count | INT(11) | Jumlah view |
| order_count | INT(11) | Jumlah order |
| rating_average | DECIMAL(3,2) | Rata-rata rating |
| rating_count | INT(11) | Jumlah rating |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Belongs to: business_categories
- Has many: order_items, reviews, addons

---

## 8. ORDERS TABLE (`orders`)
**Pesanan/transaksi**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| order_number | VARCHAR(50) | Nomor order unik |
| client_id | INT(11) | FK to clients |
| partner_id | INT(11) | FK to partners (referral) |
| order_date | DATETIME | Tanggal order |
| status | ENUM | pending/processing/completed/cancelled |
| subtotal | DECIMAL(15,2) | Subtotal |
| discount_amount | DECIMAL(15,2) | Diskon |
| tax_amount | DECIMAL(15,2) | Pajak |
| total_amount | DECIMAL(15,2) | Total |
| currency | VARCHAR(3) | Mata uang |
| payment_status | ENUM | unpaid/partial/paid/refunded |
| notes | TEXT | Catatan |
| created_at | TIMESTAMP | Waktu dibuat |
| updated_at | TIMESTAMP | Waktu update |

**Relations:**
- Belongs to: clients, partners
- Has many: order_items, payments, invoices

---

## 9. ORDER_ITEMS TABLE (`order_items`)
**Detail item dalam order**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| order_id | INT(11) | FK to orders |
| service_id | INT(11) | FK to services |
| package_id | INT(11) | FK to packages |
| item_type | ENUM | service/package/addon |
| item_name | VARCHAR(255) | Nama item |
| quantity | INT(11) | Jumlah |
| unit_price | DECIMAL(15,2) | Harga satuan |
| discount | DECIMAL(15,2) | Diskon |
| tax | DECIMAL(15,2) | Pajak |
| total | DECIMAL(15,2) | Total |
| created_at | TIMESTAMP | Waktu dibuat |

**Relations:**
- Belongs to: orders, services, packages

---

## 10. PAYMENTS TABLE (`payments`)
**Pembayaran order**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| order_id | INT(11) | FK to orders |
| payment_number | VARCHAR(50) | Nomor pembayaran |
| payment_method | VARCHAR(50) | Metode pembayaran |
| amount | DECIMAL(15,2) | Jumlah bayar |
| currency | VARCHAR(3) | Mata uang |
| status | ENUM | pending/verified/failed |
| payment_date | DATETIME | Tanggal bayar |
| verified_at | DATETIME | Tanggal verifikasi |
| verified_by | INT(11) | FK to users |
| payment_proof | VARCHAR(255) | Bukti transfer |
| transaction_id | VARCHAR(255) | ID transaksi gateway |
| notes | TEXT | Catatan |
| created_at | TIMESTAMP | Waktu dibuat |

**Relations:**
- Belongs to: orders, users (verified_by)

---

## 11. INVOICES TABLE (`invoices`)
**Invoice/faktur**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| order_id | INT(11) | FK to orders |
| invoice_number | VARCHAR(50) | Nomor invoice |
| invoice_date | DATE | Tanggal invoice |
| due_date | DATE | Tanggal jatuh tempo |
| subtotal | DECIMAL(15,2) | Subtotal |
| tax_amount | DECIMAL(15,2) | Pajak |
| discount_amount | DECIMAL(15,2) | Diskon |
| total_amount | DECIMAL(15,2) | Total |
| paid_amount | DECIMAL(15,2) | Jumlah dibayar |
| status | ENUM | unpaid/partial/paid/overdue |
| notes | TEXT | Catatan |
| created_at | TIMESTAMP | Waktu dibuat |

**Relations:**
- Belongs to: orders
- Has many: invoice_items

---

## 12. PARTNER_COMMISSIONS TABLE (`partner_commissions`)
**Komisi partner**

| Field | Type | Description |
|-------|------|-------------|
| id | INT(11) | Primary key |
| partner_id | INT(11) | FK to partners |
| order_id | INT(11) | FK to orders |
| commission_type | VARCHAR(50) | Tipe komisi |
| order_amount | DECIMAL(15,2) | Nilai order |
| commission_rate | DECIMAL(5,2) | Rate komisi |
| commission_amount | DECIMAL(15,2) | Jumlah komisi |
| status | ENUM | pending/approved/paid |
| paid_at | DATETIME | Tanggal bayar |
| notes | TEXT | Catatan |
| created_at | TIMESTAMP | Waktu dibuat |

**Relations:**
- Belongs to: partners, orders

---

**[Lanjut ke Part 2 untuk 90 tabel lainnya...]**
