# 📋 REKAP LENGKAP FILE SITUNEO DIGITAL

**File:** fix_wajib  
**Total Baris:** 2,496 baris  
**Jenis:** Kode PHP Homepage + Instruksi Pengembangan  
**Status Pembacaan:** ✅ 100% SELESAI

---

## 🎯 INSTRUKSI UTAMA (Baris 2492-2496)

### 1. **Jumlah File & Pembagian**
- Total yang diminta: **300+ file**
- Harus dibagi dalam **beberapa batch**
- Alasan: Supaya mudah revisi dan edit
- File dipecah-pecah agar tidak terlalu panjang

### 2. **Desain & Fitur**
- Tampilan desain harus **sama persis** seperti contoh homepage yang diberikan
- Semua fitur harus mengikuti template yang sudah ada

### 3. **Sistem Role (3 Role)**
- Role 1: **Client** (Pelanggan)
- Role 2: **Partner** (Mitra/Reseller)
- Role 3: **Admin** (Pengelola - diasumsikan dari konteks)

### 4. **Form Registrasi (2 Jenis)**
- **Client Form:**
  - Form standar untuk pelanggan
  - Untuk ajukan demo website
  
- **Partner Form:**
  - Form seperti "melamar pekerjaan"
  - Tetapi tidak boleh dipersulit
  - Berbeda isi dengan form client

### 5. **Sistem Komisi Partner**
- Komisi maksimal: **55%**
- Struktur: **4 Tier** (tingkatan)
- Detail ada di materi yang sudah dikirim

### 6. **Database**
- Minimum: **17+ tabel SQL**
- Boleh lebih dari 17 tabel
- Disesuaikan dengan banyaknya materi (300+ file)

---

## 📄 ISI KODE HOMEPAGE (Baris 1-2491)

### **A. INFORMASI PERUSAHAAN**

**Nama:** SITUNEO DIGITAL  
**Tagline:** Website Termahal & Termewah Se-Indonesia  
**NIB:** 20250-9261-4570-4515-5453  
**Tahun Berdiri:** 2020  
**Jumlah Client:** 500+ bisnis

---

### **B. PENAWARAN UTAMA**

#### 🎁 **Harga & Promo:**
- **Harga Per Halaman:** Rp 350.000
- **FREE DEMO:** 24 Jam
- **Sistem:** Lihat Dulu Hasilnya, Bayar Kalau Cocok!

---

### **C. MULTI-LANGUAGE (2 Bahasa)**

#### Bahasa Indonesia:
- Hero Title: "Bikin Website Profesional Cuma Rp 350rb/Halaman"
- Hero Tagline: "Menyelaraskan Ide Menjadi Solusi Digital Modern"
- Hero Subtitle: "FREE DEMO 24 JAM - Lihat Dulu Hasilnya, Bayar Kalau Cocok!"

#### English:
- Hero Title: "Professional Website Only Rp 350k/Page"
- Hero Tagline: "Digital Harmony for a Modern World"
- Hero Subtitle: "FREE 24H DEMO - See First, Pay If You Like!"

---

### **D. MENU NAVIGASI**

1. **Beranda** / Home
2. **Tentang Kami** / About
3. **Layanan** / Services
4. **Lihat Demo** / Portfolio
5. **Harga Paket** / Pricing
6. **Hubungi** / Contact
7. **Hitung Harga** / Calculator
8. **Masuk** / Login

---

### **E. LAYANAN (26 Total, 8 Populer Ditampilkan)**

#### **1. Bikin Website**
- **Harga Mulai:** Rp 350.000
- **Deskripsi:** Website profesional responsive (HP, tablet, komputer)
- **Fitur:** Cepat loading, SEO-friendly
- **Icon:** globe

#### **2. Toko Online Lengkap**
- **Harga Mulai:** Rp 2.000.000
- **Deskripsi:** E-commerce seperti Tokopedia
- **Fitur:** Keranjang belanja, pembayaran otomatis, tracking pengiriman
- **Icon:** cart

#### **3. SEO (Search Engine Optimization)**
- **Harga Mulai:** Rp 1.000.000
- **Deskripsi:** Optimasi agar mudah ditemukan di Google
- **Benefit:** Traffic naik, pembeli makin banyak
- **Icon:** search

#### **4. Iklan Google Ads**
- **Harga Mulai:** Rp 350.000
- **Deskripsi:** Pasang iklan di Google (muncul paling atas)
- **Benefit:** Customer datang terus
- **Icon:** bullseye

#### **5. Iklan Facebook & Instagram**
- **Harga Mulai:** Rp 250.000
- **Deskripsi:** Iklan di FB & IG
- **Target:** Jutaan orang dengan customer yang tepat
- **Icon:** facebook

#### **6. Robot Chat Pintar (AI)**
- **Harga Mulai:** Rp 200.000
- **Deskripsi:** Chatbot AI WhatsApp 24/7
- **Benefit:** Customer puas, kamu santai
- **Icon:** robot

#### **7. Dashboard Pantau Bisnis**
- **Harga Mulai:** Rp 1.500.000
- **Deskripsi:** Dashboard canggih monitoring
- **Fitur:** Pantau penjualan, stok, customer
- **Icon:** speedometer2

#### **8. Payment Gateway**
- **Harga Mulai:** Rp 500.000
- **Deskripsi:** Sistem pembayaran online
- **Metode:** Transfer bank, OVO, GoPay, QRIS
- **Icon:** credit-card

**Catatan:** Ada 18 layanan lainnya yang tidak ditampilkan di homepage

---

### **F. PAKET BUNDLING (3 Paket)**

#### **PAKET 1: STARTER**
**Target:** UMKM & Bisnis Kecil  
**Harga Normal:** Rp 3.500.000  
**Harga Promo:** Rp 2.500.000  
**Hemat:** Rp 1.000.000

**Fitur:**
- ✅ Website 5 halaman
- ✅ Domain .com gratis 1 tahun
- ✅ Hosting 1 tahun
- ✅ SSL (website aman dengan gembok)
- ✅ Desain logo GRATIS
- ✅ 5 artikel SEO
- ✅ Support 1 bulan
- ✅ Responsive (bisa dibuka di HP)
- ✅ SEO dasar

---

#### **PAKET 2: BUSINESS** ⭐ PALING POPULER
**Target:** Yang Paling Banyak Dipilih!  
**Harga Normal:** Rp 6.000.000  
**Harga Promo:** Rp 4.000.000  
**Hemat:** Rp 2.000.000  
**Status:** ⭐ POPULAR

**Fitur:**
- ✅ Website 8 halaman
- ✅ SEO canggih (top di Google)
- ✅ Siap jadi toko online
- ✅ Payment gateway (bayar online)
- ✅ Domain .com gratis 2 tahun
- ✅ Hosting 2 tahun
- ✅ Logo + brosur GRATIS
- ✅ 10 artikel SEO
- ✅ Support 3 bulan
- ✅ Dashboard admin kelola website
- ✅ Live chat di website

---

#### **PAKET 3: PREMIUM**
**Target:** Fitur Lengkap Kayak Perusahaan Besar  
**Harga Normal:** Rp 10.000.000  
**Harga Promo:** Rp 6.500.000  
**Hemat:** Rp 3.500.000

**Fitur:**
- ✅ Website 10 halaman
- ✅ SEO full (dijamin nongol di Google)
- ✅ Bilingual (Indonesia & Inggris)
- ✅ Dashboard admin super canggih
- ✅ Domain .com gratis 3 tahun
- ✅ Hosting 3 tahun
- ✅ Semua design GRATIS (logo, brosur, banner)
- ✅ 20 artikel SEO
- ✅ Support 6 bulan
- ✅ Setup iklan Google Ads
- ✅ WhatsApp Business API
- ✅ Email marketing otomatis

---

### **G. PORTFOLIO DEMO (50 Total, 12 Ditampilkan)**

#### **1. Toko Baju Online**
- **Kategori:** Toko Online
- **Deskripsi:** Website fashion dengan keranjang belanja & pembayaran otomatis
- **ID:** 1

#### **2. Service AC Panggilan**
- **Kategori:** Jasa Service
- **Deskripsi:** Booking online & emergency call 24 jam
- **ID:** 36

#### **3. Konsultan Bisnis**
- **Kategori:** Jasa Profesional
- **Deskripsi:** Sistem booking konsultasi online
- **ID:** 10

#### **4. Klinik Dokter**
- **Kategori:** Kesehatan
- **Deskripsi:** Booking dokter online & jadwal praktek
- **ID:** 15

#### **5. Kursus Online**
- **Kategori:** Pendidikan
- **Deskripsi:** Platform dengan video, quiz, dan sertifikat digital
- **ID:** 19

#### **6. Restoran & Cafe**
- **Kategori:** Makanan
- **Deskripsi:** Menu digital & booking meja
- **ID:** 7

#### **7. Laundry Kiloan**
- **Kategori:** Jasa Service
- **Deskripsi:** Order online & pick up gratis
- **ID:** 32

#### **8. Jual Beli Rumah**
- **Kategori:** Properti
- **Deskripsi:** Virtual tour 360° & kalkulator KPR
- **ID:** 22

#### **9. Cuci Mobil Premium**
- **Kategori:** Otomotif
- **Deskripsi:** Booking slot waktu & membership
- **ID:** 45

#### **10. Service Laptop & HP**
- **Kategori:** Service Teknis
- **Deskripsi:** Home service & garansi
- **ID:** 47

#### **11. Hotel & Booking**
- **Kategori:** Hotel
- **Deskripsi:** Booking kamar online & cek ketersediaan
- **ID:** 24

#### **12. Company Profile IT**
- **Kategori:** Perusahaan
- **Deskripsi:** Portfolio project & contact form
- **ID:** 2

**Catatan:** Ada 38 portfolio lainnya yang tidak ditampilkan

---

### **H. TESTIMONI CUSTOMER (4 Testimoni)**

#### **Testimoni 1: Budi Santoso**
- **Order:** ORD-2024-001
- **Rating:** ⭐⭐⭐⭐⭐ (5/5)
- **Review:** "Harga Rp 350rb/halaman ini MURAH BANGET! Website toko online saya jadi keren, penjualan naik 3x lipat. Tim nya fast response banget!"

#### **Testimoni 2: Sarah Wijaya**
- **Order:** ORD-2024-078
- **Rating:** ⭐⭐⭐⭐⭐ (5/5)
- **Review:** "FREE DEMO 24 jam ini jujur membantu banget. Saya bisa liat dulu hasilnya sebelum bayar. Hasilnya? PUAS BANGET! Sekarang jualan online makin lancar."

#### **Testimoni 3: Dr. Ahmad Fauzi**
- **Order:** ORD-2024-125
- **Rating:** ⭐⭐⭐⭐⭐ (5/5)
- **Review:** "Website klinik saya sekarang ada booking online. Pasien tinggal klik aja, gak usah telpon lagi. Praktis dan modern!"

#### **Testimoni 4: Rina Kusuma**
- **Order:** ORD-2024-203
- **Rating:** ⭐⭐⭐⭐⭐ (5/5)
- **Review:** "Menu digital restoran saya dibikinin Situneo. Customer bilang keren! Order lewat website juga nambah banyak. Makasih Situneo!"

---

### **I. DESAIN & TEKNOLOGI**

#### **Warna Brand (CSS Variables):**
- **Primary Blue:** #1E5C99
- **Dark Blue:** #0F3057
- **Gold:** #FFB400
- **Bright Gold:** #FFD700
- **White:** #ffffff
- **Text Light:** #e9ecef

#### **Gradients:**
- **Primary Gradient:** linear-gradient(135deg, #1E5C99 0%, #0F3057 100%)
- **Gold Gradient:** linear-gradient(135deg, #FFD700 0%, #FFB400 100%)

#### **Typography:**
- **Primary Font:** Inter (sans-serif)
- **Secondary Font:** Plus Jakarta Sans
- **Weight:** 300, 400, 500, 600, 700, 800, 900

#### **Framework & Library:**
- Bootstrap 5.3.3
- Bootstrap Icons 1.11.3
- AOS (Animate On Scroll) 2.3.1
- Google Fonts

#### **Fitur Form:**
- Background: rgba(255,255,255,0.05)
- Border: 2px solid rgba(255,180,0,0.3)
- Border Radius: 15px
- Padding: 15px
- Focus Effect: Border gold & background lighter

#### **Fitur Login/Register:**
- Toggle password visibility (show/hide)
- Password strength checker (weak/medium/strong)
- Form validation
- Password minimal 8 karakter
- Konfirmasi password harus match

---

### **J. FITUR INTERAKTIF**

#### **1. Password Visibility Toggle**
```javascript
- Icon: bi-eye (hidden) / bi-eye-slash (visible)
- Click untuk toggle type: password ↔ text
```

#### **2. Password Strength Checker**
```javascript
Kriteria:
- Minimal 8 karakter (+1)
- Ada huruf kecil (+1)
- Ada huruf besar (+1)
- Ada angka (+1)
- Ada simbol ($@#&!) (+1)

Level:
- Strength 0-2: WEAK (merah)
- Strength 3-4: MEDIUM (kuning)
- Strength 5: STRONG (hijau)
```

#### **3. Form Validation**
```javascript
Validasi:
- Password harus sama dengan confirm password
- Password minimal 8 karakter
- Alert jika validasi gagal
```

---

## 🎯 KESIMPULAN & YANG HARUS DIBUAT

### **Sistem Lengkap Yang Dibutuhkan:**

#### **1. FRONTEND (Client-Facing)**
- Homepage (sudah ada template)
- Halaman Layanan (26 layanan detail)
- Halaman Portfolio (50 demo)
- Halaman Pricing
- Halaman About
- Halaman Contact
- Kalkulator Harga
- Form Demo Request
- Login Page
- Register Page (2 jenis: Client & Partner)

#### **2. BACKEND (Admin Panel)**
- Dashboard Admin
- Manajemen User (Client, Partner, Admin)
- Manajemen Layanan (26 layanan)
- Manajemen Paket (3 paket + custom)
- Manajemen Portfolio (50+ demo)
- Manajemen Testimoni
- Manajemen Order
- Sistem Komisi Partner (4 tier, max 55%)
- Laporan & Statistik
- Settings & Konfigurasi

#### **3. PARTNER PANEL**
- Dashboard Partner
- Link Referral Generator
- Tracking Komisi
- Tracking Customer
- Withdraw/Penarikan Komisi
- Laporan Penjualan Partner

#### **4. CLIENT PANEL**
- Dashboard Client
- Status Proyek/Order
- Demo Preview
- Chat/Support Ticket
- Invoice & Payment
- Download Files (logo, assets)

#### **5. DATABASE (17+ Tabel)**
- users (multi-role: admin, client, partner)
- services (26 layanan)
- packages (3 paket bundling)
- portfolios (50+ demo)
- testimonials
- orders
- order_items
- demo_requests
- payments
- commissions
- commission_tiers (4 tier)
- partner_referrals
- partner_withdrawals
- support_tickets
- invoices
- settings
- activity_logs
- (+ tabel lainnya sesuai kebutuhan)

---

## 📦 STRUKTUR FILE YANG HARUS DIBUAT (300+ File)

### **Batch 1: Database & Core**
- database.sql
- config/database.php
- config/app.php
- .htaccess
- index.php

### **Batch 2: Authentication**
- auth/login.php
- auth/register-client.php
- auth/register-partner.php
- auth/logout.php
- auth/forgot-password.php

### **Batch 3: Admin Panel (50+ files)**
- admin/dashboard.php
- admin/users/index.php
- admin/users/add.php
- admin/users/edit.php
- admin/services/... (CRUD)
- admin/packages/... (CRUD)
- admin/portfolios/... (CRUD)
- admin/orders/... (CRUD)
- dll.

### **Batch 4: Partner Panel (30+ files)**
- partner/dashboard.php
- partner/referral.php
- partner/commission.php
- partner/customers.php
- partner/withdraw.php
- dll.

### **Batch 5: Client Panel (20+ files)**
- client/dashboard.php
- client/orders.php
- client/demo.php
- client/support.php
- dll.

### **Batch 6: Frontend Pages (20+ files)**
- pages/services.php
- pages/portfolio.php
- pages/pricing.php
- pages/calculator.php
- dll.

### **Batch 7: API & AJAX (30+ files)**
- api/login.php
- api/register.php
- api/calculate-price.php
- api/submit-demo.php
- dll.

### **Batch 8: Assets & Components (100+ files)**
- CSS files
- JS files
- Images
- Components (header, footer, sidebar, dll)

---

## 🔑 DATA PENTING

### **NIB Resmi:**
20250-9261-4570-4515-5453

### **Kontak:**
- Website: situneo.my.id
- WhatsApp: (ada tombol chat)

### **Tahun & Statistik:**
- Berdiri: 2020
- Client: 500+
- Layanan: 26
- Portfolio: 50+
- Paket: 3

---

## ⚠️ CATATAN PENTING

1. ✅ Semua desain harus **konsisten** dengan homepage
2. ✅ Form register Client & Partner **HARUS BEDA**
3. ✅ Sistem komisi **4 tier** sampai **55%**
4. ✅ Database minimum **17 tabel** (boleh lebih)
5. ✅ File dipecah jadi **300+ file** untuk kemudahan editing
6. ✅ Multi-language support (**Indonesia & English**)
7. ✅ Semua fitur harus **responsive** (mobile-friendly)
8. ✅ FREE DEMO 24 jam adalah fitur utama

---

**SELESAI - TOTAL 2,496 BARIS SUDAH DIREKAP 100%** ✅
