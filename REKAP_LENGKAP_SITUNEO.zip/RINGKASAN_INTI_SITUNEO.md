# RINGKASAN INTI REQUIREMENT SITUNEO.MY.ID

## ✅ STATUS PEMBACAAN: 100% SELESAI

---

## 📋 INTI-INTI PENTING

### 1️⃣ DATABASE
- 80+ tables (boleh ditambah jika perlu)
- Dummy data: HANYA untuk website saja

### 2️⃣ REFERRAL SYSTEM
**Format Link:**
- Partner→Client: `situneo.my.id/register/CLIENT/USERNAME`
- SPV→Partner: `situneo.my.id/register/PARTNER/USERNAME`
- Manager→SPV: `situneo.my.id/register/SPV/USERNAME`

### 3️⃣ DEMO WEBSITES (50 Total)
- ❌ TIDAK pakai subdomain
- ✅ Pakai FOLDER di cPanel
- ✅ Desain PREMIUM & MAHAL
- ✅ Nama bisnis REAL (bukan demo generic)
- ✅ Content REAL sesuai bisnis
- ✅ Sumber gambar: Unsplash/Placeholder

### 4️⃣ LOADING SCREEN
- ✅ Muncul SETIAP page
- ✅ Ada logo + text loading + info halaman tujuan

### 5️⃣ BACKGROUND
- ✅ Network particles di SEMUA halaman
- ✅ Intensity: LOW (30-40 particles)

### 6️⃣ POP-UP DEMO
- ✅ Muncul 10 detik di homepage
- ✅ Ajukan demo → WAJIB regist + login

### 7️⃣ EMAIL OTOMATIS (11 Jenis)
1. Registration confirmation
2. Partner application submitted/approved
3. Order notification (client & admin)
4. Payment received
5. Commission earned
6. Withdrawal requested/approved
7. Order completed
8. Password reset
9. Demo request submitted

### 8️⃣ INVOICE
- Format: `INV-SITUNEO-20-OKT-2025`
- Generate: MANUAL admin
- Email: OTOMATIS ke client

### 9️⃣ KOMISI
**Timing masuk balance:**
1. Client bayar LUNAS
2. Admin APPROVE
3. Serah terima selesai
→ Komisi masuk

### 🔟 ARPU
- Hitung: REAL-TIME
- Trigger: Setiap order di-ACC admin

### 1️⃣1️⃣ ADMIN CONTROL
Admin bisa edit SEMUA:
- Homepage sections
- 232+ services
- Pricing packages
- Portfolio demos
- Semua fungsi & isi website

### 1️⃣2️⃣ COPY FOR AI
- ❌ Jangan sebut "untuk AI"
- ✅ Seolah team Situneo yang buat
- ✅ Include 26 fields lengkap
- ✅ Format: JSON/Markdown/Plain text

### 1️⃣3️⃣ HIERARCHY
- Assign via REFERRAL otomatis
- Admin bisa REASSIGN manual

### 1️⃣4️⃣ DASHBOARD KOMISI
- ✅ Table breakdown
- ✅ Pie chart
- ✅ Visual menarik

### 1️⃣5️⃣ OPTIMASI GAMBAR
- Lazy loading: ON
- Format: WebP (fallback JPG/PNG)
- Compress otomatis: ON

### 1️⃣6️⃣ GOOGLE ANALYTICS
- ID: `G-RPW3MZ3RPY`
- Track: Pageview, button click, form submit

### 1️⃣7️⃣ TAMPILAN PUBLIC
- ✅ Singkat & inti saja
- ✅ Lihat lengkap → Regist + Login
- ✅ Semua CTA → Regist/Login
- ✅ WhatsApp: 1 tombol kanan bawah

### 1️⃣8️⃣ LEADERBOARD
- ✅ Top Partner/SPV/Manager
- ✅ Ranking transparan
- ✅ Khusus member bisa lihat
- ✅ Kontrol team performance

### 1️⃣9️⃣ NIB BADGE
- Lokasi: Footer semua halaman
- Size: Medium

---

## 🎯 FOKUS UTAMA

1. **DESAIN PREMIUM** - Website harus terlihat mahal
2. **REFERRAL 3 LEVEL** - System berjalan sempurna
3. **KOMISI REAL-TIME** - Akurat & transparan
4. **EMAIL OTOMATIS** - 11 jenis notifikasi
5. **50 DEMO BERKUALITAS** - High quality, real content

---

## 📊 STATISTIK

- **Total Poin Major:** 24
- **Sub-detail:** 100+
- **Email Otomatis:** 11 jenis
- **Demo Websites:** 50
- **Services:** 232+
- **Referral Levels:** 3
- **Tables:** 80+

---

**Kompleksitas:** ⭐⭐⭐⭐⭐ (HIGH)
**Timeline Estimasi:** 3-6 bulan

