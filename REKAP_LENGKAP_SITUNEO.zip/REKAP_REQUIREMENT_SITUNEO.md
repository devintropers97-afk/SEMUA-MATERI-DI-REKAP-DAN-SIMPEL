# REKAP LENGKAP REQUIREMENT WEBSITE SITUNEO.MY.ID

**Status Pembacaan:** ✅ 100% SELESAI DIBACA
**Total Poin Requirement:** 24 Poin
**Tanggal Rekap:** 20 November 2025

---

## A. DATABASE & STRUCTURE

### 1. DATABASE TABLES (80+ Tables)
- **Status:** Menggunakan 80+ tables yang sudah dilist
- **Kustomisasi:** Boleh ditambah jika ada fungsi dan membuat lebih rapih

### 2. DUMMY DATA
**Yang PERLU dibuat:**
- ✅ Dummy data untuk WEBSITE saja
- ✅ Sesuai dengan materi yang dikirim
- ❌ TIDAK PERLU untuk Client, Partner, SPV, Manager, Order dummy

**Fokus:** Dummy hasil untuk tampilan website saja

### 3. REFERRAL LINK FORMAT

**Format Referral:**
- **Partner → Client:** `situneo.my.id/register/CLIENT/USERNAME`
- **SPV → Partner:** `situneo.my.id/register/PARTNER/USERNAME`
- **Manager Area → SPV:** `situneo.my.id/register/SPV/USERNAME`

**Struktur Hierarki:**
```
Manager Area
    ↓
   SPV
    ↓
  Partner
    ↓
  Client
```

### 4. DEMO WEBSITES (50 Total)

**Spesifikasi:**
- Total: 50 demo websites
- Batch 1: 10 demo (sudah dibuat)
- Batch 2-5: 40 demo (akan dibuat)

**Kriteria:**
- ✅ Lengkap dan mudah dibaca client
- ✅ Dipilih dari 53 kategori paling marketable
- ✅ Desain PALING BAGUS dan terlihat MAHAL
- ✅ Membuat client PERCAYA dan YAKIN

### 5. DEMO SUBDOMAIN

**Format:** ❌ TIDAK PAKAI SUBDOMAIN

**Solusi:**
- ✅ Pakai FOLDER di cPanel
- ✅ Bisa tampil dan berfungsi sesuai nama dan tema
- Contoh: `situneo.my.id/demo/toko-baju/`

**Tujuan:** Demo wajib paling bagus untuk meyakinkan client

### 6. DEMO CONTENT

**Spesifikasi Content:**
- ✅ Pakai NAMA BISNIS REAL (terlihat nyata)
- ✅ Content REAL yang sesuai bisnis
- ✅ Demo terlihat NYATA (bukan placeholder)
- ❌ TIDAK pakai Lorem Ipsum
- ❌ TIDAK pakai nama generic

**Contoh:**
- ❌ SALAH: "Demo Toko Baju"
- ✅ BENAR: "Toko Baju Modis Jakarta"

### 7. LOADING SCREEN

**Spesifikasi:**
- ✅ Muncul di SETIAP PAGE
- ✅ Ada LOGO
- ✅ Ada KATA-KATA loading
- ✅ Sesuai contoh yang sudah dibuat
- ✅ Tambahan: Info tujuan halaman

**Contoh Text:**
- "Sebentar, sedang memuat Dashboard..."
- "Mohon tunggu, membuka halaman Order..."
- "Loading data Services Anda..."

### 8. NETWORK PARTICLE BACKGROUND

**Setting:**
- ✅ Di SEMUA halaman (konsisten)
- ✅ Termasuk: Dashboard, Form, Public pages
- ✅ Intensity: LOW (30-40 particles)

**Tujuan:** Konsistensi visual di seluruh website

### 9. NIB BADGE

**Penempatan:**
- ✅ Di FOOTER semua halaman
- ✅ Size: MEDIUM (subtle)

### 10. FREE DEMO 24 JAM BANNER

**Spesifikasi:**
- ✅ ALWAYS visible (floating banner)
- ✅ Pop-up muncul di HOMEPAGE setelah 10 DETIK
- ✅ Untuk ajukan demo → HARUS REGIST dan LOGIN dulu

**Flow:**
1. User buka homepage
2. 10 detik → Pop-up muncul
3. Klik "Ajukan Demo"
4. Redirect ke Register/Login

---

## B. SISTEM & FUNGSI

### 11. EMAIL NOTIFICATIONS (AUTO)

**Email Wajib Kirim Otomatis:**

✅ **Registration & Account:**
- Registration confirmation
- Password reset

✅ **Partner Management:**
- Partner application submitted
- Partner approved

✅ **Order Management:**
- Order notification (to client)
- Order notification (to admin)
- Order completed

✅ **Payment & Commission:**
- Payment received
- Commission earned

✅ **Withdrawal:**
- Withdrawal requested
- Withdrawal approved

✅ **Demo:**
- Demo request submitted

**Kriteria:** Semua email penting dan sangat penting wajib pakai notifikasi

### 12. INVOICE GENERATION

**Format:**
- Format Nomor: `INV-SITUNEO-20-OKT-2025`
- Generate PDF: MANUAL (oleh admin)
- Email ke Client: OTOMATIS

**Flow:**
1. Admin generate invoice manual
2. System auto-email ke client
3. Client terima email + PDF

### 13. COMMISSION PAYOUT

**Timing Komisi Masuk:**
1. ✅ Client bayar LUNAS
2. ✅ Admin APPROVE payment
3. ✅ Setelah serah terima dan deal-deal
4. ✅ Komisi masuk ke balance partner

**Catatan:** Harus tunggu konfirmasi lengkap sebelum komisi masuk

### 14. ARPU CALCULATION

**System:**
- ✅ REAL-TIME (setiap ada order)
- ✅ Dihitung setelah order di-ACC admin
- ❌ BUKAN bulanan
- ❌ BUKAN manual

**Flow:**
1. Order masuk → Admin ACC
2. System hitung ARPU
3. Update dashboard SPV/Manager

### 15. WEBSITE CONTENT EDITING

**Admin Bisa Edit:**
- ✅ Homepage sections (hero, about, services)
- ✅ Services catalog (232+ services)
- ✅ Pricing packages
- ✅ Portfolio demos
- ✅ **SEMUA fungsi website**
- ✅ **SEMUA isi** dari Client, Partner, SPV, Manager

**Akses:** Admin full control semua content

### 16. "COPY FOR AI" FEATURE

**Spesifikasi:**
- ❌ JANGAN pakai kata "untuk AI"
- ✅ Seolah-olah TEAM SITUNEO yang buat
- ✅ Format: Plain text / JSON / Markdown (boleh semua)
- ✅ Include SEMUA 26 fields LENGKAP
- ✅ Formatted siap paste ke ChatGPT/Claude

**Tujuan:** Biar AI pasti paham formulir yang dikirim

### 17. HIERARCHY ASSIGNMENT

**System Assign:**
- ✅ Dari REFERRAL yang SPV kasih
- ✅ Admin bisa UBAH-UBAH (reassign)
- ✅ Bisa pindah atasan sewaktu-waktu

**Flow:**
1. Partner daftar via referral SPV → Auto assign ke SPV
2. Admin bisa manual reassign jika perlu

### 18. COMMISSION SPLIT VISUALIZATION

**Dashboard Admin Tampilkan:**
- ✅ Table breakdown komisi
- ✅ Pie chart komisi
- ✅ LENGKAP dan JELAS
- ✅ Ada SENI nya (visual menarik)

**Tujuan:** Mudah dipahami dan ada nilai estetika

### 19. IMAGE OPTIMIZATION

**Setting:**
- ✅ Lazy loading: SEMUA gambar
- ✅ Format: WebP (fallback JPG/PNG)
- ✅ Compress otomatis saat upload: AKTIF

**Tujuan:** Performance website optimal

### 20. GOOGLE ANALYTICS

**ID:** `G-RPW3MZ3RPY`

**Tracking:**
- ✅ Page views
- ✅ Button clicks
- ✅ Form submissions
- ✅ Event tracking

---

## C. ATURAN UMUM & LOGIC

### 21. LOGIC & STRUKTUR
- ✅ Semua logic diatur RAPIH
- ✅ TERSTRUKTUR
- ✅ AMAN ketika berjalan
- ✅ Kamu atur sendiri yang terbaik

### 22. GAMBAR & FOTO
**Sementara:**
- ✅ Pakai UNSPLASH
- ✅ Atau PLACEHOLDER (yang pasti muncul)
- ✅ Gambar SESUAI judul dan tema
- ✅ SINKRON dengan konten

**Prioritas:** Gambar yang pasti muncul dan relevan

### 23. TAMPILAN PUBLIC

**Aturan:**
- ✅ Public page: SINGKAT dan INTI-INTI saja
- ✅ Untuk lihat LENGKAP → Harus DAFTAR dan LOGIN
- ✅ Semua CTA arahkan ke REGIST dan LOGIN
- ✅ WhatsApp: HANYA 1 tombol pop-up di KANAN BAWAH

**Tujuan:** Full fitur hanya untuk member terdaftar

### 24. HALAMAN KHUSUS PARTNER/SPV/MANAGER

**Fitur:**
- ✅ Halaman public khusus untuk Partner, SPV, Manager Area
- ✅ Bisa lihat TEAM mana yang TERBAIK
- ✅ Bisa lihat PARTNER mana yang TERBAIK
- ✅ Dibagi sesuai JABATAN
- ✅ Semua TRANSPARAN
- ✅ Bisa kontrol team

**Ranking System:**
- Top Partner bulanan
- Top SPV bulanan
- Top Manager Area bulanan
- Leaderboard transparan

**Logic:** Kamu atur sendiri yang terbaik

---

## SUMMARY PRIORITAS

### 🔴 PRIORITAS TINGGI (Harus Ada)
1. ✅ Referral system 3 level
2. ✅ 50 Demo websites (desain premium)
3. ✅ Email notifications lengkap
4. ✅ Commission system real-time
5. ✅ Admin full control content
6. ✅ Loading screen di setiap page
7. ✅ Network particle background
8. ✅ Pop-up demo 10 detik
9. ✅ Leaderboard transparan

### 🟡 PRIORITAS SEDANG (Penting)
1. ✅ Invoice auto-email
2. ✅ ARPU calculation
3. ✅ Image optimization
4. ✅ Google Analytics tracking
5. ✅ NIB badge footer

### 🟢 PRIORITAS RENDAH (Nice to Have)
1. ✅ Commission visualization charts
2. ✅ Copy for AI feature
3. ✅ Reassign hierarchy

---

## CATATAN TEKNIS

### Format Standar:
- **Database:** 80+ tables (MySQL/PostgreSQL)
- **Framework:** PHP (Laravel/CodeIgniter) atau Node.js
- **Frontend:** HTML5, CSS3, JavaScript (jQuery/Vue/React)
- **Design:** Bootstrap/Tailwind CSS
- **Particles:** Particles.js atau Three.js
- **Charts:** Chart.js atau ApexCharts
- **Email:** SMTP / Mailgun / SendGrid

### Security:
- CSRF Protection
- XSS Prevention
- SQL Injection Prevention
- Password Hashing (bcrypt/argon2)
- Session Management
- Rate Limiting

### Performance:
- CDN untuk assets
- Browser caching
- Gzip compression
- Database indexing
- Query optimization

---

## KESIMPULAN

**Total Requirement:** 24 Poin Major
**Sub-requirement:** 100+ Detail Spesifikasi
**Kompleksitas:** HIGH (Website Komersial + MLM System)
**Timeline Estimasi:** 3-6 bulan (full development)

**Fokus Utama:**
1. 🎨 **UX/UI Premium** - Website harus terlihat mahal dan profesional
2. 🔗 **Referral System** - 3 level hierarchy berfungsi sempurna
3. 💰 **Commission System** - Real-time, akurat, transparan
4. 📧 **Automation** - Email dan notifikasi otomatis
5. 🎯 **Demo Quality** - 50 demo harus HIGH QUALITY

---

**File ini dibuat otomatis berdasarkan analisis 100% dari file requirement yang dikirim.**

