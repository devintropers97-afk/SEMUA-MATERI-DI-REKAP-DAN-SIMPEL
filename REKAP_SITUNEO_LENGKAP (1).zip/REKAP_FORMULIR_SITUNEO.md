# REKAP FORMULIR SITUNEO DIGITAL

## 📌 RINGKASAN DOKUMEN

Dokumen ini berisi rencana pembuatan formulir untuk klien SITUNEO DIGITAL yang akan digunakan untuk mengumpulkan informasi pembuatan website.

---

## 🎯 OUTPUT YANG AKAN DIBUAT

1. **Google Form** (online) - Link form yang bisa langsung dikirim ke klien
2. **Word (.docx)** - Format yang bisa diedit manual
3. **PDF** - Format profesional untuk dikirim/upload

---

## 📋 STRUKTUR FORMULIR (7 BAGIAN)

### 1️⃣ TENTANG USAHA/KEGIATAN
- Nama usaha/sekolah/organisasi
- Cerita tentang kegiatan
- Tujuan pembuatan website:
  - Profil usaha/sekolah
  - Promosi & penjualan
  - Formulir pendaftaran
  - Menampilkan informasi/berita
  - Lainnya

### 2️⃣ TAMPILAN WEBSITE
- Warna utama (biru, hijau, merah, hitam, putih, dll)
- Gaya tampilan (modern, simpel, elegan, ceria, islami, dll)
- Contoh website favorit (nama/link)

### 3️⃣ HALAMAN WEBSITE
- Halaman yang diinginkan (Home, Tentang Kami, Produk, Galeri, Kontak, dll)
- Isi/keterangan tiap halaman

### 4️⃣ FITUR TAMBAHAN
- Tombol WhatsApp
- Formulir kontak
- Galeri foto/kegiatan
- Halaman berita/blog
- Login admin/dashboard
- Pendaftaran online
- Website dua bahasa (Ya/Tidak/Serahkan ke Situneo)

### 5️⃣ LOGO & FOTO
- Logo (upload/link file)
- Foto produk/gedung/kegiatan (upload/link file)

### 6️⃣ ISI & KONTAK
- Kalimat pembuka/deskripsi usaha
- Informasi kontak:
  - Nomor WhatsApp
  - Email
  - Alamat
  - Media sosial
- Kata kunci SEO

### 7️⃣ CATATAN TAMBAHAN
- Target waktu selesai
- Permintaan khusus

---

## 🎨 BRANDING

**Nama:** SITUNEO DIGITAL

**Header:**
```
SITUNEO DIGITAL
Formulir Permintaan Pembuatan Website
(Serahkan ke Situneo jika ada bagian yang tidak Anda pahami)
```

**Footer:**
```
© SITUNEO DIGITAL | Sistem Pembuatan Website Otomatis Berbasis AI
```

**Pesan Kunci:**
> "Jika tidak paham, tulis saja: Serahkan ke Situneo."

---

## 📂 STRUKTUR FILE YANG AKAN DIBUAT

```
/Situneo_System/
 ├─ 3_Examples/
 │   ├─ Formulir_Situneo_GoogleForm_Link.txt
 │   ├─ Formulir_Situneo.docx
 │   ├─ Formulir_Situneo.pdf
 │   └─ Website_Demo.zip
```

---

## ✅ KONFIRMASI SEBELUM PEMBUATAN

1. Nama: **SITUNEO DIGITAL** ✓
2. Logo: Dummy teks (bisa diganti nanti)
3. Bahasa: Indonesia (formal tapi santai)
4. Google Form: Ya, akan dibuatkan template

---

**Dibuat oleh:** Claude AI  
**Tanggal:** 20 November 2025  
**Status:** Rekap lengkap 100% dari file asli
