# 📊 REKAP LENGKAP LAYANAN PT SITUNEO DIGITAL

## 🏢 INFORMASI PERUSAHAAN
**Nama:** PT SITUNEO DIGITAL  
**Fokus Bisnis:** Digital Solutions, Website Development, Marketing & AI Automation

---

## 📂 STRUKTUR LAYANAN - 4 DIVISI UTAMA

---

# DIVISI 1: WEBSITE & PENGEMBANGAN SISTEM

## 1️⃣ LANDING PAGE / HALAMAN PROFIL
- **Harga Sekali Bayar:** Rp 350.000
- **Harga Bulanan:** Rp 150.000/bulan
- **Fitur:** 1 halaman, responsif, SEO dasar, SSL, domain + hosting, WhatsApp integration

## 2️⃣ WEBSITE MULTI HALAMAN (4-6 Halaman)
- **Harga Sekali Bayar:** Rp 750.000
- **Harga Bulanan:** Rp 250.000/bulan
- **Fitur:** 4-6 halaman, navigasi menu, galeri, kontak form, blog section

## 3️⃣ WEBSITE TOKO ONLINE (E-COMMERCE)
- **Harga Sekali Bayar:** Rp 1.500.000
- **Harga Bulanan:** Rp 350.000/bulan
- **Fitur:** Katalog produk, keranjang belanja, checkout, payment gateway (add-on)

## 4️⃣ WEBSITE CUSTOM / SISTEM WEB APP
- **Harga Sekali Bayar:** Mulai Rp 2.000.000
- **Harga Bulanan:** Rp 500.000 - 1.000.000/bulan
- **Fitur:** Custom design, sistem database, dashboard admin, API integration

## 5️⃣ WEBSITE SEKOLAH / LEMBAGA / YAYASAN
- **Harga Sekali Bayar:** Rp 1.200.000
- **Harga Bulanan:** Rp 400.000/bulan
- **Fitur:** Profil sekolah, agenda, galeri, pengumuman, info PPDB

## 6️⃣ WEBSITE PORTOFOLIO / PERSONAL BRANDING
- **Harga Sekali Bayar:** Rp 700.000
- **Harga Bulanan:** Rp 200.000/bulan
- **Fitur:** Portfolio showcase, CV online, contact form, testimoni

## 7️⃣ WEBSITE AI & OTOMASI BISNIS
- **Harga Sekali Bayar:** Rp 2.500.000
- **Harga Bulanan:** Rp 450.000/bulan
- **Fitur:** Chatbot AI, automation workflow, dashboard analitik

## 8️⃣ WEBSITE PEMERINTAHAN (GOVSITE)
- **Harga Sekali Bayar:** Rp 1.800.000
- **Harga Bulanan:** Rp 800.000/bulan
- **Fitur:** Portal layanan publik, berita & pengumuman, sistem pengaduan

## 9️⃣ WEBSITE KOMUNITAS (COMMUNITY SITE)
- **Harga Sekali Bayar:** Rp 1.500.000
- **Harga Bulanan:** Rp 600.000/bulan
- **Fitur:** Member area, forum diskusi, event calendar, galeri kegiatan

## 🔟 WEBSITE EVENT (EVENTSITE)
- **Harga Sekali Bayar:** Rp 1.200.000
- **Harga Bulanan:** Rp 500.000/bulan
- **Fitur:** Landing page event, form pendaftaran, jadwal, pembicara, galeri

## 1️⃣1️⃣ WEBSITE PROPERTI / REAL ESTATE (PROPERTYSITE)
- **Harga Sekali Bayar:** Rp 2.200.000
- **Harga Bulanan:** Rp 900.000/bulan
- **Fitur:** Listing properti, filter pencarian, galeri foto, kontak agen

---

### 🛠️ FITUR STANDAR SEMUA WEBSITE:
✅ Desain responsif (mobile-friendly)  
✅ SEO dasar aktif  
✅ SSL & keamanan  
✅ Domain + hosting management  
✅ Google Maps integration  
✅ WhatsApp contact button  
✅ Email bisnis (optional)  
✅ Integrasi media sosial  
✅ Maintenance & dukungan teknis

---

### 🎁 ADD-ON / FITUR TAMBAHAN (OPSIONAL):
| Fitur | Harga |
|-------|-------|
| Optimasi kecepatan website | Rp 200.000 |
| SSL & Firewall proteksi malware | Rp 150.000 |
| SEO Premium | Rp 600.000/bulan |
| Google My Business optimasi | Rp 250.000 |
| Payment Gateway integration | Rp 250.000 |
| Chatbot WhatsApp / AI | Rp 200.000/bulan |
| Dashboard Admin / CMS | Rp 500.000 |
| Sistem CRM Pelanggan | Rp 400.000 |

---

### 📦 PAKET KOMBINASI (HEMAT BULANAN):

#### 🚀 STARTUP GO DIGITAL
- **Harga:** Rp 200.000/bulan
- **Isi:** Website Dasar + Domain + SEO Dasar + WhatsApp Link

#### 💼 BISNIS NAIK LEVEL
- **Harga:** Rp 400.000/bulan
- **Isi:** Website Pro + SEO + Copywriting + Meta Ads + Laporan

#### 🤖 SISTEM AI DIGITAL
- **Harga:** Rp 600.000/bulan
- **Isi:** Website Custom + CRM + Chatbot AI + Marketing Report

#### 🛒 PERTUMBUHAN E-COMMERCE
- **Harga:** Rp 500.000/bulan
- **Isi:** Toko Online + Payment Gateway + Ads + Maintenance

---

---

# DIVISI 2: DIGITAL MARKETING & TRAFFIC GROWTH

## 🎯 LAYANAN UTAMA (HARGA BULANAN):

### 📈 SEO (Search Engine Optimization)
- **SEO Dasar:** Rp 200.000/bulan
- **SEO Premium:** Rp 600.000/bulan

### 📢 IKLAN DIGITAL
- **Google Ads (Search, Display, Remarketing):** Mulai Rp 400.000/bulan
- **Meta Ads (Facebook & Instagram):** Rp 400.000/bulan
- **TikTok Ads Management:** Rp 400.000/bulan

### 📍 MARKETING LOKAL & BLAST
- **Google My Business (lokal SEO):** Rp 250.000/bulan
- **WhatsApp Blast:** Rp 250.000/bulan
- **Email Automation:** Rp 200.000/bulan

### 🎯 STRATEGI & OPTIMASI
- **Kampanye Retargeting & Remarketing:** Rp 300.000/bulan
- **Traffic Growth Plan:** Rp 500.000/bulan
- **Riset Keyword & Kompetitor:** Rp 200.000
- **AI-Based Audience Targeting:** Rp 300.000
- **Campaign Planning (3 bulan):** Rp 400.000
- **Brand Awareness Campaign:** Rp 500.000/bulan

---

## ✍️ KONTEN & BRAND SUPPORT

### 📝 COPYWRITING & CONTENT CREATION
- **Landing Page Copywriting:** Rp 150.000/halaman
- **Paket Content Creator (foto produk, video reels, caption):** Rp 500.000 - 1.000.000/bulan
- **Social Media Management:** Rp 400.000/bulan
- **Content Planner (bulanan):** Rp 200.000/bulan
- **Banner Ads & Promotional Design:** Rp 100.000 - 300.000/set

---

---

# DIVISI 3: OTOMASI & SISTEM AI

## 🤖 LAYANAN UTAMA:

### 💬 CHATBOT AI
- **Chatbot AI (WhatsApp/Website/Instagram):**
  - Basic: Rp 300.000/bulan
  - Premium: Rp 600.000/bulan

### 📊 CRM SYSTEM
- **Sistem CRM (Customer Relationship Management):**
  - Basic: Rp 500.000
  - Custom: Rp 1.000.000

### 📧 AUTOMATION TOOLS
- **WhatsApp Blast Otomatis:** Rp 250.000/bulan
- **Email Automation System:** Rp 200.000/bulan
- **Follow-up Automation (Lead Nurturing):** Rp 300.000/bulan
- **Booking/Appointment Automation:** Rp 250.000

### 📈 BUSINESS INTELLIGENCE
- **AI Business Dashboard:** Rp 500.000 - 1.000.000
- **Website + CRM + Chatbot Integration:** Rp 800.000
- **AI Sales Forecasting:** Rp 500.000/bulan

---

## 🎁 ADD-ON & CUSTOM:
- **AI Assistant Training (chatbot khusus):** Rp 250.000 (setup)
- **API Integration (Google Sheet, Website, Meta, WooCommerce, dll):** Rp 300.000 - 800.000
- **Auto Lead Distribution:** Rp 250.000/bulan
- **Multi-Agent Chat Dashboard:** Rp 300.000/bulan
- **Security & Data Backup Automation:** Rp 200.000/bulan

---

## 📦 PAKET KOMBINASI:

### 🌱 PAKET PEMULA OTOMASI
- **Harga:** Rp 700.000/bulan
- **Isi:** Chatbot AI + WhatsApp Blast + CRM Dasar

### 🧠 PAKET BISNIS CERDAS AI
- **Harga:** Rp 1.200.000/bulan
- **Isi:** CRM + Chatbot Premium + Dashboard Analitik

### 💰 PAKET PENDORONG PENJUALAN
- **Harga:** Rp 900.000/bulan
- **Isi:** Auto Follow-up + CRM + Payment Reminder

### 🛒 PAKET OTOMASI E-COMMERCE
- **Harga:** Rp 1.000.000/bulan
- **Isi:** Product Chatbot + Website Integration + Auto Invoice

### 🏢 PAKET OTOMASI PERUSAHAAN
- **Harga:** Rp 2.000.000/bulan
- **Isi:** Full AI + CRM + Dashboard + API + Security Backup

---

---

# DIVISI 4: BRANDING & DESAIN KREATIF

## 🎨 LAYANAN DESAIN:

### 🖌️ LOGO & BRAND IDENTITY
- **Desain Logo:**
  - Basic: Rp 250.000
  - Premium: Rp 500.000
- **Brand Guidelines / Brand Identity Book:** Rp 600.000 - 1.000.000
- **Rebranding & Logo Redesign:** Rp 350.000
- **Business Card, Letterhead, Envelope (stationery set):** Rp 250.000 - 400.000/set

### 📦 PACKAGING & PRODUCT DESIGN
- **Packaging Design (box, label, sticker):** Rp 400.000 - 800.000/set
- **Label Design:** Rp 150.000 - 300.000
- **Mockup Product 3D:** Rp 200.000 - 500.000

### 📸 FOTOGRAFI & VIDEOGRAFI
- **Photo Product (10-20 foto edit):** Rp 500.000 - 1.000.000
- **Video Company Profile:** Rp 1.500.000 - 3.000.000
- **Video Promosi / Iklan (15-30 detik):** Rp 800.000 - 1.500.000
- **Reels / TikTok Video (10 video/bulan):** Rp 500.000 - 1.000.000

### 🎬 MOTION GRAPHICS & ANIMATION
- **Motion Graphics Logo (animasi intro):** Rp 400.000 - 800.000
- **Explainer Video Animation:** Rp 1.500.000 - 3.000.000
- **Whiteboard Animation:** Rp 1.000.000 - 2.000.000

### 🖼️ SOCIAL MEDIA DESIGN
- **Social Media Feed Design (9-12 post):** Rp 300.000 - 600.000/bulan
- **Story / Reels Template Design:** Rp 150.000 - 300.000/set
- **Carousel Post Design (5-10 slide):** Rp 200.000 - 400.000

### 📄 PRINT DESIGN
- **Flyer / Brosur Design:** Rp 150.000 - 300.000
- **Banner / Spanduk Design:** Rp 200.000 - 400.000
- **Company Profile Book Design:** Rp 800.000 - 1.500.000
- **Katalog Produk Design:** Rp 600.000 - 1.200.000

---

## 📦 PAKET KOMBINASI BRANDING:

### 🌟 PAKET BRANDING BASIC
- **Harga:** Rp 800.000
- **Isi:** Logo + Business Card + Social Media Template (3 post)

### 💼 PAKET BRANDING PROFESIONAL
- **Harga:** Rp 1.500.000
- **Isi:** Logo + Brand Guidelines + Stationery Set + 6 Social Media Post

### 🚀 PAKET BRANDING PREMIUM
- **Harga:** Rp 3.000.000
- **Isi:** Logo + Brand Book + Packaging + Company Profile + 10 Social Media Post + Video Profile

### 📱 PAKET KONTEN BULANAN
- **Harga:** Rp 500.000 - 1.000.000/bulan
- **Isi:** 12 Social Media Post + 4 Reels Video + Caption + Hashtag Strategy

---

---

# 💰 RINGKASAN HARGA (RANGE BIAYA)

## DIVISI 1 - WEBSITE
- **Harga Sekali Bayar:** Rp 350.000 - Rp 2.500.000
- **Harga Bulanan:** Rp 150.000 - Rp 1.000.000/bulan

## DIVISI 2 - DIGITAL MARKETING
- **Harga Bulanan:** Rp 200.000 - Rp 1.000.000/bulan
- **Harga Per Proyek:** Rp 150.000 - Rp 500.000

## DIVISI 3 - AI & OTOMASI
- **Harga Bulanan:** Rp 200.000 - Rp 2.000.000/bulan
- **Harga Setup/Custom:** Rp 250.000 - Rp 1.000.000

## DIVISI 4 - BRANDING & DESAIN
- **Harga Per Proyek:** Rp 100.000 - Rp 3.000.000
- **Paket Bulanan:** Rp 500.000 - Rp 1.000.000/bulan

---

# 🎯 KEUNGGULAN LAYANAN SITUNEO

✅ **Harga Kompetitif** - 40-70% lebih hemat dari pasaran  
✅ **Pengerjaan Cepat** - 1-3 hari kerja untuk website standar  
✅ **Desain Profesional** - Dibuat manual oleh tim ahli, bukan template  
✅ **Support Penuh** - Maintenance, update, dan konsultasi gratis  
✅ **Teknologi Terkini** - AI integration, automation, modern framework  
✅ **All-in-One Solution** - Dari website sampai marketing & branding  

---

# 📞 CARA PEMESANAN

1. **Konsultasi Gratis** - Diskusi kebutuhan & budget
2. **Pilih Paket** - Sesuaikan dengan kebutuhan bisnis
3. **Deal & Agreement** - Sepakati harga & timeline
4. **Proses Pengerjaan** - Tim SITUNEO mulai bekerja
5. **Review & Revisi** - Client review hasil kerja
6. **Serah Terima** - Website/project siap digunakan
7. **After Sales Support** - Maintenance & konsultasi gratis

---

# 🏆 TARGET MARKET

✅ UMKM & Startup  
✅ Perusahaan menengah  
✅ Lembaga pendidikan  
✅ Pemerintahan & instansi publik  
✅ Developer properti & real estate  
✅ Event organizer  
✅ E-commerce & toko online  
✅ Komunitas & organisasi  
✅ Personal branding & freelancer  

---

# 📌 CATATAN PENTING

⚠️ **Harga dapat berubah sewaktu-waktu**  
⚠️ **Add-on & custom request dikenakan biaya tambahan**  
⚠️ **Estimasi waktu pengerjaan tergantung kompleksitas proyek**  
⚠️ **Maintenance & hosting bulanan diperlukan untuk website tetap aktif**  
⚠️ **Revisi diluar ketentuan paket akan dikenakan biaya tambahan**  

---

# 📧 KONTAK SITUNEO

📱 **WhatsApp:** [Nomor WhatsApp]  
📧 **Email:** [Email Bisnis]  
🌐 **Website:** [www.situneo.com]  
📍 **Lokasi:** [Alamat Kantor]  

---

**© 2025 PT SITUNEO DIGITAL - Digital Solutions for Modern Business**

---

*Dokumen ini adalah rangkuman lengkap dari file katalog layanan SITUNEO yang terdiri dari 4.898 baris teks.*
