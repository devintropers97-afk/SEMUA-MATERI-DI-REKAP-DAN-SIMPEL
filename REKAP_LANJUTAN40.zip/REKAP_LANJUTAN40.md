# REKAP LENGKAP FILE LANJUTAN40
## SITUNEO DIGITAL - User Profile Page

---

## 📌 INFORMASI FILE
- **Nama File**: lanjutan40
- **Total Baris**: 961 baris
- **Jenis**: PHP/HTML
- **Fungsi**: Halaman profil pengguna
- **NIB**: 20250-9261-4570-4515-5453

---

## 🎯 RINGKASAN FUNGSI UTAMA

### 1. **UPDATE PROFIL USER**
- Form untuk mengubah nama lengkap
- Form untuk mengubah nomor telepon
- Form untuk mengubah alamat
- Validasi: nama dan telepon wajib diisi
- Auto-update session setelah berhasil

### 2. **UBAH PASSWORD**
- Memerlukan password lama (current password)
- Password baru minimal 8 karakter
- Konfirmasi password harus sama
- Password di-hash dengan fungsi hashPassword()
- Logging aktivitas perubahan password

### 3. **UPLOAD AVATAR**
- Format yang diterima: JPEG, PNG, GIF
- Ukuran maksimal: 2MB
- Filename unik: avatar_{user_id}_{timestamp}.{ext}
- Folder upload: ../uploads/avatars/
- Auto-create folder jika belum ada

### 4. **KEAMANAN**
- requireLogin() - wajib login untuk akses
- getCurrentUser() - ambil data user dari session
- Prepared statements untuk query SQL
- Validasi tipe file dan ukuran upload
- Activity logging untuk audit trail

---

## 📂 STRUKTUR KODE

### A. PHP BACKEND (Baris 1-150)

#### 1. Konfigurasi & Session
```php
require_once 'config.php';
requireLogin();
$user = getCurrentUser();
```

#### 2. Proses Update Profil (Baris 21-55)
- Ambil data POST: name, phone, address
- Validasi input (nama & telepon wajib)
- Update database dengan prepared statement
- Update session $_SESSION['user_name']
- Log aktivitas: 'Profile updated'

#### 3. Proses Ubah Password (Baris 58-99)
- Validasi password lama dengan verifyPassword()
- Cek panjang password minimal
- Cek kecocokan password baru dan konfirmasi
- Hash password baru
- Update ke database
- Log aktivitas: 'Password changed'

#### 4. Proses Upload Avatar (Baris 102-149)
- Cek error upload
- Validasi tipe file (allowed_types)
- Validasi ukuran max 2MB
- Generate nama file unik
- Move file ke folder avatars
- Update database field avatar
- Log aktivitas: 'Avatar updated'

### B. HTML FRONTEND (Baris 152-961)

#### 1. Head Section (Baris 154-170)
- Meta charset & viewport
- Title & description
- Favicon dari situneo.my.id
- Google Fonts: Inter & Plus Jakarta Sans
- Bootstrap 5.3.3 & Bootstrap Icons
- AOS Animation library

#### 2. CSS Styling (Baris 171-746)

**Variables CSS:**
```css
--primary-blue: #1E5C99
--dark-blue: #0F3057
--gold: #FFB400
--bright-gold: #FFD700
--gradient-primary: linear-gradient(135deg, #1E5C99, #0F3057)
--gradient-gold: linear-gradient(135deg, #FFD700, #FFB400)
```

**Komponen Styling:**
- Network animated background (opacity 0.3)
- Circuit pattern overlay
- Navbar premium dengan scroll effect
- Sidebar menu dengan hover effect
- Form cards dengan glass-morphism effect
- Avatar upload area
- Button gold dengan gradient
- Alert messages (success/error)
- Responsive design untuk mobile/tablet

#### 3. Navbar (Premium)
- Logo SITUNEO DIGITAL
- Nama user dengan avatar
- Dropdown profile menu
- Sidebar toggle untuk mobile
- Scroll effect (background blur)

#### 4. Sidebar Menu
- Dashboard link
- Projects link
- Team link
- Settings link
- Keluar (logout) link
- Icon Bootstrap Icons
- Active state styling

#### 5. Main Content Area

**A. Profil Header Card**
- Avatar preview besar (150x150px)
- Nama user
- Email user
- Join date
- Button "Ubah Avatar"
- File input tersembunyi

**B. Form Edit Profil**
- Input nama lengkap
- Input email (readonly)
- Input nomor telepon
- Textarea alamat (3 rows)
- Button "Simpan Perubahan"
- Error handling dengan invalid-feedback class
- Success message dengan alert

**C. Form Ubah Password**
- 3 kolom input (responsive grid):
  * Password saat ini
  * Password baru
  * Konfirmasi password baru
- Button "Ubah Password"
- Error handling per field
- Hidden input: change_password

#### 6. JavaScript (Baris 802-959)

**A. AOS Initialization**
```javascript
AOS.init({
    duration: 1000,
    once: true
});
```

**B. Network Background Animation**
- Canvas element dinamis
- 50 nodes bergerak (particle system)
- Connection lines jika jarak < 150px
- Opacity based on distance
- Resize handler untuk responsive
- RequestAnimationFrame untuk smooth animation

**Class Node:**
- Random posisi X, Y
- Random velocity (vx, vy)
- Radius 1-3px
- Update posisi setiap frame
- Bounce pada border canvas

**C. Sidebar Toggle**
- Toggle class 'show' pada click
- Untuk mobile menu

**D. Navbar Scroll Effect**
- Detect scroll > 50px
- Add class 'scrolled' untuk blur effect

**E. Avatar Upload Handler**
- Auto-submit form on file change
- Dynamic form creation
- File input append to form

**F. Form Validations**

**Validasi Profil:**
- Cek nama tidak kosong
- Cek phone tidak kosong
- Prevent submit jika invalid
- Focus ke field error

**Validasi Password:**
- Semua field wajib diisi
- Password baru = konfirmasi password
- Password minimal 8 karakter
- Alert untuk error message

---

## 🔐 FITUR KEAMANAN

1. **Authentication**: requireLogin() di awal file
2. **SQL Injection Protection**: Prepared statements
3. **Password Security**: Hash dengan hashPassword()
4. **File Upload Security**: 
   - Validasi tipe file
   - Validasi ukuran file
   - Generate unique filename
5. **XSS Prevention**: htmlspecialchars() untuk output
6. **Activity Logging**: Semua aksi dicatat
7. **Session Management**: Update session setelah perubahan

---

## 🎨 DESIGN PATTERN

### Color Scheme:
- **Primary**: Blue (#1E5C99, #0F3057)
- **Accent**: Gold (#FFB400, #FFD700)
- **Background**: Dark blue gradient
- **Text**: White (#ffffff)

### UI Elements:
- Glass-morphism cards
- Gradient buttons
- Animated network background
- Circuit pattern overlay
- Smooth transitions
- Responsive grid layout

### Typography:
- **Primary Font**: Inter (300-900)
- **Secondary Font**: Plus Jakarta Sans (400-900)

---

## 📱 RESPONSIVE DESIGN

### Breakpoints:
- **Desktop**: Full sidebar + content
- **Tablet**: Collapsible sidebar
- **Mobile**: 
  - Hamburger menu
  - Stacked form layout
  - Full-width cards

### Mobile Optimizations:
- Touch-friendly buttons (48px min)
- Larger form inputs
- Simplified navigation
- Hidden sidebar (toggle)

---

## 🔄 WORKFLOW USER

1. **Login** → requireLogin() check
2. **Load Profile** → getCurrentUser()
3. **View Data** → Display dari database
4. **Edit Action**:
   - Update profil → POST → Validate → Update DB → Log
   - Change password → POST → Verify old → Hash new → Update → Log
   - Upload avatar → FILES → Validate → Move → Update DB → Log
5. **Success** → Refresh data → Show message
6. **Error** → Show error feedback

---

## 📊 DATABASE INTERACTIONS

### Tables:
1. **users** (main table)
   - Fields: id, name, email, phone, address, password, avatar, created_at
   - Update queries dengan prepared statements

2. **activity_logs** (via logActivity function)
   - Log: 'Profile updated', 'Password changed', 'Avatar updated'

### Queries:
```sql
-- Update profile
UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?

-- Update password
UPDATE users SET password = ? WHERE id = ?

-- Update avatar
UPDATE users SET avatar = ? WHERE id = ?
```

---

## 🛠️ DEPENDENCIES

### Backend:
- PHP 7.4+
- MySQL/MariaDB
- config.php (custom functions)

### Frontend:
- Bootstrap 5.3.3
- Bootstrap Icons 1.11.3
- AOS 2.3.1 (Animate On Scroll)
- Google Fonts

### Functions (dari config.php):
- requireLogin()
- getCurrentUser()
- hashPassword()
- verifyPassword()
- logActivity()

---

## 📝 VALIDASI RULES

### Profil:
- Nama: Wajib diisi
- Phone: Wajib diisi
- Address: Optional

### Password:
- Current password: Wajib, harus benar
- New password: Minimal 8 karakter
- Confirm password: Harus sama dengan new password

### Avatar:
- Format: JPEG, PNG, GIF only
- Size: Max 2MB
- Upload folder: ../uploads/avatars/

---

## 🎯 KEY FEATURES

1. ✅ Real-time form validation
2. ✅ Animated background (particles + connections)
3. ✅ Responsive design (mobile-first)
4. ✅ Activity logging untuk audit
5. ✅ Secure file upload
6. ✅ Password strength validation
7. ✅ Session management
8. ✅ Success/error notifications
9. ✅ Glass-morphism UI design
10. ✅ Smooth animations dengan AOS

---

## 🚀 PERFORMANCE

- Lazy load animations (AOS once: true)
- RequestAnimationFrame untuk animasi smooth
- Prepared statements untuk query optimization
- Canvas resize handler untuk responsive canvas
- Minimal external dependencies

---

## 📌 CATATAN PENTING

1. **File Upload**: Folder ../uploads/avatars/ harus writable (chmod 777)
2. **Config**: Pastikan config.php sudah ada dengan fungsi required
3. **Database**: Table users harus punya field avatar (VARCHAR)
4. **Session**: PHP session harus aktif
5. **Security**: Ganti MIN_PASSWORD_LENGTH sesuai policy

---

## 🔧 CARA PENGGUNAAN

1. User harus login terlebih dahulu
2. Akses halaman profile.php
3. Form akan ter-load dengan data user saat ini
4. Edit data yang diinginkan
5. Submit form
6. Validasi akan berjalan
7. Jika valid → update database → success message
8. Jika error → tampil pesan error

---

## ⚠️ TROUBLESHOOTING

**Problem**: Avatar tidak terupload
- **Solution**: Cek permission folder uploads/avatars/ (chmod 777)

**Problem**: Password tidak bisa diubah
- **Solution**: Cek fungsi hashPassword() dan verifyPassword() di config.php

**Problem**: Session error
- **Solution**: Pastikan session_start() sudah dipanggil di config.php

**Problem**: Network animation lag
- **Solution**: Kurangi nodeCount atau connectionDistance

---

## 📚 FILE DEPENDENCIES

File ini memerlukan:
1. config.php (untuk fungsi-fungsi core)
2. Folder: ../uploads/avatars/ (untuk avatar storage)
3. Database: table users dengan field lengkap
4. Session PHP aktif

---

**END OF RECAP**
Generated: 2025
Total Lines Analyzed: 961
Status: ✅ COMPLETE
